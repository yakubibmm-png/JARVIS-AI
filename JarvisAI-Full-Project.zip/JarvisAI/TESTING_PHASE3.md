# Phase 3 — test on a real phone
1. Say "Open <any app you have>" (try a Play Store app you installed yesterday). Also try a wrong name, and two similar names (Files / Google).
2. "Install <app you don't have>": Play opens → tap Install → return to JARVIS: it should post/speak "installed" ONLY after Android finishes. Try an already-installed app.
3. "Remind me in 2 minutes to test": notification arrives (with and without notification permission; with and without "Alarms & reminders"). Reboot and re-test a future reminder.
4. "Set an alarm for 6:30 AM" → check the Clock app. 5. "What time is it in Tokyo?" 6. "Weather" (with/without Location permission) and "weather in Paris".
7. "Play relaxing music", "pause", "next". 8. "Find <contact>", "Call <contact>", "Message <contact> hello on WhatsApp" (check the draft opens, nothing is sent).
9. Turn off Wi-Fi: "Open <app>" and "what time is it" should still work (offline parser). 10. Ask a normal question: it must still just answer.
11. Voice: after "Open X" JARVIS should still speak its confirmation while X is on screen. 12. Quick Actions / Reminders / Music / Weather screens from Home.
