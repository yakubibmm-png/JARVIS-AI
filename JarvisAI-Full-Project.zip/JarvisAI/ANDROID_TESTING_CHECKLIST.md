# Android testing checklist (Phases 1–4)

## Setup
- Android Studio sync/build; install on a real phone (Android 13/14 ideal). Add Gemini key. Unlock Pro. Tools → Automation → master switch ON.
- Android 13+: App info → ⋮ → Allow restricted settings (needed for Accessibility and Notification Access when sideloaded).

## Phases 1–3 regression
1. Home orb/waveform, mic permission, speak a question, hear the answer; MUTE/SLEEP/STOP. Chat: stream, Copy/Share/Read Aloud, history, attachments.
2. "Open <any app>", wrong name, two similar names; "Install <app>" (Play opens, confirm only after Android installs); reminder in 2 min; alarm; time in Tokyo; weather (with/without Location); play music + pause/next; find/call/message a contact (nothing sent silently); offline "open <app>".

## Accessibility + screen control
3. Permissions → Accessibility: disclosure shown, enable service. "Open WhatsApp" → "Read the screen" → "Open the second chat" (check it opens the 2nd row) → "Type hello" → "Send it": a Confirm card appears, nothing sent until you tap Confirm or say yes → message is sent and JARVIS reports verified/unverified honestly.
4. "Scroll down", "Go back", "Tap <visible button text>", "Go home". Try a password field: JARVIS must refuse to type/read it. Try tapping a "Delete"/"Pay" button: confirmation required.
5. Automation OFF → all of the above must refuse with a clear message. Free (non-Pro) account → refuse.
6. JARVIS in background + Accessibility on: "Open YouTube" via a scheduled task or trigger.

## Screen Share
7. Automation → Screen Share ON → Android consent dialog → notification "JARVIS is sharing your screen". Ask "What am I looking at?" (answer uses the screenshot). Stop via notification or switch. Screen Share OFF → question falls back to readable text.

## Auto Reply
8. Enable Notification Access (disclosure). Auto Reply ON (Fixed reply). Have another phone message you on WhatsApp: reply arrives once; second message within cooldown gets none; group message gets none (unless allowed). Try Rules mode ("hello" → "Hi!") and AI mode (disclosure shown). Check the reply log. EMERGENCY OFF stops it instantly; master switch OFF too; status notification action "Auto-reply OFF".
9. Preview box shows the reply without sending.

## Background assistant, reminders, triggers
10. Background assistant ON → "JARVIS is active" notification; lock the phone; reminder fires, notification shows and (Pro) is spoken. Reboot: assistant and reminders return. Stop from notification.
11. Smart Triggers: add "Charger connected → Tell me the battery tip"; plug in; result notification (+ voice). Task Scheduler: a task 2 minutes ahead. App Launch: scheduled open (notification or direct launch with Accessibility). Custom Action: create "Good morning", say "Run my Good morning action".

## Premium screens
12. Voice Pack: preview Gemini and ElevenLabs voices, Use one; Voice Changer record → convert & play; My Voice: consent box required, create voice (paid ElevenLabs), use/delete.
13. Super AI: add a key + model ID, Verify (must show a real pass/fail), set Active, chat answers come from it (no phone tools); switch back to Gemini.
14. Preferences: Compact vs Full answers, Care/Boss/Friend tone, Language Mirror (Bengali/Hindi: replies and speech-recognition language), Clear Memory.
15. Personalization: AI name/your name, avatar change on Home/Chat/Settings, accent colour, Reset. Contact Shortcuts: save "72"; say "Message 72 on WhatsApp: hello".
16. Settings: Notifications (channel pages open), Privacy & Security (history off, clear data, remove keys), Appearance (font size), About.

## Safety checks
17. Rotate/background the app mid-voice; revoke each permission and confirm friendly errors. Make sure no message is ever sent, no call placed, nothing paid or deleted without your yes.
