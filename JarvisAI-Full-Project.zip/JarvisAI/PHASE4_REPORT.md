# Phase 4 — implementation report

## Implemented
1. **Accessibility Service** (`screen/JarvisAccessibilityService`, `ScreenReader`, `AccessibilityScreenController`). Reads the visible UI tree (never password fields), finds targets by text / view id / list position, performs click, long-press, scroll, type (ACTION_SET_TEXT), back/home/recents; gesture tap only as a fallback. Every call is gated by Pro + Automation ON + service enabled; plain-language disclosure before the user is sent to Android settings.
2. **Screen Share** (`screen/ScreenShareService`): Android MediaProjection consent each time, foreground service with a visible "Stop sharing" notification, one frame read only when you ask a screen question (`screen_question`), nothing stored. Toggle in Tools → Automation.
3. **Screen-aware commands**: tool `screen_action` (read_screen, tap, long_press, type, send, scroll_down/up, back, home, recents) and `screen_question`. Results report what Android accepted (and verify typing/sending where possible).
4. **Contextual follow-ups**: `ActionMemory` keeps recent actions, current app (from accessibility window events), last item opened, and the visible list items; these go into Gemini's prompt so "Open WhatsApp" → "Open the second chat" (ordinal=2 on the main list) → "Send him hello" works.
5. **WhatsApp messaging with confirmation**: `draft_message` opens the chat with the text prefilled; `screen_action send` creates a pending confirmation (card on every screen with Confirm/Cancel, or the user's next "yes"); only then is Send tapped and verified. Any tap on a label like Send/Pay/Buy/Delete/Confirm needs confirmation. Gemini cannot confirm in the same turn that created the request.
6. **WhatsApp Auto Reply** (`automation/AutoReply`): NotificationListener + WhatsApp's own Reply action. Needs Pro + Automation ON + Auto Reply ON + Notification Access. Modes: one reply / keyword rules / AI (Gemini). Groups off by default, only-contacts option, per-person cooldown, 20/hour cap, emergency OFF, preview box, local reply log.
7. **Contact shortcuts**: Tools → Automation → Contact Shortcuts ("72" → a contact); used by every contact tool; the shortcut names (not numbers) are given to Gemini.
8. **Background assistant**: `AssistantService` (visible foreground service, "JARVIS is active", Auto-reply OFF / Stop actions). Hosts smart triggers (charger, headphones, Wi-Fi). Never uses the microphone in the background.
9. **Spoken reminders and background voice**: reminder alarms speak through the foreground service (Pro); install results and automation results can be spoken. Switches in Automation and Settings → Notifications.
10. **Premium screens (all functional)**: Voice Pack (Gemini + ElevenLabs voice categories with preview, Voice Changer via ElevenLabs speech-to-speech, My Voice via ElevenLabs voice creation with consent), Super AI (ChatGPT, Claude, Perplexity, Grok, Custom OpenAI-compatible: key + model, real Verify test, Active switch), Preferences (Voice Brain, Clear Memory, Care/Boss/Friend, Language Mirror for 19 languages + custom tag), Personalization (AI/user name, avatar, style, accent colour, reset), Automation (master switch, requirements, modules), plus Auto Reply, App Launch, Task Scheduler, Smart Triggers, Custom Actions, Contact Shortcuts and More Features.
11. Also made real (previously placeholders): Settings → Notifications, Privacy & Security, Appearance (accent, font size, avatar), About.

## Known limitations
- Not compiled or run here (see Build status). Accessibility, MediaProjection, notification-reply, foreground-service and background-launch behaviour differs by phone maker and Android version and must be tested on devices.
- Android 13+: sideloaded apps must use App info → ⋮ → "Allow restricted settings" before Accessibility / Notification Access can be enabled.
- Apps that block accessibility (banking, password screens, FLAG_SECURE) can't be read; WhatsApp view ids/labels can change between versions.
- Auto Reply works on WhatsApp notifications that offer a Reply action (normal chats); it cannot reply if the notification is dismissed or the chat is muted/hidden by WhatsApp.
- Background app launches only work through the Accessibility Service; otherwise one app per request while JARVIS is on screen. Starting a foreground service from the background can be refused by Android (spoken reminder then falls back to the notification).
- Voice Changer / My Voice need a paid ElevenLabs plan (speech-to-speech model ID and the preset voice IDs may change; paste your own voice ID if one is retired). Gemini voice names and the TTS model ID are configuration, not guaranteed.
- Super AI providers other than Gemini are text-only (no phone tools). Model IDs are typed by the user; the Verify button is the only proof a provider works.
- Gemini tool-calling model IDs in `assets/gemini_models.json` must be verified against Google's current list.
- Some icon tints use the accent colour captured at start-up and update after reopening the app.
- Chats are plain JSON in private storage (not separately encrypted). Pro unlock is still validated on the device (swap `LicenseValidator` for a server check before wide distribution).

## Remaining work (not built)
- Biometric / app lock; light and auto themes; Terms of Service text; Rate/Update links need the real Play listing.
- Hotword ("Hey Jarvis") wake-up and always-on listening (deliberately not built).
- Direct (non-dialer) calling with confirmation; sending to groups; media/voice-message handling in Auto Reply.
- Server-side licensing, crash reporting, release signing/minification, Play-policy declarations for Accessibility, foreground services and notification access.
- A real device test pass and fixes from the first compile.

## Build status
- **Not compiled.** No Android SDK / Gradle / Kotlin compiler in the build environment.
- Checks performed: brace/paren balance of all Kotlin files; XML well-formedness of manifest and resources; every `com.jarvis.ai.*` import resolves to a declared symbol (R and BuildConfig are generated); every container member used by the UI exists; no duplicate public functions; app-name matching thresholds, offline command patterns and the confirmation-risk classifier were simulated in Python against realistic inputs.
- `app/src/test/.../TextMatchTest.kt` is included but was not executed.
