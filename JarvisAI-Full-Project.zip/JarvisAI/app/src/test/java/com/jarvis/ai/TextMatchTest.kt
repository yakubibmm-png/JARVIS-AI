package com.jarvis.ai

import com.jarvis.ai.util.TextMatch
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Run with: ./gradlew test. Mirrors the cases used to tune the app-name matching thresholds. */
class TextMatchTest {
    @Test fun exactNameIsPerfect() = assertEquals(100, TextMatch.score("whatsapp", "WhatsApp"))
    @Test fun spacingIsIgnored() = assertEquals(100, TextMatch.score("face book", "Facebook"))
    @Test fun exactBeatsLongerName() = assertTrue(TextMatch.score("whatsapp", "WhatsApp") > TextMatch.score("whatsapp", "WhatsApp Business"))
    @Test fun speechSlipStillMatches() = assertTrue(TextMatch.score("what's up", "WhatsApp") >= 70)
    @Test fun typoStillMatches() = assertTrue(TextMatch.score("spotfy", "Spotify") >= 70)
    @Test fun prefixMatches() = assertTrue(TextMatch.score("insta", "Instagram") >= 70)
    @Test fun unrelatedDoesNotMatch() = assertTrue(TextMatch.score("netflix", "WhatsApp") < 70)
    @Test fun accentsIgnored() = assertEquals(100, TextMatch.score("cafe", "Café"))
}
