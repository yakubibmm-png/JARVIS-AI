package com.jarvis.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object JarvisColors {
    val BgTop = Color(0xFF040C26)
    val Bg = Color(0xFF020817)
    val BgBottom = Color(0xFF01050F)
    val Card = Color(0xFF071533)
    val CardHi = Color(0xFF0B1F4A)
    val Cyan: Color get() = Accent.cyan
    val Neon: Color get() = Accent.neon
    val Blue = Color(0xFF2563EB)
    val Purple = Color(0xFF8B5CF6)
    val Magenta = Color(0xFFD946EF)
    val Gold = Color(0xFFFBBF24)
    val Success = Color(0xFF22C55E)
    val Danger = Color(0xFFF87171)
    val Text = Color(0xFFFFFFFF)
    val TextDim = Color(0xFF8FA3C7)
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = JarvisColors.Cyan, secondary = JarvisColors.Blue, tertiary = JarvisColors.Purple,
        background = JarvisColors.Bg, surface = JarvisColors.Card, onPrimary = Color.Black,
        onBackground = JarvisColors.Text, onSurface = JarvisColors.Text,
    )
    val d = androidx.compose.ui.platform.LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(d.density, d.fontScale * Appearance.fontScale),
    ) { MaterialTheme(colorScheme = scheme, content = content) }
}
