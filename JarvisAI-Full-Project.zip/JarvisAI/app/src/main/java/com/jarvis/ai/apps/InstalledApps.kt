package com.jarvis.ai.apps

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.jarvis.ai.util.TextMatch

data class AppInfo(val label: String, val pkg: String)

sealed interface AppMatch {
    data class Found(val app: AppInfo, val score: Int) : AppMatch
    data class Ambiguous(val apps: List<AppInfo>) : AppMatch
    data class None(val closest: List<AppInfo>) : AppMatch
}

/**
 * Live list of every app with a launcher icon. Nothing about specific apps is hard-coded: a newly installed app is
 * found automatically (the list refreshes on install/uninstall broadcasts and every minute).
 */
class InstalledApps(private val ctx: Context) {
    @Volatile private var cache: List<AppInfo> = emptyList()
    @Volatile private var at = 0L

    fun invalidate() { at = 0L }

    @Suppress("DEPRECATION")
    fun all(): List<AppInfo> {
        if (System.currentTimeMillis() - at < TTL && cache.isNotEmpty()) return cache
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = if (Build.VERSION.SDK_INT >= 33) pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        else pm.queryIntentActivities(intent, 0)
        cache = list.map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != ctx.packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        at = System.currentTimeMillis()
        return cache
    }

    @Suppress("DEPRECATION")
    fun isInstalled(pkg: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) ctx.packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
        else ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) { false }

    @Suppress("DEPRECATION")
    fun firstInstallTime(pkg: String): Long = try {
        if (Build.VERSION.SDK_INT >= 33) ctx.packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0)).firstInstallTime
        else ctx.packageManager.getPackageInfo(pkg, 0).firstInstallTime
    } catch (e: PackageManager.NameNotFoundException) { 0L }

    fun labelOf(pkg: String): String? = try {
        ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) { null }

    fun launchIntent(pkg: String): Intent? = ctx.packageManager.getLaunchIntentForPackage(pkg)

    private fun scoreOf(query: String, app: AppInfo): Int {
        val byLabel = TextMatch.score(query, app.label)
        // package tail, e.g. "whatsapp" from com.whatsapp, helps when the label is localized
        val tail = app.pkg.substringAfterLast('.')
        val byPkg = if (tail.length >= 4) TextMatch.score(query, tail) - 8 else 0
        return maxOf(byLabel, byPkg)
    }

    fun resolve(query: String): AppMatch {
        val scored = all().map { it to scoreOf(query, it) }.sortedByDescending { it.second }
        val best = scored.firstOrNull()
        if (best == null || best.second < FOUND_MIN) {
            return AppMatch.None(scored.filter { it.second >= 45 }.take(3).map { it.first })
        }
        val near = scored.filter { it.second >= FOUND_MIN && it.second >= best.second - 6 }
        return if (near.size > 1 && !(best.second == 100 && near.count { it.second == 100 } == 1)) AppMatch.Ambiguous(near.take(4).map { it.first })
        else AppMatch.Found(best.first, best.second)
    }

    companion object {
        const val FOUND_MIN = 70
        private const val TTL = 60_000L
    }
}
