package com.jarvis.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun SectionTitle(text: String, sub: String? = null) {
    Column {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (sub != null) Text(sub, color = JarvisColors.TextDim, fontSize = 12.sp)
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean = true) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            if (subtitle != null) Text(subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked, onChange, enabled = enabled, colors = SwitchDefaults.colors(checkedTrackColor = JarvisColors.Blue, checkedThumbColor = Color.White))
    }
}

@Composable
fun Pill(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, color = Color.White, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) JarvisColors.Blue else JarvisColors.BgTop)
            .border(1.dp, if (selected) JarvisColors.Cyan else JarvisColors.Blue.copy(alpha = 0.5f), RoundedCornerShape(50))
            .clickable(role = Role.Button, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

/** Options laid out in rows of [columns]; [options] are (value, label). */
@Composable
fun ChipGrid(options: List<Pair<String, String>>, selected: String?, columns: Int = 3, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(columns).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { (v, l) -> Pill(l, v == selected) { onSelect(v) } } }
        }
    }
}

@Composable
fun LabeledField(value: String, onChange: (String) -> Unit, label: String, hint: String = "", modifier: Modifier = Modifier, singleLine: Boolean = true) {
    Column(modifier) {
        Text(label, color = JarvisColors.TextDim, fontSize = 12.sp)
        OutlinedTextField(value, onChange, singleLine = singleLine, placeholder = { Text(hint) }, colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun StatusText(on: Boolean, onText: String = "ON", offText: String = "OFF") {
    Text(if (on) onText else offText, color = if (on) JarvisColors.Success else JarvisColors.Danger, fontWeight = FontWeight.Bold, fontSize = 12.sp)
}

@Composable
fun Disclosure(title: String, body: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = JarvisColors.Card,
        title = { Text(title, color = Color.White) }, text = { Text(body, color = JarvisColors.TextDim, fontSize = 13.sp) },
        confirmButton = { TextButton(onConfirm) { Text(confirm, color = JarvisColors.Cyan) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = JarvisColors.TextDim) } },
    )
}

/** Increments every time the screen returns to the foreground, so permission/service statuses re-check themselves. */
@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
fun SmallSpacer() = Spacer(Modifier.height(6.dp))
