package com.jarvis.ai.ui.screens

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.data.Languages
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.ChipGrid
import com.jarvis.ai.ui.components.Disclosure
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.LabeledField
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.SectionTitle
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun PreferencesScreen(onBack: () -> Unit, onOpenVoicePack: () -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val prefs = c.prefs
    var brain by remember { mutableStateOf(prefs.brainMode) }
    var mode by remember { mutableStateOf(prefs.personalityMode) }
    var lang by remember { mutableStateOf(prefs.replyLanguage) }
    var custom by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }

    ScreenScaffold("Preferences", "Customize your AI experience", onBack) {
        GlassCard {
            SectionTitle("Voice Brain", "Balanced: normal. Compact: shorter and faster. Full: more detail.")
            Spacer(Modifier.height(8.dp))
            ChipGrid(listOf("BALANCED" to "Balanced", "COMPACT" to "Compact", "FULL" to "Full"), brain) { brain = it; prefs.brainMode = it }
        }
        GlassCard {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { confirmClear = true }, verticalAlignment = Alignment.CenterVertically) {
                GlowIcon(Icons.Filled.DeleteSweep, JarvisColors.Danger, size = 40.dp)
                Spacer(Modifier.width(12.dp))
                androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                    Text("Clear Memory", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Remove all chats and what JARVIS remembers about recent actions", color = JarvisColors.TextDim, fontSize = 12.sp)
                }
                Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { VoicePackNav.initialTab = 3; onOpenVoicePack() }, verticalAlignment = Alignment.CenterVertically) {
                GlowIcon(Icons.Filled.Mic, JarvisColors.Neon, size = 40.dp)
                Spacer(Modifier.width(12.dp))
                androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                    Text("Record Sample", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text("Record your voice to create My Voice", color = JarvisColors.TextDim, fontSize = 12.sp)
                }
                Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim)
            }
        }
        GlassCard {
            SectionTitle("Mode", "How JARVIS talks to you")
            Spacer(Modifier.height(8.dp))
            ChipGrid(listOf("CARE" to "Care Mode", "BOSS" to "Boss Mode", "FRIEND" to "Friend Mode"), mode, columns = 3) { mode = it; prefs.personalityMode = it }
        }
        GlassCard {
            SectionTitle("Language Mirror", "JARVIS answers in this language. Auto follows the language you use. It also sets the speech-recognition language.")
            Spacer(Modifier.height(8.dp))
            ChipGrid(listOf("" to "Auto (mirror me)") + Languages.all.map { it.tag to it.name }, lang, columns = 2) {
                lang = it; prefs.replyLanguage = it; prefs.speechLocaleTag = it
            }
            Spacer(Modifier.height(10.dp))
            val known = Languages.all.any { it.tag == lang } || lang.isEmpty()
            if (!known) Text("Current: ${Languages.nameFor(lang)} ($lang)", color = JarvisColors.Cyan, fontSize = 12.sp)
            LabeledField(custom, { custom = it }, "More languages: add any language tag", "e.g. sw-KE or nl-NL")
            Spacer(Modifier.height(6.dp))
            NeonButton("Use this language", {
                val t = custom.trim()
                if (java.util.Locale.forLanguageTag(t).language.isBlank()) Toast.makeText(ctx, "That doesn't look like a language tag.", Toast.LENGTH_SHORT).show()
                else { lang = t; prefs.replyLanguage = t; prefs.speechLocaleTag = t; custom = "" }
            }, Modifier.fillMaxWidth(), filled = false, enabled = custom.isNotBlank())
        }
    }
    if (confirmClear) Disclosure(
        "Clear memory?", "All conversations and JARVIS's short-term memory of recent actions will be deleted from this phone. Saved reminders, shortcuts and settings are kept.", "Clear",
        { c.chatRepository.clearAll(); c.actionMemory.clear(); confirmClear = false; Toast.makeText(ctx, "Memory cleared", Toast.LENGTH_SHORT).show() }, { confirmClear = false },
    )
}
