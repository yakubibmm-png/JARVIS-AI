package com.jarvis.ai.ui.screens

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.data.CredentialsRepository
import com.jarvis.ai.data.ModelCategory
import com.jarvis.ai.data.ModelRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class KeyStatus { EMPTY, SAVED, INCOMPLETE }

/**
 * One masked key input with automatic persistence (no SAVE button): a valid-looking key is saved ~0.4 s after
 * the last edit, an empty field removes the key. Whitespace from pasting is stripped. Never logs the value.
 */
class KeyField(
    private val scope: CoroutineScope,
    initial: String,
    private val minLength: Int,
    private val persist: (String) -> Unit,
) {
    var text by mutableStateOf(initial); private set
    var visible by mutableStateOf(false); private set
    var status by mutableStateOf(if (initial.isBlank()) KeyStatus.EMPTY else KeyStatus.SAVED); private set
    private var job: Job? = null
    private var pending: String? = null

    fun onChange(raw: String) {
        val v = raw.filterNot { it.isWhitespace() }
        text = v
        job?.cancel(); pending = null
        when {
            v.isEmpty() -> { persist(""); status = KeyStatus.EMPTY }
            v.length < minLength -> status = KeyStatus.INCOMPLETE
            else -> {
                pending = v
                job = scope.launch {
                    delay(400)
                    persist(v); pending = null; status = KeyStatus.SAVED
                }
            }
        }
    }

    fun toggleVisible() { visible = !visible }

    /** Called when leaving the screen so a just-pasted key is never lost. */
    fun flush() { pending?.let { persist(it); status = KeyStatus.SAVED; pending = null } }
}

class ApiKeyViewModel(creds: CredentialsRepository, val models: ModelRepository) : ViewModel() {
    val gemini = KeyField(viewModelScope, creds.geminiKey.value, 20) { creds.setGeminiKey(it) }
    val eleven = KeyField(viewModelScope, creds.elevenLabsKey.value, 16) { creds.setElevenLabsKey(it) }

    var category by mutableStateOf(models.categoryOf(models.selectedId.value))
    var customDraft by mutableStateOf("")
    var customError by mutableStateOf<String?>(null)

    fun pickCategory(c: ModelCategory) { category = c }

    fun applyCustom() { customError = models.selectCustom(customDraft); if (customError == null) customDraft = "" }

    override fun onCleared() { gemini.flush(); eleven.flush() }
}
