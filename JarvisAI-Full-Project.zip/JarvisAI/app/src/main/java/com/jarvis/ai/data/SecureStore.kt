package com.jarvis.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.GeneralSecurityException

/** Encrypted key/value storage (AES-256, Android Keystore backed) for API keys and the Premium entitlement. */
class SecureStore(context: Context) {
    private val prefs: SharedPreferences = create(context.applicationContext)

    fun getString(key: String, default: String = ""): String = prefs.getString(key, default) ?: default
    fun putString(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun getBoolean(key: String, default: Boolean = false): Boolean = prefs.getBoolean(key, default)
    fun putBoolean(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()
    fun getLong(key: String, default: Long = 0L): Long = prefs.getLong(key, default)
    fun putLong(key: String, value: Long) = prefs.edit().putLong(key, value).apply()
    fun remove(key: String) = prefs.edit().remove(key).apply()

    private companion object {
        const val FILE = "jarvis_secure"

        fun create(ctx: Context): SharedPreferences = try {
            build(ctx)
        } catch (e: GeneralSecurityException) {
            // Keystore invalidated (e.g. restored device). Start clean rather than crash.
            ctx.deleteSharedPreferences(FILE)
            build(ctx)
        } catch (e: java.io.IOException) {
            ctx.deleteSharedPreferences(FILE)
            build(ctx)
        }

        fun build(ctx: Context): SharedPreferences {
            val masterKey = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                ctx, FILE, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        }
    }
}
