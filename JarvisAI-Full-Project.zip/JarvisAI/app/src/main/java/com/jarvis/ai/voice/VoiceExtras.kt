package com.jarvis.ai.voice

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.util.isOnline
import com.jarvis.ai.util.withConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URLEncoder
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

data class VoiceOption(val id: String, val name: String, val trait: String, val categories: Set<String>)

/**
 * Voice Pack presets. Gemini names are Gemini's built-in voices; the ElevenLabs entries are ElevenLabs' standard
 * voices. Availability depends on the provider and your account: if one isn't available the call fails with a clear
 * message and JARVIS falls back to the device voice. You can always paste any ElevenLabs voice ID yourself.
 */
object VoiceCatalog {
    const val GIRLS = "Girls Voice"; const val BOYS = "Boys Voice"; const val DEEP = "Deep Voice"; const val BEAUTIFUL = "Beautiful Voice"
    const val CUTE = "Cute Voice"; const val SOFT = "Soft Voice"; const val NATURAL = "Natural Voice"; const val PRO = "Professional Voice"
    val categories = listOf(GIRLS, BOYS, DEEP, BEAUTIFUL, CUTE, SOFT, NATURAL, PRO)

    val gemini = listOf(
        VoiceOption("Zephyr", "Zephyr", "Bright", setOf(GIRLS, CUTE)), VoiceOption("Leda", "Leda", "Youthful", setOf(GIRLS, CUTE)),
        VoiceOption("Aoede", "Aoede", "Breezy", setOf(GIRLS, CUTE, NATURAL)), VoiceOption("Laomedeia", "Laomedeia", "Upbeat", setOf(GIRLS, CUTE)),
        VoiceOption("Kore", "Kore", "Firm", setOf(GIRLS, PRO)), VoiceOption("Gacrux", "Gacrux", "Mature", setOf(GIRLS, PRO)),
        VoiceOption("Callirrhoe", "Callirrhoe", "Easy-going", setOf(GIRLS, NATURAL)), VoiceOption("Achernar", "Achernar", "Soft", setOf(GIRLS, SOFT, BEAUTIFUL)),
        VoiceOption("Vindemiatrix", "Vindemiatrix", "Gentle", setOf(GIRLS, SOFT, BEAUTIFUL)), VoiceOption("Sulafat", "Sulafat", "Warm", setOf(GIRLS, BEAUTIFUL, NATURAL)),
        VoiceOption("Puck", "Puck", "Upbeat", setOf(BOYS, NATURAL)), VoiceOption("Fenrir", "Fenrir", "Excitable", setOf(BOYS, NATURAL)),
        VoiceOption("Achird", "Achird", "Friendly", setOf(BOYS, NATURAL)), VoiceOption("Charon", "Charon", "Informative", setOf(BOYS, DEEP, PRO)),
        VoiceOption("Orus", "Orus", "Firm", setOf(BOYS, DEEP)), VoiceOption("Algenib", "Algenib", "Gravelly", setOf(BOYS, DEEP)),
        VoiceOption("Alnilam", "Alnilam", "Firm", setOf(BOYS, DEEP, PRO)), VoiceOption("Rasalgethi", "Rasalgethi", "Informative", setOf(BOYS, PRO)),
        VoiceOption("Schedar", "Schedar", "Even", setOf(BOYS, PRO, NATURAL)), VoiceOption("Sadaltager", "Sadaltager", "Knowledgeable", setOf(BOYS, PRO)),
        VoiceOption("Enceladus", "Enceladus", "Breathy", setOf(BOYS, SOFT)),
    )

    val eleven = listOf(
        VoiceOption("21m00Tcm4TlvDq8ikWAM", "Rachel", "Calm", setOf(GIRLS, BEAUTIFUL, NATURAL, PRO)),
        VoiceOption("EXAVITQu4vr4xnSDxMaL", "Bella", "Soft", setOf(GIRLS, SOFT, BEAUTIFUL)),
        VoiceOption("MF3mGyEYCl7XYWbV9V6O", "Elli", "Young", setOf(GIRLS, CUTE)),
        VoiceOption("AZnzlk1XvdvUeBnXmlld", "Domi", "Strong", setOf(GIRLS, PRO)),
        VoiceOption("ErXwobaYiN019PkySvjV", "Antoni", "Well-rounded", setOf(BOYS, NATURAL)),
        VoiceOption("TxGEqnHWrfWFTfGW9XjX", "Josh", "Deep", setOf(BOYS, DEEP)),
        VoiceOption("VR6AewLTigWG4xSOukaG", "Arnold", "Crisp", setOf(BOYS, PRO)),
        VoiceOption("pNInz6obpgDQGcFmaJgB", "Adam", "Deep narration", setOf(BOYS, DEEP, PRO)),
        VoiceOption("yoZ06aMxZJJ28mfd3POQ", "Sam", "Raspy", setOf(BOYS, NATURAL)),
    )
}

data class MyVoice(val id: String, val name: String)

/** Voices the user created with "My Voice" (stored on the device; the audio lives with ElevenLabs). */
class MyVoices(private val prefs: AppPrefs) {
    fun all(): List<MyVoice> = runCatching {
        val a = JSONArray(prefs.myVoicesJson); (0 until a.length()).map { a.getJSONObject(it).let { o -> MyVoice(o.getString("id"), o.getString("name")) } }
    }.getOrDefault(emptyList())
    fun add(v: MyVoice) = save(all() + v)
    fun remove(id: String) = save(all().filterNot { it.id == id })
    private fun save(l: List<MyVoice>) { val a = JSONArray(); l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name)) }; prefs.myVoicesJson = a.toString() }
}

/** Records the microphone to a 16 kHz mono WAV (for Voice Changer and My Voice samples). Needs the microphone permission. */
class WavRecorder {
    @Volatile private var stopRequested = false
    fun stop() { stopRequested = true }

    suspend fun record(maxSeconds: Int, onLevel: (Float) -> Unit): ByteArray? = withContext(Dispatchers.IO) {
        val rate = 16_000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try { AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, rate)) } catch (e: Exception) { return@withContext null }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return@withContext null }
        stopRequested = false
        val out = ByteArrayOutputStream()
        val buf = ByteArray(3200)
        try {
            rec.startRecording()
            val end = System.currentTimeMillis() + maxSeconds * 1000L
            while (!stopRequested && isActive && System.currentTimeMillis() < end) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) { out.write(buf, 0, n); onLevel(level(buf, n)) }
            }
        } catch (e: Exception) {
            return@withContext null
        } finally {
            runCatching { rec.stop() }; rec.release(); onLevel(0f)
        }
        val pcm = out.toByteArray()
        if (pcm.size < rate) null else wav(pcm, rate)
    }

    private fun level(b: ByteArray, n: Int): Float {
        var sum = 0.0; var i = 0
        while (i + 1 < n) { val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt(); sum += s.toDouble() * s; i += 2 }
        return (sqrt(sum / (n / 2).coerceAtLeast(1)) / 32768.0 / 0.2).coerceIn(0.0, 1.0).pow(0.7).toFloat()
    }

    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val h = ByteArray(44)
        fun i32(o: Int, v: Int) { h[o] = v.toByte(); h[o + 1] = (v shr 8).toByte(); h[o + 2] = (v shr 16).toByte(); h[o + 3] = (v shr 24).toByte() }
        fun i16(o: Int, v: Int) { h[o] = v.toByte(); h[o + 1] = (v shr 8).toByte() }
        "RIFF".toByteArray().copyInto(h, 0); i32(4, 36 + pcm.size); "WAVEfmt ".toByteArray().copyInto(h, 8)
        i32(16, 16); i16(20, 1); i16(22, 1); i32(24, rate); i32(28, rate * 2); i16(32, 2); i16(34, 16)
        "data".toByteArray().copyInto(h, 36); i32(40, pcm.size)
        return h + pcm
    }
}

class UploadFile(val field: String, val filename: String, val mime: String, val bytes: ByteArray)

/** ElevenLabs endpoints beyond text-to-speech: Voice Changer (speech-to-speech) and My Voice (create / delete). */
class ElevenLabsApi(private val ctx: Context) {
    private fun multipart(fields: Map<String, String>, files: List<UploadFile>): Pair<String, ByteArray> {
        val boundary = "----jarvis" + System.nanoTime()
        val out = ByteArrayOutputStream()
        fun w(s: String) = out.write(s.toByteArray(Charsets.UTF_8))
        fields.forEach { (k, v) -> w("--$boundary\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n") }
        files.forEach { f ->
            w("--$boundary\r\nContent-Disposition: form-data; name=\"${f.field}\"; filename=\"${f.filename}\"\r\nContent-Type: ${f.mime}\r\n\r\n")
            out.write(f.bytes); w("\r\n")
        }
        w("--$boundary--\r\n")
        return "multipart/form-data; boundary=$boundary" to out.toByteArray()
    }

    private fun failure(code: Int) = VoiceProviderException(
        when (code) {
            401 -> "ElevenLabs rejected your API key."
            402, 403 -> "Your ElevenLabs plan doesn't allow this (creating voices needs a paid plan)."
            404 -> "ElevenLabs couldn't find that voice."
            422 -> "ElevenLabs couldn't use that audio (too short, too noisy or an unsupported format)."
            429 -> "ElevenLabs is rate-limiting requests."
            else -> "ElevenLabs is unavailable right now."
        },
    )

    private fun requireOnline() { if (!ctx.isOnline()) throw VoiceProviderException("You're offline. This feature needs an internet connection.") }

    /** Streams the converted voice as 24 kHz PCM chunks. */
    suspend fun speechToSpeech(key: String, voiceId: String, wav: ByteArray, onChunk: (ByteArray, Int) -> Unit) {
        requireOnline()
        val (type, body) = multipart(mapOf("model_id" to "eleven_multilingual_sts_v2"), listOf(UploadFile("audio", "voice.wav", "audio/wav", wav)))
        try {
            withConnection("$BASE/speech-to-speech/${URLEncoder.encode(voiceId, "UTF-8")}/stream?output_format=pcm_24000", { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 60_000; c.doOutput = true
                c.setRequestProperty("Content-Type", type); c.setRequestProperty("xi-api-key", key)
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) { c.errorStream?.close(); throw failure(code) }
                val buf = ByteArray(4096)
                c.inputStream.use { i -> while (true) { val n = i.read(buf); if (n < 0) break; if (n > 0) onChunk(buf, n) } }
            }
        } catch (e: IOException) { throw VoiceProviderException("ElevenLabs couldn't be reached.") }
    }

    /** Creates a voice from audio samples. Returns the new voice ID. */
    suspend fun addVoice(key: String, name: String, files: List<UploadFile>): String {
        requireOnline()
        val (type, body) = multipart(mapOf("name" to name, "description" to "Created in JARVIS AI by the voice's owner"), files)
        try {
            return withConnection("$BASE/voices/add", { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 120_000; c.doOutput = true
                c.setRequestProperty("Content-Type", type); c.setRequestProperty("xi-api-key", key)
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) { c.errorStream?.close(); throw failure(code) }
                JSONObject(c.inputStream.bufferedReader().use { it.readText() }).optString("voice_id").ifEmpty { throw VoiceProviderException("ElevenLabs didn't return a voice.") }
            }
        } catch (e: IOException) { throw VoiceProviderException("ElevenLabs couldn't be reached.") }
    }

    suspend fun deleteVoice(key: String, voiceId: String) {
        requireOnline()
        try {
            withConnection("$BASE/voices/${URLEncoder.encode(voiceId, "UTF-8")}", { c -> c.requestMethod = "DELETE"; c.connectTimeout = 15_000; c.readTimeout = 30_000; c.setRequestProperty("xi-api-key", key) }) { c ->
                val code = c.responseCode
                c.errorStream?.close()
                if (code !in 200..299 && code != 404) throw failure(code)
            }
        } catch (e: IOException) { throw VoiceProviderException("ElevenLabs couldn't be reached.") }
    }

    private companion object { const val BASE = "https://api.elevenlabs.io/v1" }
}
