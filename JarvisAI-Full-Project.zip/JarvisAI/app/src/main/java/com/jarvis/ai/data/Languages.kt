package com.jarvis.ai.data

data class Language(val name: String, val tag: String)

/** Language Mirror options. "Auto" (empty) mirrors whatever language the user speaks or types. Custom tags can be added in Preferences. */
object Languages {
    val all = listOf(
        Language("Bengali", "bn-BD"), Language("Hindi", "hi-IN"), Language("English", "en-US"), Language("Arabic", "ar-SA"),
        Language("Portuguese", "pt-BR"), Language("Spanish", "es-ES"), Language("Russian", "ru-RU"), Language("Filipino / Tagalog", "fil-PH"),
        Language("Indonesian", "id-ID"), Language("Chinese", "zh-CN"), Language("Japanese", "ja-JP"), Language("Korean", "ko-KR"),
        Language("Turkish", "tr-TR"), Language("Urdu", "ur-PK"), Language("French", "fr-FR"), Language("German", "de-DE"),
        Language("Italian", "it-IT"), Language("Thai", "th-TH"), Language("Vietnamese", "vi-VN"),
    )
    fun nameFor(tag: String): String = all.firstOrNull { it.tag == tag }?.name
        ?: java.util.Locale.forLanguageTag(tag).getDisplayName(java.util.Locale.ENGLISH).ifBlank { tag }
}
