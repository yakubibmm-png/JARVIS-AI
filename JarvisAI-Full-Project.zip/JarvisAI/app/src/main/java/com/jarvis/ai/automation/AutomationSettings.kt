package com.jarvis.ai.automation

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class ReplyRule(val keyword: String, val reply: String)
data class ReplyLogEntry(val at: Long, val contact: String, val incoming: String, val reply: String, val status: String)

/**
 * Everything the user controls about automation. Nothing here runs unless [enabled] (the master switch) is ON
 * and the user has Pro. Turning the master switch off stops Auto Reply, tasks, triggers and screen control at once.
 */
class AutomationSettings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("jarvis_automation", Context.MODE_PRIVATE)

    private val _enabled = MutableStateFlow(sp.getBoolean("enabled", false))
    val enabled: StateFlow<Boolean> = _enabled.asStateFlow()
    fun setEnabled(v: Boolean) { sp.edit().putBoolean("enabled", v).apply(); _enabled.value = v }

    private val _autoReply = MutableStateFlow(sp.getBoolean("auto_reply", false))
    val autoReplyEnabled: StateFlow<Boolean> = _autoReply.asStateFlow()
    fun setAutoReply(v: Boolean) { sp.edit().putBoolean("auto_reply", v).apply(); _autoReply.value = v }

    /** FIXED = one reply, RULES = keyword rules then the default, AI = Gemini writes it. */
    var replyMode: String
        get() = sp.getString("reply_mode", "FIXED") ?: "FIXED"
        set(v) = sp.edit().putString("reply_mode", v).apply()
    var defaultReply: String
        get() = sp.getString("default_reply", "I'll get back to you soon.") ?: ""
        set(v) = sp.edit().putString("default_reply", v).apply()
    var replyStyle: String
        get() = sp.getString("reply_style", "Friendly, short and natural.") ?: ""
        set(v) = sp.edit().putString("reply_style", v).apply()
    var allowGroups: Boolean
        get() = sp.getBoolean("allow_groups", false)
        set(v) = sp.edit().putBoolean("allow_groups", v).apply()
    var onlyContacts: Boolean
        get() = sp.getBoolean("only_contacts", true)
        set(v) = sp.edit().putBoolean("only_contacts", v).apply()
    var aiFallback: Boolean
        get() = sp.getBoolean("ai_fallback", true)
        set(v) = sp.edit().putBoolean("ai_fallback", v).apply()
    var cooldownSec: Int
        get() = sp.getInt("cooldown_sec", 120)
        set(v) = sp.edit().putInt("cooldown_sec", v).apply()

    private val _rules = MutableStateFlow(readRules())
    val rules: StateFlow<List<ReplyRule>> = _rules.asStateFlow()
    fun addRule(r: ReplyRule) = saveRules(_rules.value + r)
    fun removeRule(r: ReplyRule) = saveRules(_rules.value - r)
    private fun saveRules(l: List<ReplyRule>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("k", it.keyword).put("r", it.reply)) }
        sp.edit().putString("rules", a.toString()).apply(); _rules.value = l
    }
    private fun readRules() = runCatching {
        val a = JSONArray(sp.getString("rules", "[]")); (0 until a.length()).map { a.getJSONObject(it).let { o -> ReplyRule(o.getString("k"), o.getString("r")) } }
    }.getOrDefault(emptyList())

    private val _log = MutableStateFlow(readLog())
    val log: StateFlow<List<ReplyLogEntry>> = _log.asStateFlow()
    @Synchronized fun addLog(e: ReplyLogEntry) {
        val l = (listOf(e) + _log.value).take(50)
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("t", it.at).put("c", it.contact).put("i", it.incoming).put("r", it.reply).put("s", it.status)) }
        sp.edit().putString("log", a.toString()).apply(); _log.value = l
    }
    fun clearLog() { sp.edit().remove("log").apply(); _log.value = emptyList() }
    private fun readLog() = runCatching {
        val a = JSONArray(sp.getString("log", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> ReplyLogEntry(o.getLong("t"), o.getString("c"), o.getString("i"), o.getString("r"), o.getString("s")) } }
    }.getOrDefault(emptyList())
}

data class AutoTask(val id: Int, val label: String, val command: String, val triggerAt: Long, val repeat: String, val launchPkg: String?)
data class SmartTrigger(val id: Int, val event: String, val command: String)
data class CustomAction(val id: Int, val name: String, val command: String)

/** User-defined tasks, smart triggers and custom actions (all stored on the device). */
class AutomationItems(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("jarvis_automation_items", Context.MODE_PRIVATE)

    private val _tasks = MutableStateFlow(readTasks()); val tasks: StateFlow<List<AutoTask>> = _tasks.asStateFlow()
    private val _triggers = MutableStateFlow(readTriggers()); val triggers: StateFlow<List<SmartTrigger>> = _triggers.asStateFlow()
    private val _actions = MutableStateFlow(readActions()); val actions: StateFlow<List<CustomAction>> = _actions.asStateFlow()

    private fun nextId(): Int { val n = sp.getInt("next", 1); sp.edit().putInt("next", n + 1).apply(); return n }

    @Synchronized fun addTask(label: String, command: String, at: Long, repeat: String, pkg: String?): AutoTask {
        val t = AutoTask(nextId(), label, command, at, repeat, pkg); saveTasks(_tasks.value + t); return t
    }
    @Synchronized fun updateTask(t: AutoTask) = saveTasks(_tasks.value.map { if (it.id == t.id) t else it })
    @Synchronized fun removeTask(id: Int) = saveTasks(_tasks.value.filterNot { it.id == id })
    fun task(id: Int) = _tasks.value.firstOrNull { it.id == id }

    @Synchronized fun addTrigger(event: String, command: String) = saveTriggers(_triggers.value + SmartTrigger(nextId(), event, command))
    @Synchronized fun removeTrigger(id: Int) = saveTriggers(_triggers.value.filterNot { it.id == id })

    @Synchronized fun addAction(name: String, command: String) = saveActions(_actions.value + CustomAction(nextId(), name, command))
    @Synchronized fun removeAction(id: Int) = saveActions(_actions.value.filterNot { it.id == id })

    private fun saveTasks(l: List<AutoTask>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("i", it.id).put("l", it.label).put("c", it.command).put("t", it.triggerAt).put("r", it.repeat).put("p", it.launchPkg ?: "")) }
        sp.edit().putString("tasks", a.toString()).apply(); _tasks.value = l.sortedBy { it.triggerAt }
    }
    private fun saveTriggers(l: List<SmartTrigger>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("i", it.id).put("e", it.event).put("c", it.command)) }
        sp.edit().putString("triggers", a.toString()).apply(); _triggers.value = l
    }
    private fun saveActions(l: List<CustomAction>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("i", it.id).put("n", it.name).put("c", it.command)) }
        sp.edit().putString("actions", a.toString()).apply(); _actions.value = l
    }
    private fun readTasks() = runCatching {
        val a = JSONArray(sp.getString("tasks", "[]"))
        (0 until a.length()).map { a.getJSONObject(it).let { o -> AutoTask(o.getInt("i"), o.getString("l"), o.getString("c"), o.getLong("t"), o.getString("r"), o.optString("p").ifEmpty { null }) } }
    }.getOrDefault(emptyList())
    private fun readTriggers() = runCatching {
        val a = JSONArray(sp.getString("triggers", "[]")); (0 until a.length()).map { a.getJSONObject(it).let { o -> SmartTrigger(o.getInt("i"), o.getString("e"), o.getString("c")) } }
    }.getOrDefault(emptyList())
    private fun readActions() = runCatching {
        val a = JSONArray(sp.getString("actions", "[]")); (0 until a.length()).map { a.getJSONObject(it).let { o -> CustomAction(o.getInt("i"), o.getString("n"), o.getString("c")) } }
    }.getOrDefault(emptyList())
}
