package com.jarvis.ai.command

import org.json.JSONArray
import org.json.JSONObject

/** One phone capability exposed to Gemini as a function. Adding a capability = add a ToolSpec + a handler. */
class ToolSpec(
    val name: String,
    val intent: JarvisIntent,
    val description: String,
    val properties: Map<String, JSONObject> = emptyMap(),
    val required: List<String> = emptyList(),
    /** Starts another app's screen (so JARVIS leaves the foreground). At most one per request. */
    val launchesApp: Boolean = false,
    /** Phase 4: direct (non-draft) sending/calling must ask the user first. */
    val needsConfirmation: Boolean = false,
)

object ToolSpecs {
    private fun str(desc: String, vararg options: String) = JSONObject().put("type", "string").put("description", desc).also {
        if (options.isNotEmpty()) it.put("enum", JSONArray(options.toList()))
    }
    private fun int(desc: String) = JSONObject().put("type", "integer").put("description", desc)
    private fun bool(desc: String) = JSONObject().put("type", "boolean").put("description", desc)
    private fun strList(desc: String) = JSONObject().put("type", "array").put("description", desc).put("items", JSONObject().put("type", "string"))

    val all: List<ToolSpec> = listOf(
        ToolSpec("open_app", JarvisIntent.OPEN_APP, "Open an installed app by its name. Works for any app installed on the phone.",
            mapOf("app_name" to str("Name of the app as the user said it, e.g. WhatsApp, Facebook, Camera, Calculator.")), listOf("app_name"), launchesApp = true),
        ToolSpec("install_app", JarvisIntent.INSTALL_APP, "Install an app: checks whether it is installed and, if not, opens its Google Play page so the user can tap Install.",
            mapOf("app_name" to str("App name, e.g. Spotify."), "package_name" to str("Android package ID ONLY if you are confident of it, e.g. com.spotify.music. Otherwise omit.")), listOf("app_name"), launchesApp = true),
        ToolSpec("search", JarvisIntent.SEARCH, "Search the web, or search inside a named app (YouTube, Maps, Spotify...).",
            mapOf("query" to str("What to search for."), "app_name" to str("Optional app to search in.")), listOf("query"), launchesApp = true),
        ToolSpec("open_url", JarvisIntent.OPEN_URL, "Open a web link (http or https) in the browser.",
            mapOf("url" to str("Full https URL.")), listOf("url"), launchesApp = true),
        ToolSpec("set_reminder", JarvisIntent.SET_REMINDER, "Create a reminder that shows a notification at a given time.",
            mapOf(
                "message" to str("What to remind the user about, e.g. 'drink water'."),
                "datetime" to str("Absolute LOCAL date-time as yyyy-MM-ddTHH:mm:ss. Use this OR in_minutes."),
                "in_minutes" to int("Minutes from now. Use this OR datetime."),
                "repeat" to str("Repeat pattern.", "none", "daily", "weekly"),
            ), listOf("message")),
        ToolSpec("list_reminders", JarvisIntent.SET_REMINDER, "List the user's upcoming reminders."),
        ToolSpec("cancel_reminder", JarvisIntent.SET_REMINDER, "Cancel upcoming reminders whose message contains the given text.",
            mapOf("message_contains" to str("Part of the reminder message.")), listOf("message_contains")),
        ToolSpec("set_alarm", JarvisIntent.SET_ALARM, "Set an alarm in the phone's Clock app.",
            mapOf(
                "hour" to int("Hour 0-23."), "minute" to int("Minute 0-59."), "label" to str("Optional alarm label."),
                "days" to strList("Optional repeat days: mon, tue, wed, thu, fri, sat, sun."),
            ), listOf("hour", "minute")),
        ToolSpec("get_time", JarvisIntent.GET_TIME, "Get the current time and date, optionally in another time zone.",
            mapOf("timezone" to str("Optional IANA zone such as Asia/Tokyo. Omit for the phone's local time."))),
        ToolSpec("get_weather", JarvisIntent.GET_WEATHER, "Get real current weather and a short forecast. Omit location for the user's current location.",
            mapOf("location" to str("City or place name. Omit for the phone's location."))),
        ToolSpec("play_media", JarvisIntent.PLAY_MEDIA, "Play music or video matching a search, using a media app.",
            mapOf("query" to str("What to play, e.g. 'relaxing music' or 'Bengali songs'."), "app_name" to str("Optional media app to use."), "kind" to str("audio or video.", "audio", "video")), listOf("query"), launchesApp = true),
        ToolSpec("media_control", JarvisIntent.PLAY_MEDIA, "Control whatever media is currently playing.",
            mapOf("action" to str("Control action.", "play", "pause", "toggle", "next", "previous", "stop")), listOf("action")),
        ToolSpec("find_contact", JarvisIntent.CALL_CONTACT, "Look up contacts by name on this phone. Phone numbers are not returned.",
            mapOf("name" to str("Contact name.")), listOf("name")),
        ToolSpec("call_contact", JarvisIntent.CALL_CONTACT, "Prepare a phone call: opens the dialer with the contact's number (the user presses call).",
            mapOf("contact" to str("Contact name or phone number.")), listOf("contact"), launchesApp = true, needsConfirmation = true),
        ToolSpec("draft_message", JarvisIntent.SEND_MESSAGE, "Open a chat or SMS with a contact and prefill a message. The user must press Send.",
            mapOf(
                "contact" to str("Contact name or phone number."), "text" to str("Message text, if any."),
                "app_name" to str("Messaging app such as WhatsApp or Telegram; omit for SMS."),
            ), listOf("contact"), launchesApp = true, needsConfirmation = true),
        ToolSpec("open_settings", JarvisIntent.OPEN_SETTINGS, "Open a page of the phone's Settings.",
            mapOf("page" to str("Settings page.", "main", "wifi", "bluetooth", "display", "sound", "battery", "apps", "location", "notifications", "accessibility", "date", "storage", "airplane")), listOf("page"), launchesApp = true),
        ToolSpec("set_flashlight", JarvisIntent.UNKNOWN, "Turn the flashlight on or off.",
            mapOf("on" to bool("true to turn on, false to turn off.")), listOf("on")),
        ToolSpec("screen_action", JarvisIntent.TAP_ELEMENT, "Operate the screen of the app that is currently open (needs Accessibility, Pro and Automation ON). Use read_screen first when you need to know what is visible. 'send' presses the Send button for a message that is already typed; the user must confirm before it is sent.",
            mapOf(
                "action" to str("What to do.", "read_screen", "tap", "long_press", "type", "send", "scroll_down", "scroll_up", "back", "home", "recents"),
                "target" to str("Visible text or label of what to tap or which field to type in, e.g. 'Send' or 'Search'."),
                "ordinal" to int("1-based position in the main on-screen list: 2 for 'the second chat' or 'the second result'. Use instead of target."),
                "text" to str("Text to type (for action=type)."),
            ), listOf("action")),
        ToolSpec("screen_question", JarvisIntent.SCREEN_QUESTION, "Answer a question about what is on the user's screen right now (uses a screenshot if Screen Share is on, otherwise the readable text).",
            mapOf("question" to str("What the user wants to know about the screen.")), listOf("question")),
        ToolSpec("confirm_action", JarvisIntent.UNKNOWN, "Carry out or cancel the action that is waiting for the user's confirmation. Call it ONLY when the user's newest message clearly says yes (approve=true) or no (approve=false). Never call it in the same turn that created the pending action.",
            mapOf("approve" to bool("true to proceed, false to cancel.")), listOf("approve")),
        ToolSpec("run_custom_action", JarvisIntent.UNKNOWN, "Look up one of the user's saved custom actions by name. The result contains the command to carry out now with the other tools.",
            mapOf("name" to str("Name of the custom action.")), listOf("name")),
    )

    private val byName = all.associateBy { it.name }
    fun find(name: String): ToolSpec? = byName[name]

    fun declarations(): JSONArray = JSONArray().also { arr ->
        all.forEach { t ->
            val o = JSONObject().put("name", t.name).put("description", t.description)
            if (t.properties.isNotEmpty()) {
                val props = JSONObject(); t.properties.forEach { (k, v) -> props.put(k, v) }
                val params = JSONObject().put("type", "object").put("properties", props)
                if (t.required.isNotEmpty()) params.put("required", JSONArray(t.required))
                o.put("parameters", params)
            }
            arr.put(o)
        }
    }

    /** Used by the offline fallback parser to build the same calls Gemini would. */
    fun callFor(c: ParsedCommand): Pair<String, JSONObject>? = when (c.intent) {
        JarvisIntent.OPEN_APP -> "open_app" to JSONObject().put("app_name", c.app.orEmpty())
        JarvisIntent.INSTALL_APP -> "install_app" to JSONObject().put("app_name", c.app.orEmpty())
        JarvisIntent.GET_TIME -> "get_time" to JSONObject()
        JarvisIntent.GET_WEATHER -> "get_weather" to JSONObject().also { o -> c.query?.let { o.put("location", it) } }
        JarvisIntent.SEARCH -> "search" to JSONObject().put("query", c.query.orEmpty())
        JarvisIntent.PLAY_MEDIA -> "play_media" to JSONObject().put("query", c.query.orEmpty())
        JarvisIntent.SET_ALARM -> c.time?.split(":")?.takeIf { it.size == 2 }?.let { "set_alarm" to JSONObject().put("hour", it[0].toInt()).put("minute", it[1].toInt()) }
        JarvisIntent.SET_REMINDER -> "set_reminder" to JSONObject().put("message", c.text.orEmpty()).also { o ->
            val t = c.time.orEmpty()
            if (t.startsWith("in:")) o.put("in_minutes", t.removePrefix("in:").toInt()) else o.put("datetime", t)
        }
        else -> null
    }
}
