package com.jarvis.ai.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.jarvis.ai.apps.AppInfo
import com.jarvis.ai.command.ActionOutcome
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.jarvisTextFieldColors
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.weather.WeatherResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Calendar

/** Shows the REAL result of an action (what Android actually accepted or refused). */
@Composable
private fun OutcomeCard(o: ActionOutcome?) {
    if (o == null) return
    GlassCard {
        Row(verticalAlignment = Alignment.Top) {
            Icon(if (o.ok) Icons.Filled.Check else Icons.Filled.Close, null, tint = if (o.ok) JarvisColors.Success else JarvisColors.Danger, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(o.summary, color = Color.White, fontSize = 14.sp)
                o.needsUserAction?.let { Text(it, color = JarvisColors.Gold, fontSize = 12.sp) }
                o.candidates?.let { Text("Which one? " + it.joinToString(", "), color = JarvisColors.Gold, fontSize = 12.sp) }
                if (o.needsPermission != null) Text("Enable the permission on the Permissions page.", color = JarvisColors.Gold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun InputRow(value: String, onValue: (String) -> Unit, hint: String, button: String, icon: ImageVector, onGo: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value, onValue, singleLine = true, placeholder = { Text(hint) }, colors = jarvisTextFieldColors(),
            shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f),
        )
        Spacer(Modifier.width(8.dp))
        NeonButton(button, onGo, icon = icon, enabled = value.isNotBlank())
    }
}

// ───────────────────────── Quick Actions ─────────────────────────
@Composable
fun QuickActionsScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf<ActionOutcome?>(null) }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var appQuery by remember { mutableStateOf("") }
    var web by remember { mutableStateOf("") }
    var install by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var torch by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { c.installedApps.all() } }
    fun run(tool: String, args: JSONObject) { scope.launch { result = c.actionEngine.runSingle(tool, args) } }

    ScreenScaffold("Quick Actions", "Open apps, search and more", onBack) {
        OutcomeCard(result)

        GlassCard {
            Text("Open any app", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("${apps.size} apps found on this phone. New installs appear automatically.", color = JarvisColors.TextDim, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                appQuery, { appQuery = it }, singleLine = true, placeholder = { Text("Type an app name…") },
                leadingIcon = { Icon(Icons.Filled.Search, null, tint = JarvisColors.TextDim) },
                colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(6.dp))
            val shown = if (appQuery.isBlank()) apps.take(12) else apps.filter { com.jarvis.ai.util.TextMatch.score(appQuery, it.label) >= 60 || it.label.contains(appQuery, true) }.take(12)
            shown.forEach { a -> AppRow(a) { run("open_app", JSONObject().put("app_name", a.label)) } }
            if (shown.isEmpty() && apps.isNotEmpty()) Text("No installed app matches that.", color = JarvisColors.TextDim, fontSize = 12.sp)
        }

        GlassCard {
            Text("Shortcuts", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Time now") { run("get_time", JSONObject()) }
                Chip(if (torch) "Flashlight off" else "Flashlight on") { torch = !torch; run("set_flashlight", JSONObject().put("on", torch)) }
                Chip("Wi-Fi") { run("open_settings", JSONObject().put("page", "wifi")) }
                Chip("Bluetooth") { run("open_settings", JSONObject().put("page", "bluetooth")) }
                Chip("Sound") { run("open_settings", JSONObject().put("page", "sound")) }
                Chip("Display") { run("open_settings", JSONObject().put("page", "display")) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Weather") { onNavigate("weather") }
                Chip("Reminders") { onNavigate("reminders") }
                Chip("Music") { onNavigate("music") }
            }
        }

        GlassCard {
            Text("Search the web", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            InputRow(web, { web = it }, "What to search…", "Go", Icons.Filled.Search) { run("search", JSONObject().put("query", web)) }
            Spacer(Modifier.height(10.dp))
            Text("Install an app from Google Play", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            InputRow(install, { install = it }, "App name…", "Find", Icons.Filled.Search) { run("install_app", JSONObject().put("app_name", install)) }
            Spacer(Modifier.height(10.dp))
            Text("Find a contact", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            InputRow(contact, { contact = it }, "Name…", "Find", Icons.Filled.Search) { run("find_contact", JSONObject().put("name", contact)) }
        }
        Text("Tip: you can also just say these to JARVIS, in your own words.", color = JarvisColors.TextDim, fontSize = 12.sp)
    }
}

@Composable
private fun Chip(label: String, onClick: () -> Unit) {
    Text(
        label, color = Color.White, fontSize = 12.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, JarvisColors.Neon, RoundedCornerShape(50)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

@Composable
private fun AppRow(app: AppInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val icon = remember(app.pkg) { runCatching { ctx.packageManager.getApplicationIcon(app.pkg).toBitmap(72, 72).asImageBitmap() }.getOrNull() }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) Image(icon, null, Modifier.size(34.dp).clip(RoundedCornerShape(8.dp))) else Box(Modifier.size(34.dp).background(JarvisColors.Card))
        Spacer(Modifier.width(12.dp))
        Text(app.label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text("Open", color = JarvisColors.Cyan, fontSize = 12.sp)
    }
}

// ───────────────────────── Reminders ─────────────────────────
@Composable
fun RemindersScreen(onBack: () -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val items by c.reminderStore.items.collectAsState()
    var text by remember { mutableStateOf("") }
    var repeat by remember { mutableStateOf("none") }
    var date by remember { mutableStateOf<Calendar?>(null) }
    var result by remember { mutableStateOf<ActionOutcome?>(null) }
    val fmt = remember { java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT) }

    fun pick() {
        val now = Calendar.getInstance()
        DatePickerDialog(ctx, { _, y, m, d ->
            TimePickerDialog(ctx, { _, h, min ->
                date = Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), android.text.format.DateFormat.is24HourFormat(ctx)).show()
        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
    }

    ScreenScaffold("Reminders", "Never miss anything", onBack) {
        OutcomeCard(result)
        GlassCard {
            Text("New reminder", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(text, { text = it }, singleLine = true, placeholder = { Text("Remind me to…") }, colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            NeonButton(date?.let { fmt.format(it.time) } ?: "Pick date & time", { pick() }, Modifier.fillMaxWidth(), icon = Icons.Filled.Alarm, filled = false)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("none" to "Once", "daily" to "Daily", "weekly" to "Weekly").forEach { (k, label) ->
                    Text(
                        label, color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (repeat == k) JarvisColors.Blue else JarvisColors.BgTop)
                            .border(1.dp, if (repeat == k) JarvisColors.Cyan else JarvisColors.Blue.copy(alpha = 0.5f), RoundedCornerShape(50))
                            .clickable { repeat = k }.padding(horizontal = 14.dp, vertical = 7.dp),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            NeonButton("Add reminder", {
                val at = date ?: return@NeonButton
                val local = LocalDateTime.ofInstant(at.toInstant(), java.time.ZoneId.systemDefault()).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                scope.launch {
                    result = c.actionEngine.runSingle("set_reminder", JSONObject().put("message", text.trim()).put("datetime", local).put("repeat", repeat))
                    if (result?.ok == true) { text = ""; date = null; repeat = "none" }
                }
            }, Modifier.fillMaxWidth(), enabled = text.isNotBlank() && date != null)
            Text("You can also say it: \"Remind me to drink water at 8 PM.\"", color = JarvisColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        Text("Upcoming", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (items.isEmpty()) Text("No upcoming reminders.", color = JarvisColors.TextDim, fontSize = 13.sp)
        items.forEach { r ->
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(Icons.Filled.Alarm, JarvisColors.Purple, size = 38.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.message, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(fmt.format(java.util.Date(r.triggerAt)) + if (r.repeat != "none") " · ${r.repeat}" else "", color = JarvisColors.TextDim, fontSize = 12.sp)
                    }
                    Icon(Icons.Filled.Delete, "Delete reminder", tint = JarvisColors.Danger, modifier = Modifier.clickable { c.reminderScheduler.cancel(r.id) }.padding(6.dp))
                }
            }
        }
    }
}

// ───────────────────────── Music ─────────────────────────
@Composable
fun MusicScreen(onBack: () -> Unit) {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<ActionOutcome?>(null) }
    fun run(tool: String, args: JSONObject) { scope.launch { result = c.actionEngine.runSingle(tool, args) } }

    ScreenScaffold("Music", "Play your favorite", onBack) {
        OutcomeCard(result)
        GlassCard {
            Text("Play something", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            InputRow(query, { query = it }, "Song, artist or mood…", "Play", Icons.Filled.PlayArrow) { run("play_media", JSONObject().put("query", query.trim())) }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Relaxing music", "Workout mix", "Study focus", "Top hits", "Instrumental").forEach { s -> Chip(s) { query = s } }
            }
            Text("JARVIS asks your media apps to play it. Which app answers depends on what is installed; you can also say \"play … on <app>\".", color = JarvisColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        GlassCard {
            Text("Controls", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                CtrlButton(Icons.Filled.SkipPrevious, "Previous") { run("media_control", JSONObject().put("action", "previous")) }
                CtrlButton(Icons.Filled.PlayArrow, "Play") { run("media_control", JSONObject().put("action", "play")) }
                CtrlButton(Icons.Filled.Pause, "Pause") { run("media_control", JSONObject().put("action", "pause")) }
                CtrlButton(Icons.Filled.SkipNext, "Next") { run("media_control", JSONObject().put("action", "next")) }
                CtrlButton(Icons.Filled.Stop, "Stop") { run("media_control", JSONObject().put("action", "stop")) }
            }
        }
    }
}

@Composable
private fun CtrlButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        GlowIcon(icon, JarvisColors.Magenta, size = 42.dp)
        Text(label, color = Color.White, fontSize = 10.sp)
    }
}

// ───────────────────────── Weather ─────────────────────────
@Composable
fun WeatherScreen(onBack: () -> Unit) {
    val c = LocalContainer.current
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf<WeatherResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var city by remember { mutableStateOf("") }

    fun load(place: String?) {
        scope.launch {
            loading = true
            state = if (place.isNullOrBlank()) c.weather.forDevice() else c.weather.forPlace(place)
            loading = false
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { load(null) }
    LaunchedEffect(Unit) { if (c.weather.hasLocationPermission()) load(null) }

    ScreenScaffold("Weather", "Check live weather", onBack) {
        GlassCard {
            InputRow(city, { city = it }, "Search a city…", "Go", Icons.Filled.Search) { load(city) }
            Spacer(Modifier.height(8.dp))
            NeonButton("Use my location", {
                if (c.weather.hasLocationPermission()) load(null) else permLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
            }, Modifier.fillMaxWidth(), filled = false)
        }
        if (loading) Text("Loading…", color = JarvisColors.Cyan, fontSize = 14.sp)
        when (val r = state) {
            is WeatherResult.Ok -> {
                val w = r.weather
                GlassCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GlowIcon(Icons.Filled.WbSunny, JarvisColors.Gold, size = 56.dp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(w.place, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("${w.tempC.toInt()}°C", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp)
                            Text(w.summary, color = JarvisColors.Cyan, fontSize = 14.sp)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Feels like ${w.feelsC.toInt()}°C · Humidity ${w.humidity}% · Wind ${w.windKmh.toInt()} km/h · Rain now ${w.precipMm} mm", color = JarvisColors.TextDim, fontSize = 12.sp)
                }
                w.days.forEachIndexed { i, d ->
                    GlassCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(if (i == 0) "Today" else d.date, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(d.summary + (d.rainChance?.let { " · rain $it%" } ?: ""), color = JarvisColors.TextDim, fontSize = 12.sp)
                            }
                            Text("${d.maxC.toInt()}° / ${d.minC.toInt()}°", color = Color.White, fontSize = 14.sp)
                        }
                    }
                }
                Text("Data: Open-Meteo", color = JarvisColors.TextDim, fontSize = 11.sp)
            }
            WeatherResult.NeedsPermission -> Text("Allow location to see weather where you are, or search a city above.", color = JarvisColors.Gold, fontSize = 13.sp)
            WeatherResult.NoLocation -> Text("Couldn't find your location. Turn on Location or search a city.", color = JarvisColors.Gold, fontSize = 13.sp)
            is WeatherResult.PlaceNotFound -> Text("No place called \"${r.name}\" was found.", color = JarvisColors.Gold, fontSize = 13.sp)
            WeatherResult.Offline -> Text("You're offline. This feature needs an internet connection.", color = JarvisColors.Gold, fontSize = 13.sp)
            WeatherResult.Failed -> Text("The weather service didn't answer. Try again in a moment.", color = JarvisColors.Danger, fontSize = 13.sp)
            null -> if (!loading) Text("Search a city or use your location to see live weather.", color = JarvisColors.TextDim, fontSize = 13.sp)
        }
    }
}
