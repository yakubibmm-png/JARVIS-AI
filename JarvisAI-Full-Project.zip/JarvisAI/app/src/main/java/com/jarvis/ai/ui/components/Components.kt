package com.jarvis.ai.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun JarvisBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(JarvisColors.BgTop, JarvisColors.Bg, JarvisColors.BgBottom))),
        content = content,
    )
}

fun Modifier.neonBorder(shape: Shape = RoundedCornerShape(18.dp)): Modifier = this.border(
    1.dp,
    Brush.linearGradient(listOf(JarvisColors.Cyan.copy(alpha = 0.75f), JarvisColors.Blue.copy(alpha = 0.55f), JarvisColors.Purple.copy(alpha = 0.5f))),
    shape,
)

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: Dp = 14.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    var m = modifier.clip(shape).background(JarvisColors.Card.copy(alpha = 0.78f)).neonBorder(shape)
    if (onClick != null) m = m.clickable(role = Role.Button, onClick = onClick)
    Column(m.padding(padding), content = content)
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    filled: Boolean = true,
    enabled: Boolean = true,
    colors: List<Color> = listOf(JarvisColors.Blue, JarvisColors.Cyan.copy(alpha = 0.9f)),
) {
    val shape = RoundedCornerShape(14.dp)
    val bg = if (filled) Modifier.background(Brush.horizontalGradient(colors))
    else Modifier.background(JarvisColors.Card.copy(alpha = 0.6f)).border(1.dp, JarvisColors.Cyan.copy(alpha = 0.8f), shape)
    Row(
        modifier
            .height(46.dp)
            .alpha(if (enabled) 1f else 0.5f)
            .clip(shape)
            .then(bg)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
    }
}

@Composable
fun ProBadge(locked: Boolean, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    val bg = if (locked) Brush.horizontalGradient(listOf(JarvisColors.Purple, JarvisColors.Magenta))
    else Brush.horizontalGradient(listOf(Color(0xFFB45309), JarvisColors.Gold))
    Row(
        modifier.clip(shape).background(bg).padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (locked) Icons.Filled.Lock else Icons.Filled.WorkspacePremium, null, tint = Color.White, modifier = Modifier.size(11.dp))
        Spacer(Modifier.width(4.dp))
        Text("PRO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GlowIcon(icon: ImageVector, tint: Color, modifier: Modifier = Modifier, size: Dp = 44.dp) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.35f), tint.copy(alpha = 0.12f))))
            .border(1.dp, tint.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f)) }
}

@Composable
fun CircleIconButton(icon: ImageVector, description: String, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Color.White) {
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(JarvisColors.Card.copy(alpha = 0.8f))
            .border(BorderStroke(1.5.dp, JarvisColors.Neon), CircleShape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(22.dp)) }
}

/** Standard page: header (optional back arrow) + scrolling content. Used by every non-Home screen. */
@Composable
fun ScreenScaffold(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    trailing: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    JarvisBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (onBack != null) {
                    CircleIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", onBack)
                    Spacer(Modifier.width(12.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (subtitle != null) Text(subtitle, color = JarvisColors.TextDim, fontSize = 13.sp)
                }
                trailing()
            }
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content,
            )
        }
    }
}

@Composable
fun jarvisTextFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    focusedBorderColor = JarvisColors.Cyan,
    unfocusedBorderColor = JarvisColors.Blue.copy(alpha = 0.6f),
    cursorColor = JarvisColors.Cyan,
    focusedContainerColor = JarvisColors.BgTop.copy(alpha = 0.6f),
    unfocusedContainerColor = JarvisColors.BgTop.copy(alpha = 0.6f),
    focusedPlaceholderColor = JarvisColors.TextDim,
    unfocusedPlaceholderColor = JarvisColors.TextDim,
)
