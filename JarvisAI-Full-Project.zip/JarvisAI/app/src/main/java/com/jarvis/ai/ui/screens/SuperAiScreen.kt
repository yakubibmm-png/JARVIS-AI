package com.jarvis.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.ai.SuperProvider
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.LabeledField
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.jarvisTextFieldColors
import com.jarvis.ai.ui.theme.JarvisColors
import kotlinx.coroutines.launch

@Composable
fun SuperAiScreen(onBack: () -> Unit, onOpenApiKey: () -> Unit) {
    val c = LocalContainer.current
    val repo = c.superAi
    val active by repo.active.collectAsState()
    val version by repo.version.collectAsState()
    var expanded by remember { mutableStateOf<SuperProvider?>(null) }

    ScreenScaffold("Super AI", "Advanced AI models & providers", onBack) {
        Text("Choose which AI answers in Chat and voice. A provider is usable only after you save its key and model ID, and it shows Verified only after a real test request worked. Phone control (opening apps, reminders, screen control) works with Gemini only.", color = JarvisColors.TextDim, fontSize = 12.sp)
        @Suppress("UNUSED_VARIABLE") val refresh = version
        SuperProvider.entries.forEach { p ->
            val configured = repo.isConfigured(p)
            val isActive = repo.effective() == p
            val status = repo.status(p)
            GlassCard {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { expanded = if (expanded == p) null else p }, verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(if (p == SuperProvider.GEMINI) Icons.Filled.AutoAwesome else Icons.Filled.Psychology, if (isActive) JarvisColors.Success else JarvisColors.Cyan, size = 42.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(p.subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
                        Text(
                            when { isActive -> "Active"; status == "ok" -> "Verified"; status.startsWith("fail") -> "Test failed"; configured -> "Saved, not tested"; p == SuperProvider.GEMINI -> "Add your Gemini key"; else -> "Not set up" },
                            color = when { isActive || status == "ok" -> JarvisColors.Success; status.startsWith("fail") -> JarvisColors.Danger; else -> JarvisColors.TextDim }, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                        )
                    }
                    RadioDot(isActive)
                }
                if (expanded == p) ProviderEditor(p, onOpenApiKey)
            }
        }
    }
}

@Composable
private fun RadioDot(selected: Boolean) {
    androidx.compose.foundation.layout.Box(
        Modifier.size(20.dp).clip(CircleShape).border(2.dp, if (selected) JarvisColors.Cyan else JarvisColors.TextDim, CircleShape).padding(4.dp)
            .background(if (selected) JarvisColors.Cyan else Color.Transparent, CircleShape),
    )
}

@Composable
private fun ProviderEditor(p: SuperProvider, onOpenApiKey: () -> Unit) {
    val repo = LocalContainer.current.superAi
    val scope = rememberCoroutineScope()
    var key by remember(p) { mutableStateOf(repo.key(p)) }
    var show by remember(p) { mutableStateOf(false) }
    var model by remember(p) { mutableStateOf(repo.model(p)) }
    var base by remember(p) { mutableStateOf(repo.base(p)) }
    var testing by remember(p) { mutableStateOf(false) }
    var message by remember(p) { mutableStateOf<String?>(repo.status(p).removePrefix("fail:").takeIf { repo.status(p).startsWith("fail") }) }

    Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (p == SuperProvider.GEMINI) {
            Text("Gemini uses the key and model from the API Key page.", color = JarvisColors.TextDim, fontSize = 12.sp)
            NeonButton("Open API Key page", onOpenApiKey, Modifier.fillMaxWidth(), filled = false)
            if (repo.isConfigured(p)) NeonButton("Use Gemini", { repo.setActive(p) }, Modifier.fillMaxWidth())
            return@Column
        }
        if (p == SuperProvider.CUSTOM) LabeledField(base, { base = it; repo.setBase(p, it) }, "Service address", "https://…/v1")
        Text("API key", color = JarvisColors.TextDim, fontSize = 12.sp)
        OutlinedTextField(
            key, { key = it.filterNot { ch -> ch.isWhitespace() }; repo.setKey(p, key) }, singleLine = true,
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth(),
        )
        LabeledField(model, { model = it; repo.setModel(p, it) }, "Model ID", "Copy it from the provider's own model list")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton(if (show) "HIDE KEY" else "SHOW KEY", { show = !show }, Modifier.weight(1f), filled = false)
            NeonButton(if (testing) "Testing…" else "Verify", {
                testing = true
                scope.launch { message = repo.verify(p); testing = false }
            }, Modifier.weight(1f), enabled = repo.isConfigured(p) && !testing)
        }
        message?.let { Text(it, color = JarvisColors.Danger, fontSize = 12.sp) }
        NeonButton(if (repo.effective() == p) "Active" else "Use ${p.title}", {
            if (!repo.setActive(p)) message = "Save a key and model ID first."
        }, Modifier.fillMaxWidth(), enabled = repo.effective() != p)
        Text("Messages you send are sent to this provider while it is active. Keys are stored encrypted on this phone.", color = JarvisColors.TextDim, fontSize = 11.sp)
    }
}
