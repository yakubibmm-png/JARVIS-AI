package com.jarvis.ai.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.delay
import java.io.IOException
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Streams 16-bit mono PCM to an AudioTrack and reports the loudness of what is being played (0..1),
 * so the waveform can react to JARVIS's real voice. [write] blocks (call from an IO thread).
 */
class PcmPlayer(
    private val sampleRate: Int,
    private val volume: Float,
    private val onLevel: (Float) -> Unit,
) {
    private var track: AudioTrack? = null
    private var carry = -1
    private var frames = 0L
    @Volatile var hasPlayed = false
        private set

    fun start() {
        val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val buffer = maxOf(min, sampleRate / 2) // ≈ 250 ms: keeps the waveform close to what you hear
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(buffer)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        t.setVolume(volume.coerceIn(0f, 1f))
        t.play()
        track = t
    }

    fun write(data: ByteArray, len: Int = data.size) {
        val t = track ?: return
        val joined = if (carry >= 0) ByteArray(len + 1).also { it[0] = carry.toByte(); System.arraycopy(data, 0, it, 1, len) } else data.copyOf(len)
        val usable = joined.size and 1.inv()
        carry = if (joined.size != usable) joined[usable].toInt() and 0xFF else -1
        val slice = sampleRate / 50 * 2 // 20 ms
        var off = 0
        while (off < usable) {
            val n = minOf(slice, usable - off)
            val w = t.write(joined, off, n)
            if (w < 0) throw IOException("audio write failed ($w)")
            onLevel(level(joined, off, n))
            off += n; frames += n / 2; hasPlayed = true
        }
    }

    /** Wait for queued audio to finish playing. */
    suspend fun drain() {
        val t = track ?: return
        t.stop()
        val deadline = System.currentTimeMillis() + 3000
        while (t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) delay(20)
        onLevel(0f)
    }

    fun release() {
        track?.let { runCatching { it.pause(); it.flush(); it.release() } }
        track = null
        onLevel(0f)
    }

    private fun level(b: ByteArray, off: Int, n: Int): Float {
        var sum = 0.0
        var i = off
        while (i + 1 < off + n) {
            val s = ((b[i + 1].toInt() shl 8) or (b[i].toInt() and 0xFF)).toShort().toInt()
            sum += s.toDouble() * s
            i += 2
        }
        val rms = sqrt(sum / (n / 2).coerceAtLeast(1)) / 32768.0
        return (rms / 0.2).coerceIn(0.0, 1.0).pow(0.7).toFloat()
    }
}
