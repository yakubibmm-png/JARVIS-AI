package com.jarvis.ai.apps

import android.content.Context
import com.jarvis.ai.util.TextMatch
import com.jarvis.ai.util.withConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/** Checks that a Google Play listing really exists (public page, no scraping of content beyond the title). */
object PlayLookup {
    private val title = Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)

    /** The listing's title, or null if the page doesn't exist or can't be reached. */
    suspend fun titleFor(pkg: String): String? = withContext(Dispatchers.IO) {
        try {
            withConnection("https://play.google.com/store/apps/details?id=$pkg&hl=en", { c ->
                c.connectTimeout = 6000; c.readTimeout = 6000; c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) JarvisAI")
            }) { c ->
                if (c.responseCode != 200) null
                else {
                    val head = c.inputStream.use { input ->
                        val buf = ByteArray(24_000)
                        var n = 0
                        while (n < buf.size) { val r = input.read(buf, n, buf.size - n); if (r < 0) break; n += r }
                        String(buf, 0, n, Charsets.UTF_8)
                    }
                    title.find(head)?.groupValues?.get(1)?.trim()
                        ?.replace(" - Apps on Google Play", "")?.replace("&amp;", "&")?.replace("&#39;", "'")
                }
            }
        } catch (e: IOException) { null }
    }

    /** Does the Play title plausibly belong to the app the user asked for? */
    fun matches(requested: String, playTitle: String): Boolean {
        val short = playTitle.substringBefore(':').substringBefore(" - ").trim()
        return maxOf(TextMatch.score(requested, playTitle), TextMatch.score(requested, short)) >= 70
    }
}

data class PendingInstall(val requested: String, val pkg: String?, val startedAt: Long)

/**
 * Remembers installs JARVIS sent to Google Play and reports completion ONLY when Android shows the app is really
 * installed (package-added broadcast, or a check when JARVIS returns to the screen).
 */
class InstallTracker(
    ctx: Context,
    private val apps: InstalledApps,
    private val onInstalled: (label: String) -> Unit,
) {
    private val sp = ctx.applicationContext.getSharedPreferences("jarvis_installs", Context.MODE_PRIVATE)

    @Synchronized fun start(requested: String, pkg: String?) {
        val list = load().filterNot { it.requested.equals(requested, true) } + PendingInstall(requested, pkg, System.currentTimeMillis())
        save(list)
    }

    fun pending(): List<PendingInstall> = load()

    fun onPackageAdded(pkg: String) {
        apps.invalidate()
        check()
    }

    /** Called on package broadcasts and whenever JARVIS comes to the foreground. */
    @Synchronized fun check() {
        val now = System.currentTimeMillis()
        val keep = ArrayList<PendingInstall>()
        for (p in load()) {
            if (now - p.startedAt > EXPIRE_MS) continue
            val done: String? = when {
                p.pkg != null && apps.isInstalled(p.pkg) && apps.firstInstallTime(p.pkg) >= p.startedAt - 60_000 -> apps.labelOf(p.pkg)
                p.pkg == null -> apps.all().firstOrNull { apps.firstInstallTime(it.pkg) >= p.startedAt - 60_000 && TextMatch.score(p.requested, it.label) >= 85 }?.label
                else -> null
            }
            if (done != null) onInstalled(done) else keep.add(p)
        }
        save(keep)
    }

    private fun load(): List<PendingInstall> = runCatching {
        val arr = JSONArray(sp.getString("pending", "[]"))
        (0 until arr.length()).map { val o = arr.getJSONObject(it); PendingInstall(o.getString("r"), o.optString("p").ifEmpty { null }, o.getLong("t")) }
    }.getOrDefault(emptyList())

    private fun save(list: List<PendingInstall>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("r", it.requested).put("p", it.pkg ?: "").put("t", it.startedAt)) }
        sp.edit().putString("pending", arr.toString()).apply()
    }

    private companion object { const val EXPIRE_MS = 30 * 60 * 1000L }
}
