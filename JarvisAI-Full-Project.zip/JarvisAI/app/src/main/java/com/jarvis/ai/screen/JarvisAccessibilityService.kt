package com.jarvis.ai.screen

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.jarvis.ai.JarvisApp
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Only does something when JARVIS asks it to (voice/text command with Pro + Automation ON). It does not log, store or
 * upload what is on screen. It listens only for "which app came to the front" events.
 */
class JarvisAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: JarvisAccessibilityService? = null
        val connected = MutableStateFlow(false)
    }

    override fun onServiceConnected() { instance = this; connected.value = true }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg.startsWith("com.android.systemui")) return
        (applicationContext as? JarvisApp)?.container?.noteForegroundApp(pkg)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean { instance = null; connected.value = false; return super.onUnbind(intent) }
}
