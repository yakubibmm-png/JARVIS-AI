package com.jarvis.ai.di

import android.app.Application
import androidx.compose.runtime.staticCompositionLocalOf
import com.jarvis.ai.BuildConfig
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.data.CredentialsRepository
import com.jarvis.ai.data.ModelRepository
import com.jarvis.ai.data.SecureStore
import com.jarvis.ai.premium.LocalKeyHashValidator
import com.jarvis.ai.premium.PremiumRepository
import com.jarvis.ai.ai.GeminiClient
import com.jarvis.ai.chat.ChatRepository
import com.jarvis.ai.chat.ConversationEngine
import com.jarvis.ai.apps.InstallTracker
import com.jarvis.ai.apps.InstalledApps
import com.jarvis.ai.command.ActionEngine
import com.jarvis.ai.command.ActionMemory
import com.jarvis.ai.command.AppForeground
import com.jarvis.ai.command.CommandRouter
import com.jarvis.ai.command.HandlerRegistry
import com.jarvis.ai.command.LocalIntentParser
import com.jarvis.ai.command.handlers.ContactHandlers
import com.jarvis.ai.command.handlers.DeviceHandlers
import com.jarvis.ai.command.handlers.InfoHandlers
import com.jarvis.ai.command.handlers.ScreenController
import com.jarvis.ai.command.handlers.UnavailableScreenController
import com.jarvis.ai.contacts.AliasStore
import com.jarvis.ai.contacts.ContactsRepository
import com.jarvis.ai.reminders.Notifier
import com.jarvis.ai.reminders.ReminderScheduler
import com.jarvis.ai.reminders.ReminderStore
import com.jarvis.ai.weather.LocationProvider
import com.jarvis.ai.weather.WeatherRepository
import kotlinx.coroutines.launch
import com.jarvis.ai.ai.SuperAiRepository
import com.jarvis.ai.ai.SuperAiRouter
import com.jarvis.ai.automation.AutoReplyManager
import com.jarvis.ai.automation.AutomationItems
import com.jarvis.ai.automation.AutomationRunner
import com.jarvis.ai.automation.AutomationSettings
import com.jarvis.ai.automation.BackgroundVoice
import com.jarvis.ai.automation.TaskScheduler
import com.jarvis.ai.command.ActionOutcome
import com.jarvis.ai.command.ConfirmationManager
import com.jarvis.ai.command.handlers.AccessibilityScreenController
import com.jarvis.ai.screen.JarvisAccessibilityService
import com.jarvis.ai.screen.ScreenShareManager
import com.jarvis.ai.util.TextMatch
import org.json.JSONObject
import com.jarvis.ai.command.PassThroughRouter
import com.jarvis.ai.voice.SpeechInput
import com.jarvis.ai.voice.TtsManager
import com.jarvis.ai.voice.VoiceController
import com.jarvis.ai.voice.VoiceSessionHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Manual dependency container. Later phases add: AiProvider, TtsProvider, CommandEngine,
 * ActionPlanner, AutomationManager, ReminderScheduler, etc. here.
 */
class AppContainer(private val app: Application) {
    val secureStore: SecureStore by lazy { SecureStore(app) }
    val prefs: AppPrefs by lazy { AppPrefs(app) }
    val credentials: CredentialsRepository by lazy { CredentialsRepository(secureStore) }
    val models: ModelRepository by lazy { ModelRepository(app, prefs) }

    /** The ONE Premium state. Every screen reads premium.isPremium. */
    val premium: PremiumRepository by lazy {
        PremiumRepository(secureStore, LocalKeyHashValidator(BuildConfig.PREMIUM_KEY_SHA256))
    }

    val voiceSession: VoiceSessionHolder by lazy { VoiceSessionHolder() }

    // ── Phase 2 ──
    /** Lives as long as the process so a reply keeps generating if the user switches screens. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    val geminiClient: GeminiClient by lazy { GeminiClient(app, credentials) }
    val chatRepository: ChatRepository by lazy { ChatRepository(app, prefs, appScope) }

    /** Optional pre-AI hook; the default passes everything to Gemini (phone commands arrive as Gemini tool calls). */
    val commandRouter: CommandRouter = PassThroughRouter

    // ── Phase 3: command / action engine ──
    val foreground = AppForeground()
    val actionMemory = ActionMemory()
    val installedApps: InstalledApps by lazy { InstalledApps(app) }
    val aliasStore: AliasStore by lazy { AliasStore(app) }
    val contacts: ContactsRepository by lazy { ContactsRepository(app, aliasStore) }
    val reminderStore: ReminderStore by lazy { ReminderStore(app) }
    val reminderScheduler: ReminderScheduler by lazy { ReminderScheduler(app, reminderStore) }
    val locationProvider: LocationProvider by lazy { LocationProvider(app) }
    val weather: WeatherRepository by lazy { WeatherRepository(app, locationProvider) }

    val installTracker: InstallTracker by lazy { InstallTracker(app, installedApps) { label -> onInstallConfirmed(label) } }

    // ── Phase 4: automation, screen control, background assistant, Super AI ──
    val automation: AutomationSettings by lazy { AutomationSettings(app) }
    val automationItems: AutomationItems by lazy { AutomationItems(app) }
    val taskScheduler: TaskScheduler by lazy { TaskScheduler(app, automationItems) }
    val screenShare: ScreenShareManager by lazy { ScreenShareManager(app) }
    val superAi: SuperAiRepository by lazy { SuperAiRepository(app, prefs, secureStore, credentials) }
    private val superAiRouter: SuperAiRouter by lazy { SuperAiRouter(geminiClient, superAi) }

    val backgroundVoice: BackgroundVoice by lazy { BackgroundVoice(app, prefs, premium, foreground) { text -> voiceController.announce(text) } }
    val automationRunner: AutomationRunner by lazy { AutomationRunner(app, appScope, { conversation }, automation, premium, backgroundVoice, installedApps) }
    val autoReply: AutoReplyManager by lazy { AutoReplyManager(app, automation, premium, geminiClient, models, contacts, prefs, appScope) }

    /** Yes/no gate for sending messages, paying, deleting... Approved by the card's Confirm button or the user's next message. */
    val confirmations: ConfirmationManager by lazy { ConfirmationManager(appScope) { o -> onConfirmationResult(o) } }

    val screenController: ScreenController by lazy {
        AccessibilityScreenController(app, actionMemory, premium, automation, confirmations, screenShare, geminiClient, models, installedApps) { actionEngine.requestId }
    }

    private fun screenCapable() = premium.isPremium.value && automation.enabled.value && JarvisAccessibilityService.instance != null

    val actionEngine: ActionEngine by lazy {
        val device = DeviceHandlers(app, installedApps, installTracker)
        val contact = ContactHandlers(app, contacts, installedApps)
        val info = InfoHandlers(app, weather, reminderStore, reminderScheduler)
        ActionEngine(HandlerRegistry.build(device, contact, info, { screenController }, this::customAction), actionMemory, foreground, this::screenCapable)
    }

    /** "Run my Good morning action": returns the saved command so Gemini carries it out with the normal tools. */
    private fun customAction(name: String): ActionOutcome {
        val a = automationItems.actions.value.map { it to TextMatch.score(name, it.name) }.filter { it.second >= 70 }.maxByOrNull { it.second }?.first
            ?: return ActionOutcome.fail("No custom action called \"$name\".", "not_found", JSONObject().put("available", org.json.JSONArray(automationItems.actions.value.map { it.name })))
        return ActionOutcome(true, "Custom action \"${a.name}\".", JSONObject().put("command_to_carry_out_now", a.command))
    }

    private fun onInstallConfirmed(label: String) {
        val text = "$label has been installed successfully."
        appScope.launch {
            conversation.postAssistantNote("✅ $text")
            Notifier.info(app, "App installed", text)
            if (foreground.isForeground) voiceController.announce("Boss, $text") else backgroundVoice.speak("Boss, $text")
        }
    }

    private fun onConfirmationResult(o: ActionOutcome) {
        appScope.launch {
            conversation.postAssistantNote((if (o.ok) "✅ " else "⚠️ ") + o.summary)
            voiceController.announce(o.summary)
        }
    }

    /** Called by the Accessibility Service when another app comes to the front (feeds follow-up context). */
    fun noteForegroundApp(pkg: String) { installedApps.labelOf(pkg)?.let { actionMemory.setCurrentApp(it) } }

    val conversation: ConversationEngine by lazy {
        ConversationEngine(
            chatRepository, superAiRouter, models, prefs, premium, commandRouter, appScope, actionEngine, actionMemory, LocalIntentParser(),
            { aliasStore.all.value.map { it.alias } },
        )
    }
    val tts: TtsManager by lazy { TtsManager(app, prefs, credentials, geminiClient, models, premium) }
    val voiceController: VoiceController by lazy {
        VoiceController(app, appScope, voiceSession, conversation, tts, SpeechInput(app), credentials, prefs, foreground)
    }
}

val LocalContainer = staticCompositionLocalOf<AppContainer> { error("AppContainer not provided") }
