package com.jarvis.ai

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.nav.JarvisNavHost
import com.jarvis.ai.ui.theme.JarvisTheme

class MainActivity : ComponentActivity() {
    override fun onStart() {
        super.onStart()
        val c = (application as JarvisApp).container
        c.foreground.isForeground = true
        c.installedApps.invalidate()
        c.installTracker.check()   // confirms installs that finished while JARVIS was in the background
    }

    override fun onStop() {
        (application as JarvisApp).container.foreground.isForeground = false
        super.onStop()
        // Stop listening/speaking when the app really leaves the foreground (not on rotation).
        if (!isChangingConfigurations) (application as JarvisApp).container.voiceController.onAppBackgrounded()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        val container = (application as JarvisApp).container
        setContent {
            CompositionLocalProvider(LocalContainer provides container) {
                JarvisTheme { JarvisNavHost() }
            }
        }
    }
}
