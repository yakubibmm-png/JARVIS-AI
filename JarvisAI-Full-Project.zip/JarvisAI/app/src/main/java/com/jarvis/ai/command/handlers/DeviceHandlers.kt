package com.jarvis.ai.command.handlers

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import com.jarvis.ai.apps.AppInfo
import com.jarvis.ai.apps.AppMatch
import com.jarvis.ai.apps.InstallTracker
import com.jarvis.ai.apps.InstalledApps
import com.jarvis.ai.apps.PlayLookup
import com.jarvis.ai.command.ActionOutcome
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import kotlin.coroutines.resume

/**
 * Starts an activity safely. When JARVIS is in the background and the Accessibility Service is connected (so the user
 * enabled it), the launch goes through that service, which Android allows; otherwise only a foreground app may launch.
 * Returns false when Android refuses or no app can handle the intent.
 */
internal fun Context.tryStart(i: Intent): Boolean {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val foreground = (applicationContext as? com.jarvis.ai.JarvisApp)?.container?.foreground?.isForeground ?: true
    val starter: Context = if (!foreground) (com.jarvis.ai.screen.JarvisAccessibilityService.instance ?: this) else this
    return try { starter.startActivity(i); true } catch (e: ActivityNotFoundException) { false } catch (e: SecurityException) { false }
}

internal fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

internal fun ambiguous(what: String, apps: List<AppInfo>) = ActionOutcome(
    ok = false, summary = "More than one installed app matches \"$what\".", reason = "ambiguous", candidates = apps.map { it.label },
)

/** Open / install / search / URL / settings / media / flashlight. */
class DeviceHandlers(
    private val ctx: Context,
    private val apps: InstalledApps,
    private val installs: InstallTracker,
) {
    // ───────── open any installed app ─────────
    suspend fun openApp(args: JSONObject): ActionOutcome {
        val q = args.optString("app_name").trim()
        if (q.isEmpty()) return ActionOutcome.fail("No app name was given.", "missing_argument")
        return when (val m = apps.resolve(q)) {
            is AppMatch.Found -> launch(m.app)
            is AppMatch.Ambiguous -> ambiguous(q, m.apps)
            is AppMatch.None -> ActionOutcome(
                ok = false, summary = "No installed app matches \"$q\".", reason = "not_installed",
                data = JSONObject().put("closest_matches", JSONArray(m.closest.map { it.label }))
                    .put("hint", "The user can ask JARVIS to install it from Google Play."),
            )
        }
    }

    private fun launch(app: AppInfo): ActionOutcome {
        val i = apps.launchIntent(app.pkg) ?: return ActionOutcome.fail("${app.label} can't be opened.", "no_launch_intent")
        return if (ctx.tryStart(i)) ActionOutcome(
            ok = true, summary = "Opened ${app.label}.", launchedExternal = true,
            data = JSONObject().put("app_label", app.label).put("package", app.pkg),
        ) else ActionOutcome.fail("Android refused to open ${app.label}.", "launch_refused")
    }

    // ───────── install via Google Play ─────────
    suspend fun installApp(args: JSONObject): ActionOutcome {
        val name = args.optString("app_name").trim()
        if (name.isEmpty()) return ActionOutcome.fail("No app name was given.", "missing_argument")
        val hint = args.optString("package_name").trim().takeIf { PKG.matches(it) }

        // 1) already installed?
        val installed: AppInfo? = when (val m = apps.resolve(name)) {
            is AppMatch.Found -> m.app.takeIf { m.score >= 85 }
            else -> null
        } ?: hint?.takeIf { apps.isInstalled(it) }?.let { AppInfo(apps.labelOf(it) ?: name, it) }
        if (installed != null) return ActionOutcome(
            ok = true, summary = "${installed.label} is already installed.",
            data = JSONObject().put("already_installed", true).put("app_label", installed.label).put("install_confirmed", true),
        )

        // 2) find the Play listing; a package ID suggested by Gemini is verified against the real Play page first
        var pkg: String? = null
        var verified = false
        if (hint != null) {
            val title = PlayLookup.titleFor(hint)
            if (title != null && PlayLookup.matches(name, title)) { pkg = hint; verified = true }
        }
        val uri = if (pkg != null) Uri.parse("market://details?id=$pkg") else Uri.parse("market://search?q=${enc(name)}&c=apps")
        val web = if (pkg != null) Uri.parse("https://play.google.com/store/apps/details?id=$pkg")
        else Uri.parse("https://play.google.com/store/search?q=${enc(name)}&c=apps")
        val started = ctx.tryStart(Intent(Intent.ACTION_VIEW, uri).setPackage("com.android.vending")) ||
            ctx.tryStart(Intent(Intent.ACTION_VIEW, uri)) || ctx.tryStart(Intent(Intent.ACTION_VIEW, web))
        if (!started) return ActionOutcome.fail("Google Play couldn't be opened on this phone.", "play_unavailable")

        installs.start(name, pkg)
        return ActionOutcome(
            ok = true, launchedExternal = true,
            summary = if (verified) "Opened the Google Play page for $name." else "Opened Google Play search results for $name.",
            needsUserAction = if (verified) "Tap Install in Google Play." else "Pick the right app in Google Play and tap Install.",
            data = JSONObject().put("install_confirmed", false).put("listing_verified", verified)
                .put("note", "JARVIS will confirm only after Android reports the app as installed."),
        )
    }

    // ───────── search ─────────
    suspend fun search(args: JSONObject): ActionOutcome {
        val q = args.optString("query").trim()
        val appName = args.optString("app_name").trim()
        if (q.isEmpty()) return ActionOutcome.fail("Nothing to search for.", "missing_argument")
        if (appName.isNotEmpty()) when (val m = apps.resolve(appName)) {
            is AppMatch.Ambiguous -> return ambiguous(appName, m.apps)
            is AppMatch.Found -> {
                val template = SEARCH_LINKS[m.app.pkg]
                if (template != null) {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse(template.replace("%s", if (template.startsWith("http")) enc(q) else Uri.encode(q)))).setPackage(m.app.pkg)
                    if (ctx.tryStart(i)) return ActionOutcome(true, "Searched ${m.app.label} for \"$q\".", launchedExternal = true,
                        data = JSONObject().put("app_label", m.app.label).put("searched_in_app", true))
                }
                val open = apps.launchIntent(m.app.pkg)
                if (open != null && ctx.tryStart(open)) return ActionOutcome(
                    ok = true, launchedExternal = true, summary = "Opened ${m.app.label}, but searching inside it isn't possible yet.",
                    data = JSONObject().put("app_label", m.app.label).put("searched_in_app", false),
                    needsUserAction = "Type the search in ${m.app.label} yourself. Searching inside other apps needs the Accessibility feature.",
                )
            }
            is AppMatch.None -> Unit
        }
        val ok = ctx.tryStart(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)) ||
            ctx.tryStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(q)}")))
        return if (ok) ActionOutcome(true, "Started a web search for \"$q\".", launchedExternal = true, data = JSONObject().put("searched_in_app", false))
        else ActionOutcome.fail("No browser or search app could be opened.", "no_handler")
    }

    fun openUrl(args: JSONObject): ActionOutcome {
        val url = args.optString("url").trim()
        val uri = runCatching { Uri.parse(url) }.getOrNull()
        if (uri == null || uri.scheme?.lowercase() !in setOf("http", "https") || uri.host.isNullOrBlank())
            return ActionOutcome.fail("Only normal web links (http or https) can be opened.", "invalid_url")
        return if (ctx.tryStart(Intent(Intent.ACTION_VIEW, uri))) ActionOutcome(true, "Opened ${uri.host}.", launchedExternal = true)
        else ActionOutcome.fail("No app could open that link.", "no_handler")
    }

    // ───────── settings ─────────
    fun openSettings(args: JSONObject): ActionOutcome {
        val page = args.optString("page", "main").lowercase()
        val action = when (page) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS; "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY; "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS; "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS; "date" -> Settings.ACTION_DATE_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS; "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val i = Intent(action).also { if (page == "notifications") it.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName) }
        return if (page == "notifications") {
            // that page is for JARVIS's own notifications; the system-wide list is the main page
            if (ctx.tryStart(i)) ActionOutcome(true, "Opened JARVIS's notification settings.", launchedExternal = true)
            else ActionOutcome.fail("That settings page couldn't be opened.", "no_handler")
        } else if (ctx.tryStart(i)) ActionOutcome(true, "Opened ${page.replaceFirstChar { it.uppercase() }} settings.", launchedExternal = true)
        else ActionOutcome.fail("That settings page couldn't be opened.", "no_handler")
    }

    // ───────── media ─────────
    suspend fun playMedia(args: JSONObject): ActionOutcome {
        val q = args.optString("query").trim()
        val appName = args.optString("app_name").trim()
        val kind = args.optString("kind")
        if (q.isEmpty()) return ActionOutcome.fail("Nothing to play.", "missing_argument")
        var app: AppInfo? = null
        if (appName.isNotEmpty()) when (val m = apps.resolve(appName)) {
            is AppMatch.Found -> app = m.app
            is AppMatch.Ambiguous -> return ambiguous(appName, m.apps)
            is AppMatch.None -> return ActionOutcome(false, "No installed app matches \"$appName\".", reason = "not_installed")
        }
        val focus = when (kind) { "video" -> MediaStore.Video.Media.ENTRY_CONTENT_TYPE; "audio" -> MediaStore.Audio.Media.ENTRY_CONTENT_TYPE; else -> "vnd.android.cursor.item/*" }
        val play = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(MediaStore.EXTRA_MEDIA_FOCUS, focus).putExtra(SearchManager.QUERY, q)
        app?.let { play.setPackage(it.pkg) }
        if (ctx.tryStart(play)) return ActionOutcome(
            ok = true, launchedExternal = true, summary = "Asked ${app?.label ?: "a media app"} to play \"$q\".",
            data = JSONObject().put("app_label", app?.label ?: "").put("playback_confirmed", false),
            needsUserAction = "Playback is handled by that app; it may ask you to confirm or sign in.",
        )
        val yt = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${enc(q)}"))
        if (ctx.tryStart(yt)) return ActionOutcome(
            ok = true, launchedExternal = true, summary = "No media app could start playback directly, so I opened YouTube search results for \"$q\".",
            data = JSONObject().put("playback_confirmed", false), needsUserAction = "Tap a result to play it.",
        )
        return ActionOutcome.fail("No app on this phone could play that.", "no_handler")
    }

    suspend fun mediaControl(args: JSONObject): ActionOutcome {
        val action = args.optString("action").lowercase()
        val key = when (action) {
            "play", "pause", "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> return ActionOutcome.fail("Unknown media action \"$action\".", "invalid_argument")
        }
        val am = ctx.getSystemService(AudioManager::class.java) ?: return ActionOutcome.fail("Audio controls aren't available.", "no_audio_service")
        val before = am.isMusicActive
        if (action == "play" && before) return ActionOutcome(true, "Media is already playing.", JSONObject().put("playing", true))
        if ((action == "pause" || action == "stop") && !before) return ActionOutcome(true, "Nothing is playing right now.", JSONObject().put("playing", false))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
        delay(600)
        val after = am.isMusicActive
        return when (action) {
            "play" -> if (after) ActionOutcome(true, "Playback resumed.", JSONObject().put("playing", true))
                else ActionOutcome.fail("I sent the play command but nothing started playing.", "not_confirmed", JSONObject().put("playing", false))
            "pause", "stop" -> if (!after) ActionOutcome(true, if (action == "pause") "Paused." else "Stopped.", JSONObject().put("playing", false))
                else ActionOutcome.fail("I sent the command but media is still playing.", "not_confirmed", JSONObject().put("playing", true))
            "toggle" -> ActionOutcome(true, if (after) "Now playing." else "Now paused.", JSONObject().put("playing", after))
            else -> ActionOutcome(true, "Sent \"$action\" to the active media app.", JSONObject().put("playing", after).put("confirmed", false))
        }
    }

    // ───────── flashlight ─────────
    suspend fun flashlight(args: JSONObject): ActionOutcome {
        val on = args.optBoolean("on", true)
        val cm = ctx.getSystemService(CameraManager::class.java) ?: return ActionOutcome.fail("No camera service.", "no_camera")
        val id = cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true && c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return ActionOutcome.fail("This phone has no flashlight.", "no_flash")
        val confirmed = withTimeoutOrNull(1500) {
            suspendCancellableCoroutine<Boolean> { cont ->
                val cb = object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        if (cameraId == id && enabled == on && cont.isActive) { cm.unregisterTorchCallback(this); cont.resume(true) }
                    }
                }
                cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
                try { cm.setTorchMode(id, on) } catch (e: Exception) { cm.unregisterTorchCallback(cb); if (cont.isActive) cont.resume(false) }
                cont.invokeOnCancellation { runCatching { cm.unregisterTorchCallback(cb) } }
            }
        }
        return if (confirmed == true) ActionOutcome(true, if (on) "Flashlight is on." else "Flashlight is off.", JSONObject().put("flashlight_on", on))
        else ActionOutcome.fail("I couldn't confirm the flashlight changed.", "not_confirmed")
    }

    private companion object {
        val PKG = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")
        /** Optional shortcuts for in-app search; any other app falls back to "open the app" honestly. */
        val SEARCH_LINKS = mapOf(
            "com.google.android.youtube" to "https://www.youtube.com/results?search_query=%s",
            "com.google.android.apps.youtube.music" to "https://music.youtube.com/search?q=%s",
            "com.spotify.music" to "spotify:search:%s",
            "com.google.android.apps.maps" to "geo:0,0?q=%s",
        )
    }
}
