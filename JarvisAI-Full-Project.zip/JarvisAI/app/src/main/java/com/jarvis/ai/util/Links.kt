package com.jarvis.ai.util

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

object Links {
    const val GEMINI_KEY_URL = "https://aistudio.google.com/app/apikey"
    const val ELEVENLABS_KEY_URL = "https://elevenlabs.io/app/settings/api-keys"
    const val TELEGRAM_USERNAME = "JARVISai_PRO"
}

fun Context.openUrl(url: String): Boolean = try {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    if (this !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(intent)
    true
} catch (e: ActivityNotFoundException) {
    false
}

/** Telegram app first, browser fallback. Returns false only if neither can open. */
fun Context.openTelegram(): Boolean =
    openUrl("tg://resolve?domain=${Links.TELEGRAM_USERNAME}") || openUrl("https://t.me/${Links.TELEGRAM_USERNAME}")
