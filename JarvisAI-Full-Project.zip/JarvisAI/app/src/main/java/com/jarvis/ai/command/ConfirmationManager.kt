package com.jarvis.ai.command

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PendingConfirmation(
    val id: Long, val title: String, val detail: String, val requestId: Long, val createdAt: Long,
    val execute: suspend () -> ActionOutcome,
)

/**
 * Nothing consequential (sending a message, paying, deleting...) happens without an explicit yes. A pending action
 * can be approved by tapping Confirm on the card, or by the user's NEXT spoken/typed message (never in the same turn).
 */
class ConfirmationManager(private val scope: CoroutineScope, private val onResult: (ActionOutcome) -> Unit) {
    private val _pending = MutableStateFlow<PendingConfirmation?>(null)
    val pending: StateFlow<PendingConfirmation?> = _pending.asStateFlow()
    private var expiry: Job? = null
    private var counter = 0L

    fun request(title: String, detail: String, requestId: Long, execute: suspend () -> ActionOutcome) {
        val p = PendingConfirmation(++counter, title, detail, requestId, System.currentTimeMillis(), execute)
        _pending.value = p
        expiry?.cancel()
        expiry = scope.launch { delay(EXPIRE_MS); if (_pending.value?.id == p.id) _pending.value = null }
    }

    private fun take(): PendingConfirmation? {
        val p = _pending.value ?: return null
        _pending.value = null; expiry?.cancel()
        return if (System.currentTimeMillis() - p.createdAt > EXPIRE_MS) null else p
    }

    suspend fun approveFromTool(currentRequestId: Long): ActionOutcome {
        val p = _pending.value ?: return ActionOutcome.fail("Nothing is waiting for confirmation.", "nothing_pending")
        if (p.requestId == currentRequestId) return ActionOutcome.fail("The user has not confirmed yet. Ask them, then wait for their answer.", "confirmation_needs_user")
        val taken = take() ?: return ActionOutcome.fail("The confirmation expired. Ask the user again.", "expired")
        return taken.execute()
    }

    fun approveFromUi() {
        val p = take() ?: return
        scope.launch { onResult(p.execute()) }
    }

    fun cancel(): Boolean { val had = _pending.value != null; _pending.value = null; expiry?.cancel(); return had }

    private companion object { const val EXPIRE_MS = 2 * 60 * 1000L }
}
