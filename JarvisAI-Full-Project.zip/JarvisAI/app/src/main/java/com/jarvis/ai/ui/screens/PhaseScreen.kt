package com.jarvis.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.theme.JarvisColors

/**
 * Honest placeholder for screens whose engines ship in a later phase. It states exactly what is not built yet
 * instead of showing controls that do nothing.
 */
@Composable
fun PhaseScreen(
    title: String,
    subtitle: String,
    icon: ImageVector,
    phase: Int,
    items: List<String>,
    onBack: (() -> Unit)?,
) {
    ScreenScaffold(title, subtitle, onBack) {
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlowIcon(icon, JarvisColors.Cyan)
                Spacer(Modifier.width(12.dp))
                Text("Arrives in Phase $phase", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            Text("This screen is wired into navigation. Its working controls are added together with the engine behind them, so nothing here pretends to work.", color = JarvisColors.TextDim, fontSize = 13.sp)
        }
        GlassCard {
            Text("Planned for this screen", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            items.forEach {
                Row(Modifier, horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.Top) {
                    Icon(Icons.Filled.Check, null, tint = JarvisColors.Cyan, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(it, color = Color.White, fontSize = 13.sp)
                }
                Spacer(Modifier.height(6.dp))
            }
        }
    }
}
