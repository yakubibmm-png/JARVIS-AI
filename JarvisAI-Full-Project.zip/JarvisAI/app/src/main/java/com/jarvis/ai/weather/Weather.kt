package com.jarvis.ai.weather

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.core.content.ContextCompat
import com.jarvis.ai.util.isOnline
import com.jarvis.ai.util.withConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.Locale
import kotlin.coroutines.resume

data class DayForecast(val date: String, val summary: String, val maxC: Double, val minC: Double, val rainChance: Int?)

data class Weather(
    val place: String, val tempC: Double, val feelsC: Double, val humidity: Int, val windKmh: Double,
    val precipMm: Double, val summary: String, val isDay: Boolean, val days: List<DayForecast>,
)

sealed interface WeatherResult {
    data class Ok(val weather: Weather) : WeatherResult
    data object NeedsPermission : WeatherResult
    data object NoLocation : WeatherResult
    data class PlaceNotFound(val name: String) : WeatherResult
    data object Offline : WeatherResult
    data object Failed : WeatherResult
}

/** Coarse device location (no GPS needed). Used only when the user asks for weather without naming a place. */
class LocationProvider(private val ctx: Context) {
    fun hasPermission() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @Suppress("MissingPermission", "DEPRECATION")
    suspend fun current(): Location? {
        if (!hasPermission()) return null
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return null
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER).filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        val last = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .filter { System.currentTimeMillis() - it.time < 2 * 3600_000 }.maxByOrNull { it.time }
        if (last != null) return last
        val p = providers.firstOrNull { it != LocationManager.PASSIVE_PROVIDER } ?: return null
        return withTimeoutOrNull(8000) {
            suspendCancellableCoroutine { cont ->
                val l = object : LocationListener {
                    override fun onLocationChanged(location: Location) { if (cont.isActive) cont.resume(location) }
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                    @Deprecated("Deprecated in Java") override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                }
                lm.requestSingleUpdate(p, l, Looper.getMainLooper())
                cont.invokeOnCancellation { lm.removeUpdates(l) }
            }
        }
    }

    @Suppress("DEPRECATION")
    suspend fun label(loc: Location): String = withContext(Dispatchers.IO) {
        try {
            if (!Geocoder.isPresent()) return@withContext "your location"
            val a = Geocoder(ctx, Locale.getDefault()).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
            a?.locality ?: a?.subAdminArea ?: a?.adminArea ?: "your location"
        } catch (e: Exception) { "your location" }
    }
}

/** Real weather from Open-Meteo (free, no key). Nothing is ever invented: failures are reported as failures. */
class WeatherRepository(private val ctx: Context, private val location: LocationProvider) {
    fun hasLocationPermission() = location.hasPermission()

    suspend fun forPlace(name: String): WeatherResult {
        if (!ctx.isOnline()) return WeatherResult.Offline
        return try {
            val g = getJson("https://geocoding-api.open-meteo.com/v1/search?name=${URLEncoder.encode(name, "UTF-8")}&count=1&language=en&format=json")
            val first = g.optJSONArray("results")?.optJSONObject(0) ?: return WeatherResult.PlaceNotFound(name)
            val label = listOf(first.optString("name"), first.optString("admin1"), first.optString("country")).filter { it.isNotBlank() }.distinct().take(2).joinToString(", ")
            fetch(first.getDouble("latitude"), first.getDouble("longitude"), label)
        } catch (e: IOException) { WeatherResult.Offline } catch (e: Exception) { WeatherResult.Failed }
    }

    suspend fun forDevice(): WeatherResult {
        if (!location.hasPermission()) return WeatherResult.NeedsPermission
        if (!ctx.isOnline()) return WeatherResult.Offline
        val loc = location.current() ?: return WeatherResult.NoLocation
        return try { fetch(loc.latitude, loc.longitude, location.label(loc)) } catch (e: IOException) { WeatherResult.Offline } catch (e: Exception) { WeatherResult.Failed }
    }

    private suspend fun fetch(lat: Double, lon: Double, place: String): WeatherResult {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,is_day" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=4"
        val o = getJson(url)
        val cur = o.getJSONObject("current")
        val daily = o.getJSONObject("daily")
        val dates = daily.getJSONArray("time")
        val days = (0 until dates.length()).map { i ->
            DayForecast(
                dates.getString(i), describe(daily.getJSONArray("weather_code").getInt(i)),
                daily.getJSONArray("temperature_2m_max").getDouble(i), daily.getJSONArray("temperature_2m_min").getDouble(i),
                daily.optJSONArray("precipitation_probability_max")?.let { if (it.isNull(i)) null else it.getInt(i) },
            )
        }
        return WeatherResult.Ok(
            Weather(
                place, cur.getDouble("temperature_2m"), cur.getDouble("apparent_temperature"), cur.getInt("relative_humidity_2m"),
                cur.getDouble("wind_speed_10m"), cur.getDouble("precipitation"), describe(cur.getInt("weather_code")), cur.optInt("is_day", 1) == 1, days,
            ),
        )
    }

    private suspend fun getJson(url: String): JSONObject = withContext(Dispatchers.IO) {
        withConnection(url, { c -> c.connectTimeout = 10_000; c.readTimeout = 10_000 }) { c ->
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        }
    }

    companion object {
        fun describe(code: Int): String = when (code) {
            0 -> "Clear sky"; 1 -> "Mainly clear"; 2 -> "Partly cloudy"; 3 -> "Overcast"
            45, 48 -> "Fog"; 51, 53, 55 -> "Drizzle"; 56, 57 -> "Freezing drizzle"
            61 -> "Light rain"; 63 -> "Rain"; 65 -> "Heavy rain"; 66, 67 -> "Freezing rain"
            71 -> "Light snow"; 73 -> "Snow"; 75 -> "Heavy snow"; 77 -> "Snow grains"
            80 -> "Light showers"; 81 -> "Showers"; 82 -> "Violent showers"; 85, 86 -> "Snow showers"
            95 -> "Thunderstorm"; 96, 99 -> "Thunderstorm with hail"
            else -> "Unknown conditions"
        }
    }
}
