package com.jarvis.ai.command

import com.jarvis.ai.ai.FnCall
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

/**
 * understand (Gemini tool call) -> PLAN (order + limits + guards) -> EXECUTE (handlers) -> real result.
 * Handlers are registered by tool name; Phase 4 adds the screen/messaging handlers without touching this class.
 */
class ActionEngine(
    private val handlers: Map<String, ActionHandler>,
    private val memory: ActionMemory,
    private val foreground: AppForeground,
    /** True when Accessibility + Pro + Automation are all on: JARVIS may then act while it is in the background. */
    private val screenCapable: () -> Boolean = { false },
) {
    /** Incremented for every user message; the confirmation flow uses it so a pending action cannot be approved in the same turn. */
    @Volatile var requestId: Long = 0L

    class Step(val index: Int, val call: FnCall, val spec: ToolSpec?)

    /** Non-launching steps first, so everything that doesn't leave JARVIS runs before the one app launch. */
    fun plan(calls: List<FnCall>): List<Step> =
        calls.mapIndexed { i, c -> Step(i, c, ToolSpecs.find(c.name)) }
            .sortedBy { if (it.spec?.launchesApp == true) 1 else 0 }

    /** Results are returned in the same order as [calls]. */
    suspend fun execute(calls: List<FnCall>, run: RunContext): List<ActionOutcome> {
        val results = arrayOfNulls<ActionOutcome>(calls.size)
        var launched = false
        var executed = 0
        for (step in plan(calls)) {
            val spec = step.spec
            val handler = handlers[step.call.name]
            val launches = spec?.launchesApp == true
            val outcome: ActionOutcome = when {
                spec == null || handler == null -> ActionOutcome.fail("JARVIS has no action called \"${step.call.name}\".", "unknown_tool")
                executed >= MAX_STEPS -> ActionOutcome.fail("Too many actions in one request.", "too_many_actions")
                launches && launched && !screenCapable() -> ActionOutcome.fail("Only one app can be opened per request until screen control is enabled.", "already_opened_an_app")
                launches && !foreground.isForeground && !screenCapable() -> ActionOutcome.fail("JARVIS has to be on screen to open other apps. Open JARVIS and try again.", "app_not_in_foreground")
                else -> {
                    run.onStatus(statusFor(step.call))
                    executed++
                    try {
                        handler!!.handle(step.call.args)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: SecurityException) {
                        ActionOutcome.permission("unknown", "Android blocked this action because a permission is missing.")
                    } catch (e: Exception) {
                        ActionOutcome.fail("The action failed unexpectedly (${e.javaClass.simpleName}).", "exception")
                    }
                }
            }
            if (outcome.launchedExternal) { launched = true; foreground.noteExternalLaunch(); if (screenCapable()) kotlinx.coroutines.delay(1200) }
            memory.record(step.call.name, step.call.args, outcome)
            results[step.index] = outcome
        }
        return results.map { it!! }
    }

    /** Runs one tool directly (used by the Quick Actions, Music, Reminders and Weather screens). */
    suspend fun runSingle(name: String, args: JSONObject): ActionOutcome =
        execute(listOf(FnCall(name, args)), RunContext(false)).first()

    private fun statusFor(c: FnCall): String = when (c.name) {
        "open_app" -> "Opening ${c.args.optString("app_name")}…"
        "install_app" -> "Looking for ${c.args.optString("app_name")}…"
        "search" -> "Searching…"
        "play_media" -> "Starting playback…"
        "set_reminder", "set_alarm" -> "Setting that up…"
        "get_weather" -> "Checking the weather…"
        "find_contact", "call_contact", "draft_message" -> "Looking up the contact…"
        else -> "Working on it…"
    }

    private companion object { const val MAX_STEPS = 5 }
}
