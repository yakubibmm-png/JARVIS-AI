package com.jarvis.ai.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream

sealed interface AttachResult {
    data class Ok(val attachment: PendingAttachment) : AttachResult
    data class Error(val message: String) : AttachResult
}

/** Turns a picked/captured Uri into something Gemini accepts: JPEG-downscaled image, PDF bytes, or text. */
object AttachmentLoader {
    private const val MAX_BYTES = 10 * 1024 * 1024
    private const val MAX_TEXT_CHARS = 200_000
    private val textExt = setOf("txt", "md", "csv", "json", "xml", "html", "css", "js", "ts", "kt", "java", "py", "c", "cpp", "h", "cs", "go", "rs", "sh", "yml", "yaml", "sql", "log")

    fun load(ctx: Context, uri: Uri): AttachResult {
        val resolver = ctx.contentResolver
        val mime = resolver.getType(uri).orEmpty()
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "attachment"
        val ext = name.substringAfterLast('.', "").lowercase()
        return try {
            when {
                mime.startsWith("image/") -> loadImage(ctx, uri, name)
                mime == "application/pdf" || ext == "pdf" -> {
                    val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: return AttachResult.Error("Couldn't read that file.")
                    if (bytes.size > MAX_BYTES) AttachResult.Error("That PDF is too large (limit 10 MB).")
                    else AttachResult.Ok(PendingAttachment(name, "application/pdf", bytes = bytes))
                }
                mime.startsWith("text/") || ext in textExt -> {
                    val text = resolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return AttachResult.Error("Couldn't read that file.")
                    AttachResult.Ok(PendingAttachment(name, "text/plain", text = text.take(MAX_TEXT_CHARS)))
                }
                else -> AttachResult.Error("This file type isn't supported. Try an image, PDF or text file.")
            }
        } catch (e: Exception) {
            AttachResult.Error("Couldn't read that file.")
        }
    }

    private fun loadImage(ctx: Context, uri: Uri, name: String): AttachResult {
        val resolver = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return AttachResult.Error("Couldn't read that image.")
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
        val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
            ?: return AttachResult.Error("Couldn't read that image.")
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        val thumb = Bitmap.createScaledBitmap(bmp, 96, (96f * bmp.height / bmp.width).toInt().coerceAtLeast(1), true)
        return AttachResult.Ok(PendingAttachment(name, "image/jpeg", bytes = out.toByteArray(), thumbnail = thumb))
    }
}
