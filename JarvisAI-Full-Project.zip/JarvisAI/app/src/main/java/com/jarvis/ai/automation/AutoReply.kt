package com.jarvis.ai.automation

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.ai.AssistantProfile
import com.jarvis.ai.ai.GeminiClient
import com.jarvis.ai.contacts.ContactsRepository
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.data.ModelRepository
import com.jarvis.ai.premium.PremiumRepository
import com.jarvis.ai.util.TextMatch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Receives notifications. It only looks at WhatsApp message notifications, and only when Auto Reply is ON. */
class JarvisNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        (applicationContext as? JarvisApp)?.container?.autoReply?.onNotification(sbn)
    }
}

/**
 * WhatsApp Auto Reply, done the way Android intends: the reply goes through the notification's own "Reply" action.
 * Requires: Pro + Automation ON + Auto Reply ON + Notification Access granted by the user. Groups are skipped unless
 * allowed. Rate-limited per contact. Every reply is logged on the Auto Reply screen. Message text is sent to Gemini
 * ONLY in AI mode.
 */
class AutoReplyManager(
    private val ctx: Context,
    private val settings: AutomationSettings,
    private val premium: PremiumRepository,
    private val gemini: GeminiClient,
    private val models: ModelRepository,
    private val contacts: ContactsRepository,
    private val prefs: AppPrefs,
    private val scope: CoroutineScope,
) {
    private val seen = LinkedHashMap<String, Long>()
    private val lastReplyAt = HashMap<String, Long>()
    private val sentTimes = ArrayDeque<Long>()

    fun isActive(): Boolean = premium.isPremium.value && settings.enabled.value && settings.autoReplyEnabled.value

    fun onNotification(sbn: StatusBarNotification) {
        if (sbn.packageName !in PACKAGES || !isActive()) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val lastMsg = style?.messages?.lastOrNull()
        val sender: String
        val text: String
        val isGroup: Boolean
        val context: List<String>
        if (lastMsg != null) {
            if (lastMsg.person == null) return // my own message
            sender = lastMsg.person?.name?.toString() ?: n.extras.getString(Notification.EXTRA_TITLE).orEmpty()
            text = lastMsg.text?.toString().orEmpty()
            isGroup = style?.isGroupConversation == true
            context = style?.messages?.takeLast(6)?.map { (it.person?.name?.toString() ?: "Me") + ": " + it.text }.orEmpty()
        } else {
            sender = n.extras.getString(Notification.EXTRA_TITLE).orEmpty()
            text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            isGroup = false
            context = listOf("$sender: $text")
        }
        if (text.isBlank() || sender.isBlank()) return
        if (isGroup && !settings.allowGroups) return
        val action = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return
        val remoteInputs = action.remoteInputs ?: return

        val now = System.currentTimeMillis()
        val key = "${sbn.key}|${lastMsg?.timestamp ?: text.hashCode()}"
        synchronized(this) {
            seen.entries.removeAll { now - it.value > 10 * 60_000 }
            if (seen.containsKey(key)) return
            seen[key] = now
            if (now - (lastReplyAt[sender] ?: 0L) < settings.cooldownSec * 1000L) return
            while (sentTimes.isNotEmpty() && now - sentTimes.first() > 3_600_000) sentTimes.removeFirst()
            if (sentTimes.size >= MAX_PER_HOUR) return
        }
        if (settings.onlyContacts && !isKnownContact(sender)) return

        scope.launch {
            val reply = try { compose(sender, text, context) } catch (e: Exception) { null }
            if (reply.isNullOrBlank()) { settings.addLog(ReplyLogEntry(now, sender, text.take(40), "", "No reply written")); return@launch }
            if (!isActive()) return@launch // switched off while the reply was being written
            val status = try {
                val results = Bundle()
                remoteInputs.forEach { results.putCharSequence(it.resultKey, reply) }
                val intent = Intent()
                android.app.RemoteInput.addResultsToIntent(remoteInputs, intent, results)
                action.actionIntent.send(ctx, 0, intent)
                synchronized(this@AutoReplyManager) { lastReplyAt[sender] = System.currentTimeMillis(); sentTimes.addLast(System.currentTimeMillis()) }
                "Sent through WhatsApp's reply action"
            } catch (e: Exception) { "Failed: ${e.javaClass.simpleName}" }
            settings.addLog(ReplyLogEntry(now, sender, text.take(40), reply, status))
        }
    }

    /** Also used by the "Preview" box on the Auto Reply screen (nothing is sent). */
    suspend fun compose(sender: String, message: String, context: List<String>): String? = when (settings.replyMode) {
        "RULES" -> settings.rules.value.firstOrNull { message.contains(it.keyword, ignoreCase = true) }?.reply ?: settings.defaultReply
        "AI" -> try {
            val me = AssistantProfile.from(prefs).userCallName.ifBlank { "the user" }
            gemini.oneShot(
                models.effective(premium.isPremium.value),
                "You write short WhatsApp replies on behalf of a busy person ($me). Style: ${settings.replyStyle} " +
                    "Write ONLY the reply text, in the same language as the incoming message, at most two short sentences. " +
                    "Never promise anything, never agree to money, meetings or sharing personal details; if unsure say they will reply soon.",
                "Recent conversation:\n${context.joinToString("\n")}\n\nWrite the reply to the last message from $sender.",
            ).take(500)
        } catch (e: Exception) { if (settings.aiFallback) settings.defaultReply else null }
        else -> settings.defaultReply
    }

    private fun isKnownContact(name: String): Boolean =
        contacts.hasPermission() && contacts.all().any { TextMatch.score(name, it.name) >= 90 || name.filter { c -> c.isDigit() }.let { d -> d.length >= 7 && it.numbers.any { p -> p.number.filter { c -> c.isDigit() }.endsWith(d.takeLast(7)) } } }

    companion object {
        val PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
        private const val MAX_PER_HOUR = 20
    }
}
