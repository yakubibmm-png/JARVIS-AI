package com.jarvis.ai.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.voice.VoiceState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Live waveform/particle line. IDLE: slow dim breathing. LISTENING: follows mic [level] (0..1).
 * THINKING: travelling pulse. SPEAKING: reacts to output level when supplied, else a lively wave.
 * Phase 2 feeds [level] from AudioRecord RMS / TTS output.
 */
@Composable
fun VoiceVisualizer(state: VoiceState, level: Float, modifier: Modifier = Modifier.fillMaxWidth().height(52.dp)) {
    val t = rememberInfiniteTransition(label = "viz")
    val phase by t.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(if (state == VoiceState.IDLE) 4200 else 2200, easing = LinearEasing)), label = "phase",
    )
    val smooth by animateFloatAsState(level, spring(stiffness = Spring.StiffnessMedium), label = "level")

    Canvas(modifier) {
        val n = 41
        val gap = size.width / (n + 1)
        val mid = size.height / 2f
        val dimmed = state == VoiceState.MUTED || state == VoiceState.SLEEPING || state == VoiceState.STOPPED || state == VoiceState.ERROR
        for (i in 0 until n) {
            val u = i / (n - 1f)
            val envelope = sin(PI * u).toFloat()
            val wave = 0.5f + 0.5f * sin(phase * (if (state == VoiceState.THINKING) 2f else 1f) + i * 0.55f)
            val h = when (state) {
                VoiceState.LISTENING -> (0.12f + 0.88f * smooth) * envelope * (0.4f + 0.6f * wave)
                VoiceState.THINKING -> {
                    val pos = phase / (2f * PI.toFloat())
                    val dd = abs(u - pos).let { min(it, 1f - it) }
                    0.12f + 0.88f * exp(-(dd * dd) / 0.012f)
                }
                VoiceState.SPEAKING -> (0.12f + 0.6f * max(smooth, 0.35f)) * envelope * (0.35f + 0.65f * wave)
                else -> 0.05f + 0.07f * wave * envelope
            }.coerceIn(0f, 1f)
            val barH = (h * size.height).coerceAtLeast(4f * density)
            val base = if (dimmed) JarvisColors.TextDim else JarvisColors.Cyan
            val alpha = if (dimmed) 0.35f else if (state == VoiceState.IDLE) 0.3f + 0.3f * wave else 0.35f + 0.65f * h
            drawLine(
                base.copy(alpha = alpha.coerceIn(0f, 1f)),
                Offset(gap * (i + 1), mid - barH / 2f), Offset(gap * (i + 1), mid + barH / 2f),
                strokeWidth = 3f * density, cap = StrokeCap.Round,
            )
        }
    }
}
