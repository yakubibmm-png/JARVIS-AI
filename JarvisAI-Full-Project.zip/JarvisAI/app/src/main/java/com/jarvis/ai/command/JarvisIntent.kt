package com.jarvis.ai.command

/** Intent categories from the master prompt. The Phase 3 command engine produces these from natural language. */
enum class JarvisIntent {
    OPEN_APP, INSTALL_APP, SEARCH, OPEN_URL, OPEN_CHAT, SEND_MESSAGE, READ_MESSAGE, CALL_CONTACT,
    TAP_ELEMENT, TYPE_TEXT, SCROLL, GO_BACK, SET_REMINDER, SET_ALARM, PLAY_MEDIA, GET_WEATHER,
    GET_TIME, CREATE_CODE, SCREEN_QUESTION, OPEN_SETTINGS, CHITCHAT, UNKNOWN,
}

data class ParsedCommand(
    val intent: JarvisIntent,
    val app: String? = null,
    val contact: String? = null,
    val text: String? = null,
    val query: String? = null,
    val time: String? = null,
    val uiTarget: String? = null,
    val confidence: Float = 0f,
)

/** Pipeline stage interfaces: understand -> plan -> execute -> report. Implemented in Phase 3+. */
interface CommandUnderstanding { suspend fun parse(utterance: String): ParsedCommand }
interface ActionExecutor { suspend fun execute(command: ParsedCommand): ActionResult }
sealed interface ActionResult {
    data class Success(val spokenSummary: String) : ActionResult
    data class NeedsClarification(val question: String) : ActionResult
    data class NeedsPermission(val message: String) : ActionResult
    data class Failed(val message: String) : ActionResult
}
