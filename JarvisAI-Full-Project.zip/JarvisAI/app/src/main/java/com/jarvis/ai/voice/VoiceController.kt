package com.jarvis.ai.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import com.jarvis.ai.chat.ConversationEngine
import com.jarvis.ai.command.AppForeground
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.data.CredentialsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * The voice conversation loop:  LISTENING -> THINKING -> SPEAKING -> (LISTENING again while the session is active).
 *
 *  MUTE   : stops the mic and JARVIS's voice but keeps the session; a reply still being generated shows as text only.
 *           Tap UNMUTE / the mic to resume listening.
 *  SLEEP  : ends everything and parks the assistant (SLEEPING). Tap the mic to wake it.
 *  STOP   : ends the session (STOPPED) until the user starts it again.
 *
 * Must be used from the main thread. Phase 3 plugs phone actions in through ConversationEngine's CommandRouter.
 */
class VoiceController(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val session: VoiceSessionHolder,
    private val engine: ConversationEngine,
    private val tts: TtsManager,
    private val speech: SpeechInput,
    private val creds: CredentialsRepository,
    private val prefs: AppPrefs,
    private val foreground: AppForeground,
) {
    private var turnJob: Job? = null
    private var speakJob: Job? = null
    private var sessionActive = false
    private var silentRounds = 0

    private val _readingId = MutableStateFlow<String?>(null)
    /** Chat message currently being read aloud (for the Read Aloud / Stop toggle). */
    val readingId: StateFlow<String?> = _readingId.asStateFlow()

    private val audio = ctx.getSystemService(AudioManager::class.java)
    private var focus: AudioFocusRequest? = null

    // ───────────── user actions ─────────────

    fun onMicPressed() {
        when (session.ui.value.state) {
            VoiceState.LISTENING -> speech.finish()                       // done talking: send now
            VoiceState.THINKING -> { cancelTurn(); endSession(VoiceState.IDLE) }
            VoiceState.SPEAKING -> { interruptSpeech(); startSession() }  // barge-in
            VoiceState.MUTED -> beginListening()                           // unmute
            else -> startSession()
        }
    }

    fun toggleMute() {
        if (session.ui.value.state == VoiceState.MUTED) { beginListening(); return }
        speech.cancel(); interruptSpeech()
        session.setState(VoiceState.MUTED)
    }

    fun sleep() { stopEverything(); session.setCaption(""); session.setState(VoiceState.SLEEPING) }

    fun stop() { stopEverything(); session.setCaption(""); session.setState(VoiceState.STOPPED) }

    /** Used by Chat before typing/dictating so voice never fights the text UI. */
    fun interruptAll() { stopEverything(); session.setCaption(""); session.setState(VoiceState.IDLE) }

    fun onAppBackgrounded() {
        speech.cancel() // the microphone can't be used while JARVIS is in the background
        if (foreground.recentlyLaunched()) {
            // JARVIS just opened another app: let it finish telling the user what happened, but don't listen again.
            if (session.ui.value.state == VoiceState.LISTENING) endSession(VoiceState.IDLE)
            return
        }
        if (session.ui.value.state != VoiceState.IDLE || _readingId.value != null) interruptAll()
    }

    /** Speaks an unprompted update (e.g. "installation finished") if JARVIS isn't busy. */
    fun announce(text: String) {
        if (session.ui.value.state == VoiceState.IDLE && _readingId.value == null) speakThen(text, listenAfter = false)
    }

    /** Chat "Read Aloud": toggles reading of one message. */
    fun readAloud(messageId: String, text: String) {
        if (_readingId.value == messageId) { interruptAll(); return }
        stopEverything()
        _readingId.value = messageId
        speakJob = scope.launch {
            session.setCaption("")
            session.setState(VoiceState.SPEAKING)
            try {
                tts.speak(text) { session.setLevel(it) }.note?.let { session.notify(it, if (it.contains("API key")) NoticeAction.ADD_KEY else null) }
                if (_readingId.value == messageId) session.setState(VoiceState.IDLE)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                session.notify("Couldn't play the voice. Please try again.")
                session.setState(VoiceState.IDLE)
            } finally {
                if (_readingId.value == messageId) _readingId.value = null
            }
        }
    }

    // ───────────── session flow ─────────────

    private fun startSession() {
        if (!creds.hasGeminiKey) {
            session.notify("Add your Gemini API key to start using JARVIS AI.", NoticeAction.ADD_KEY)
            return
        }
        stopEverything()
        sessionActive = true
        silentRounds = 0
        beginListening()
    }

    private fun beginListening() {
        if (!speech.isAvailable) {
            fail("Speech recognition isn't available on this device. You can still chat by typing.")
            return
        }
        sessionActive = true
        requestFocus()
        session.setCaption("")
        session.setState(VoiceState.LISTENING)
        speech.start(locale(), object : SpeechCallback {
            override fun onLevel(level: Float) = session.setLevel(level)
            override fun onPartial(text: String) = session.setCaption(text)
            override fun onFinal(text: String) = handleUtterance(text)
            override fun onError(error: SpeechError) {
                when (error) {
                    SpeechError.NO_SPEECH -> noSpeech()
                    SpeechError.PERMISSION -> fail("Microphone permission is required for voice input.", NoticeAction.OPEN_APP_SETTINGS)
                    SpeechError.NETWORK -> fail("Speech recognition needs an internet connection on this device.")
                    SpeechError.BUSY -> fail("The speech recognizer is busy. Please try again.")
                    SpeechError.UNAVAILABLE -> fail("Speech recognition isn't available right now.")
                    SpeechError.AUDIO, SpeechError.OTHER -> fail("I couldn't hear you. Please try again.")
                }
            }
        })
    }

    private fun noSpeech() {
        silentRounds++
        if (sessionActive && silentRounds < 2) beginListening() else endSession(VoiceState.IDLE)
    }

    private fun handleUtterance(text: String) {
        silentRounds = 0
        session.setCaption(text)
        session.setState(VoiceState.THINKING)
        turnJob = scope.launch {
            val outcome = engine.send(text, null, viaVoice = true, onStatus = { session.setCaption(it) })
            outcome.permissionHint?.let { session.notify(it, NoticeAction.OPEN_PERMISSIONS) }
            val muted = session.ui.value.state == VoiceState.MUTED
            if (outcome.error != null) {
                session.setCaption(outcome.error)
                if (muted) return@launch
                session.setState(VoiceState.ERROR)
                if (outcome.keyProblem) session.notify(outcome.error, NoticeAction.ADD_KEY)
                speakThen(outcome.error, listenAfter = false)
            } else {
                session.setCaption(outcome.text.take(220))
                if (muted) return@launch
                speakThen(outcome.text, listenAfter = sessionActive && prefs.continuousConversation)
            }
        }
    }

    private fun speakThen(text: String, listenAfter: Boolean) {
        speakJob?.cancel()
        speakJob = scope.launch {
            session.setState(VoiceState.SPEAKING)
            try {
                tts.speak(text) { session.setLevel(it) }.note?.let { session.notify(it, if (it.contains("API key")) NoticeAction.ADD_KEY else null) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                session.notify("Couldn't play the voice. Please try again.")
            }
            if (listenAfter && sessionActive && foreground.isForeground) beginListening() else endSession(VoiceState.IDLE)
        }
    }

    // ───────────── helpers ─────────────

    private fun cancelTurn() { turnJob?.cancel(); turnJob = null }

    private fun interruptSpeech() { speakJob?.cancel(); speakJob = null; tts.stop(); _readingId.value = null }

    private fun stopEverything() {
        speech.cancel()
        cancelTurn()
        interruptSpeech()
        sessionActive = false
        abandonFocus()
        session.setLevel(0f)
    }

    private fun endSession(state: VoiceState) {
        sessionActive = false
        abandonFocus()
        session.setState(state)
        if (state == VoiceState.IDLE) session.setCaption("")
    }

    private fun fail(message: String, action: NoticeAction? = null) {
        speech.cancel()
        sessionActive = false
        abandonFocus()
        session.setState(VoiceState.ERROR)
        session.notify(message, action)
        scope.launch {
            delay(4000)
            if (session.ui.value.state == VoiceState.ERROR) session.setState(VoiceState.IDLE)
        }
    }

    private fun locale(): Locale =
        prefs.speechLocaleTag.takeIf { it.isNotBlank() }?.let { Locale.forLanguageTag(it) } ?: Locale.getDefault()

    private fun requestFocus() {
        if (focus != null) return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .build()
        if (audio?.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) focus = req
    }

    private fun abandonFocus() {
        focus?.let { audio?.abandonAudioFocusRequest(it) }
        focus = null
    }
}
