package com.jarvis.ai.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.voice.VoiceState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Holographic particle sphere. ~280 points projected on the draw thread only (no recomposition per frame).
 * Energy rises with voice state/level. Infinite transitions stop automatically when the screen leaves composition.
 */
@Composable
fun AiOrb(modifier: Modifier = Modifier, state: VoiceState = VoiceState.IDLE, level: Float = 0f) {
    val points = remember { fibonacciSphere(280) }
    val transition = rememberInfiniteTransition(label = "orb")
    val angle by transition.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "angle",
    )
    val pulse by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse",
    )
    val energy = when (state) {
        VoiceState.IDLE -> 0.35f
        VoiceState.LISTENING -> 0.55f + level * 0.45f
        VoiceState.THINKING -> 0.8f
        VoiceState.SPEAKING -> 0.7f
        else -> 0.2f
    }

    Canvas(modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension * 0.36f * (1f + 0.025f * pulse * (0.5f + energy))

        drawCircle(
            Brush.radialGradient(listOf(JarvisColors.Cyan.copy(alpha = 0.08f + 0.18f * energy), Color.Transparent), center = c, radius = r * 1.7f),
            radius = r * 1.7f, center = c,
        )

        val cosA = cos(angle); val sinA = sin(angle)
        val tilt = 0.4f; val cosT = cos(tilt); val sinT = sin(tilt)
        val d = density
        for (i in 0 until 280) {
            val px = points[i * 3]; val py = points[i * 3 + 1]; val pz = points[i * 3 + 2]
            val x1 = px * cosA + pz * sinA
            val z1 = -px * sinA + pz * cosA
            val y2 = py * cosT - z1 * sinT
            val z2 = py * sinT + z1 * cosT
            val depth = (z2 + 1f) / 2f
            val alpha = ((0.15f + 0.85f * depth) * (0.5f + 0.5f * energy)).coerceIn(0f, 1f)
            drawCircle(JarvisColors.Cyan.copy(alpha = alpha), radius = (0.8f + 2.0f * depth) * d, center = Offset(c.x + x1 * r, c.y + y2 * r))
        }

        // Holographic base rings
        val baseY = c.y + r * 1.18f
        for (k in 0 until 3) {
            val w = r * (1.9f - k * 0.35f)
            val h = w * 0.16f
            drawOval(
                JarvisColors.Neon.copy(alpha = (0.55f - k * 0.15f) * (0.6f + 0.4f * energy)),
                topLeft = Offset(c.x - w / 2f, baseY - h / 2f), size = Size(w, h),
                style = Stroke(width = 1.5f * d),
            )
        }
    }
}

private fun fibonacciSphere(n: Int): FloatArray {
    val out = FloatArray(n * 3)
    val phi = (PI * (3.0 - sqrt(5.0))).toFloat()
    for (i in 0 until n) {
        val y = 1f - (i / (n - 1f)) * 2f
        val rad = sqrt(1f - y * y)
        val th = phi * i
        out[i * 3] = cos(th) * rad
        out[i * 3 + 1] = y
        out[i * 3 + 2] = sin(th) * rad
    }
    return out
}
