package com.jarvis.ai.premium

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

sealed interface LicenseResult {
    data object Valid : LicenseResult
    data class Invalid(val message: String) : LicenseResult
    data class TooManyAttempts(val seconds: Int) : LicenseResult
}

/**
 * Swap this implementation for a server-side license check later (e.g. POST key + device ID, receive a
 * signed token) without touching PremiumRepository or any UI.
 */
interface LicenseValidator {
    suspend fun validate(candidate: String): LicenseResult
}

/**
 * Compares SHA-256(key) to a build-time hash, so the plain key is not stored in the source or UI.
 * NOTE: a hash of a single shared key can still be brute-forced or the check patched out of an APK.
 */
class LocalKeyHashValidator(expectedHex: String) : LicenseValidator {
    private val expected: ByteArray? = expectedHex.takeIf { it.length == 64 }?.let { hex ->
        runCatching { ByteArray(32) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() } }.getOrNull()
    }

    override suspend fun validate(candidate: String): LicenseResult = withContext(Dispatchers.Default) {
        val exp = expected ?: return@withContext LicenseResult.Invalid("Premium is not configured in this build.")
        val digest = MessageDigest.getInstance("SHA-256").digest(candidate.trim().toByteArray(Charsets.UTF_8))
        if (MessageDigest.isEqual(digest, exp)) LicenseResult.Valid
        else LicenseResult.Invalid("That key isn't valid. Check it and try again.")
    }
}
