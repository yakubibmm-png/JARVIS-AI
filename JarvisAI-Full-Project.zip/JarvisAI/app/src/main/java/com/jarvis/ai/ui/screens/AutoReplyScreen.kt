package com.jarvis.ai.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.core.app.NotificationManagerCompat
import com.jarvis.ai.automation.ReplyRule
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.ChipGrid
import com.jarvis.ai.ui.components.Disclosure
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.LabeledField
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.SectionTitle
import com.jarvis.ai.ui.components.StatusText
import com.jarvis.ai.ui.components.SwitchRow
import com.jarvis.ai.ui.components.rememberResumeTick
import com.jarvis.ai.ui.theme.JarvisColors
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun AutoReplyScreen(onBack: () -> Unit, onOpenAutomation: () -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val s = c.automation
    val scope = rememberCoroutineScope()
    val enabled by s.enabled.collectAsState()
    val on by s.autoReplyEnabled.collectAsState()
    val rules by s.rules.collectAsState()
    val log by s.log.collectAsState()
    val isPro by c.premium.isPremium.collectAsState()
    val tick = rememberResumeTick()
    val access = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    var mode by remember { mutableStateOf(s.replyMode) }
    var def by remember { mutableStateOf(s.defaultReply) }
    var style by remember { mutableStateOf(s.replyStyle) }
    var groups by remember { mutableStateOf(s.allowGroups) }
    var onlyContacts by remember { mutableStateOf(s.onlyContacts) }
    var fallback by remember { mutableStateOf(s.aiFallback) }
    var cooldown by remember { mutableFloatStateOf(s.cooldownSec.toFloat()) }
    var kw by remember { mutableStateOf("") }
    var kwReply by remember { mutableStateOf("") }
    var sample by remember { mutableStateOf("Hello") }
    var preview by remember { mutableStateOf<String?>(null) }
    var askAccess by remember { mutableStateOf(false) }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

    ScreenScaffold("Auto Reply", "Reply to WhatsApp messages automatically", onBack) {
        GlassCard {
            SwitchRow(if (on) "Auto Reply is ON" else "Auto Reply is OFF", "Replies only to WhatsApp messages, through WhatsApp's own Reply action.", on, enabled = isPro) { s.setAutoReply(it) }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Pro", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f)); StatusText(isPro, "Active", "Needed") }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Automation master switch", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f)); StatusText(enabled); Spacer(Modifier.width(8.dp)); if (!enabled) NeonButton("Open", onOpenAutomation) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Notification Access", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f)); StatusText(access); Spacer(Modifier.width(8.dp)); if (!access) NeonButton("Enable", { askAccess = true }) }
            if (on && (!enabled || !access)) Text("Auto Reply will stay idle until the items above are ON.", color = JarvisColors.Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(10.dp))
            NeonButton("EMERGENCY OFF", { s.setAutoReply(false) }, Modifier.fillMaxWidth(), colors = listOf(Color(0xFFB91C1C), Color(0xFFEF4444)), enabled = on)
        }

        GlassCard {
            SectionTitle("How to reply")
            Spacer(Modifier.height(8.dp))
            ChipGrid(listOf("FIXED" to "One reply", "RULES" to "Keyword rules", "AI" to "AI (Gemini)"), mode, columns = 3) { mode = it; s.replyMode = it }
            Spacer(Modifier.height(10.dp))
            LabeledField(def, { def = it; s.defaultReply = it }, if (mode == "RULES") "Reply when no rule matches" else "Reply text", "e.g. I'll get back to you soon.")
            if (mode == "AI") {
                Spacer(Modifier.height(8.dp))
                LabeledField(style, { style = it; s.replyStyle = it }, "Style for AI replies", "e.g. Friendly, short, casual")
                SwitchRow("Use the reply text if AI fails", null, fallback) { fallback = it; s.aiFallback = it }
                Text("In AI mode the incoming message text is sent to Gemini to write the reply.", color = JarvisColors.Gold, fontSize = 11.sp)
            }
        }

        if (mode == "RULES") GlassCard {
            SectionTitle("Keyword rules", "The first rule whose keyword appears in the message is used. Example: \"how are you\" → \"I'm doing well. How are you?\"")
            Spacer(Modifier.height(8.dp))
            rules.forEach { r ->
                Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("“${r.keyword}”", color = JarvisColors.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold); Text(r.reply, color = Color.White, fontSize = 12.sp) }
                    Icon(Icons.Filled.Delete, "Delete rule", tint = JarvisColors.Danger, modifier = Modifier.clickable { s.removeRule(r) })
                }
            }
            LabeledField(kw, { kw = it }, "If the message contains", "hello")
            Spacer(Modifier.height(6.dp))
            LabeledField(kwReply, { kwReply = it }, "Reply with", "Hi!")
            Spacer(Modifier.height(6.dp))
            NeonButton("Add rule", { s.addRule(ReplyRule(kw.trim(), kwReply.trim())); kw = ""; kwReply = "" }, Modifier.fillMaxWidth(), enabled = kw.isNotBlank() && kwReply.isNotBlank())
        }

        GlassCard {
            SectionTitle("Safety")
            SwitchRow("Reply in groups too", "Off is safer: groups are skipped.", groups) { groups = it; s.allowGroups = it }
            Spacer(Modifier.height(8.dp))
            SwitchRow("Only people in my contacts", "Needs the Contacts permission.", onlyContacts) { onlyContacts = it; s.onlyContacts = it }
            Spacer(Modifier.height(8.dp))
            Text("Wait at least ${cooldown.toInt()} seconds between replies to the same person (and never more than 20 replies an hour).", color = Color.White, fontSize = 12.sp)
            Slider(cooldown, { cooldown = it }, valueRange = 30f..600f, onValueChangeFinished = { s.cooldownSec = cooldown.toInt() },
                colors = SliderDefaults.colors(thumbColor = JarvisColors.Cyan, activeTrackColor = JarvisColors.Blue, inactiveTrackColor = JarvisColors.Card))
        }

        GlassCard {
            SectionTitle("Try it", "See what JARVIS would reply. Nothing is sent.")
            Spacer(Modifier.height(8.dp))
            LabeledField(sample, { sample = it }, "Pretend someone wrote", "Hello")
            Spacer(Modifier.height(6.dp))
            NeonButton("Preview reply", { scope.launch { preview = c.autoReply.compose("Friend", sample, listOf("Friend: $sample")) ?: "No reply would be sent." } }, Modifier.fillMaxWidth(), filled = false, enabled = sample.isNotBlank())
            preview?.let { Text(it, color = JarvisColors.Cyan, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
        }

        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { SectionTitle("Reply log", "Kept only on this phone (first 40 characters of each message).") }
                if (log.isNotEmpty()) NeonButton("Clear", { s.clearLog() }, filled = false)
            }
            if (log.isEmpty()) Text("No automatic replies yet.", color = JarvisColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            log.take(20).forEach { e ->
                Column(Modifier.padding(top = 8.dp)) {
                    Text("${e.contact} · ${fmt.format(Date(e.at))}", color = JarvisColors.TextDim, fontSize = 11.sp)
                    Text("They: ${e.incoming}", color = Color.White, fontSize = 12.sp)
                    if (e.reply.isNotBlank()) Text("JARVIS: ${e.reply}", color = JarvisColors.Cyan, fontSize = 12.sp)
                    Text(e.status, color = if (e.status.startsWith("Sent")) JarvisColors.Success else JarvisColors.Gold, fontSize = 11.sp)
                }
            }
        }
    }
    if (askAccess) Disclosure("Notification Access", NOTIFICATION_DISCLOSURE, "Open settings", { askAccess = false; ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, { askAccess = false })
}
