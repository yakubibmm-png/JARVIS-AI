package com.jarvis.ai.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.jarvis.ai.BuildConfig
import com.jarvis.ai.ai.SuperProvider
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.reminders.Notifier
import com.jarvis.ai.screen.JarvisAccessibilityService
import com.jarvis.ai.ui.components.ChipGrid
import com.jarvis.ai.ui.components.Disclosure
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.SectionTitle
import com.jarvis.ai.ui.components.StatusText
import com.jarvis.ai.ui.components.SwitchRow
import com.jarvis.ai.ui.components.rememberResumeTick
import com.jarvis.ai.ui.nav.Routes
import com.jarvis.ai.ui.theme.Accent
import com.jarvis.ai.ui.theme.Appearance
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.util.Links
import com.jarvis.ai.util.openTelegram
import com.jarvis.ai.util.openUrl

@Composable
private fun LinkCard(title: String, subtitle: String, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text(subtitle, color = JarvisColors.TextDim, fontSize = 12.sp) }
            Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim, modifier = Modifier.size(20.dp))
        }
    }
}

// ───────────────────────── Notifications ─────────────────────────
@Composable
fun NotificationsScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val c = LocalContainer.current; val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val on = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    var spoken by remember { mutableStateOf(c.prefs.spokenReminders) }
    var voice by remember { mutableStateOf(c.prefs.voiceNotifications) }
    fun open(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Toast.makeText(ctx, "Couldn't open that settings page.", Toast.LENGTH_SHORT).show() } }
    fun channel(id: String) = open(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).putExtra(Settings.EXTRA_CHANNEL_ID, id))

    ScreenScaffold("Notifications", "Control your notifications", onBack) {
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("App notifications", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text("Reminders, install results and assistant status", color = JarvisColors.TextDim, fontSize = 12.sp) }
                StatusText(on); Spacer(Modifier.width(8.dp))
                NeonButton("Manage", { open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) }, filled = !on)
            }
        }
        GlassCard {
            SectionTitle("Voice", "Spoken alerts are a Pro feature.")
            Spacer(Modifier.height(8.dp))
            SwitchRow("Spoken reminders", "JARVIS says reminders aloud", spoken) { spoken = it; c.prefs.spokenReminders = it }
            Spacer(Modifier.height(8.dp))
            SwitchRow("Voice notifications", "Short spoken updates (installs, automation results)", voice) { voice = it; c.prefs.voiceNotifications = it }
        }
        GlassCard {
            SectionTitle("Notification style", "Sound, vibration and importance are set per category by Android.")
            Spacer(Modifier.height(8.dp))
            ChipGrid(listOf("reminders" to "Reminders", "assistant_events" to "Assistant events", "assistant_status" to "Background status"), null, columns = 2) { channel(it) }
        }
        LinkCard("Background assistant", "Status notification and background voice", { onNavigate(Routes.AUTOMATION) })
    }
}

// ───────────────────────── Privacy & Security ─────────────────────────
@Composable
fun PrivacyScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val c = LocalContainer.current; val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val chats by c.chatRepository.conversations.collectAsState()
    val reminders by c.reminderStore.items.collectAsState()
    val log by c.automation.log.collectAsState()
    val a11y by JarvisAccessibilityService.connected.collectAsState()
    val sharing by c.screenShare.active.collectAsState()
    val access = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    var history by remember { mutableStateOf(c.prefs.chatHistoryEnabled) }
    var confirm by remember { mutableStateOf<String?>(null) }

    ScreenScaffold("Privacy & Security", "Keep your data safe", onBack) {
        GlassCard {
            SectionTitle("What JARVIS does with your data")
            Text("• Chats, reminders, shortcuts and settings are stored on this phone (in the app's private storage; chats are not separately encrypted).\n• API keys and your Pro status are stored in Android's encrypted storage.\n• What you say or type is sent to the AI service you chose (Gemini by default) to answer you. Voice and text-to-speech may use Google, Gemini or ElevenLabs.\n• Contacts are looked up on the phone; phone numbers are not sent to the AI.\n• Screen text or a screenshot is sent only when you ask a question about the screen.\n• There is no hidden recording, no ads and no analytics in this app.", color = JarvisColors.TextDim, fontSize = 12.sp)
        }
        GlassCard {
            SectionTitle("Sensitive access right now")
            Spacer(Modifier.height(8.dp))
            listOf("Accessibility Service" to a11y, "Notification Access" to access, "Screen Share" to sharing).forEach { (n, v) ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) { Text(n, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f)); StatusText(v) }
            }
            Spacer(Modifier.height(8.dp))
            NeonButton("Open Permissions", { onNavigate(Routes.PERMISSIONS) }, Modifier.fillMaxWidth(), filled = false)
        }
        GlassCard {
            SwitchRow("Save chat history", "Off keeps chats only until you close the app and removes the saved file.", history) { history = it; c.chatRepository.setHistoryEnabled(it) }
        }
        GlassCard {
            SectionTitle("Local storage", "${chats.count { it.messages.isNotEmpty() }} chats · ${reminders.size} reminders · ${log.size} auto-reply log entries")
            Spacer(Modifier.height(8.dp))
            NeonButton("Clear all chats", { confirm = "chats" }, Modifier.fillMaxWidth(), filled = false)
            Spacer(Modifier.height(8.dp))
            NeonButton("Clear memory of recent actions", { c.actionMemory.clear(); Toast.makeText(ctx, "Cleared", Toast.LENGTH_SHORT).show() }, Modifier.fillMaxWidth(), filled = false)
            Spacer(Modifier.height(8.dp))
            NeonButton("Clear auto-reply log", { c.automation.clearLog() }, Modifier.fillMaxWidth(), filled = false, enabled = log.isNotEmpty())
            Spacer(Modifier.height(8.dp))
            NeonButton("Remove all saved API keys", { confirm = "keys" }, Modifier.fillMaxWidth(), colors = listOf(Color(0xFFB91C1C), Color(0xFFEF4444)))
        }
    }
    when (confirm) {
        "chats" -> Disclosure("Clear all chats?", "Every conversation on this phone will be deleted.", "Clear", { c.chatRepository.clearAll(); confirm = null }, { confirm = null })
        "keys" -> Disclosure("Remove all API keys?", "Your Gemini, ElevenLabs and Super AI keys will be deleted from this phone. Pro stays active.", "Remove", {
            c.credentials.setGeminiKey(""); c.credentials.setElevenLabsKey(""); SuperProvider.entries.forEach { if (it != SuperProvider.GEMINI) c.superAi.setKey(it, "") }; confirm = null
        }, { confirm = null })
        else -> Unit
    }
}

// ───────────────────────── Appearance ─────────────────────────
@Composable
fun AppearanceScreen(onBack: () -> Unit) {
    val prefs = LocalContainer.current.prefs
    ScreenScaffold("Appearance", "Customize your app look", onBack) {
        GlassCard {
            SectionTitle("Theme", "JARVIS uses its dark futuristic theme.")
        }
        GlassCard {
            SectionTitle("Accent color")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accent.options.forEachIndexed { i, o ->
                    val sel = Accent.index == i
                    Box(Modifier.size(40.dp).clip(CircleShape).border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.Transparent, CircleShape).clickable { Accent.select(i); prefs.accentIndex = i }.padding(5.dp)) {
                        Box(Modifier.size(30.dp).clip(CircleShape).border(15.dp, o.primary, CircleShape))
                    }
                }
            }
            Text("Some icons update after you reopen the app.", color = JarvisColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
        GlassCard {
            SectionTitle("Font size", "Applies to the whole app")
            Spacer(Modifier.height(8.dp))
            ChipGrid(Appearance.fontScales.mapIndexed { i, p -> i.toString() to p.first }, Appearance.fontIndex.toString(), columns = 2) { Appearance.selectFont(it.toInt()); prefs.fontScaleIndex = it.toInt() }
        }
        GlassCard {
            SectionTitle("AI avatar")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(Appearance.avatarCount) { i ->
                    val sel = Appearance.avatar == i
                    Image(painterResource(Appearance.avatarRes(i)), Appearance.avatarNames[i], Modifier.size(60.dp).clip(CircleShape).border(if (sel) 3.dp else 1.dp, if (sel) JarvisColors.Cyan else JarvisColors.Blue.copy(alpha = 0.5f), CircleShape).clickable { Appearance.selectAvatar(i); prefs.avatarIndex = i })
                }
            }
        }
        NeonButton("Reset appearance", { Accent.select(0); Appearance.selectAvatar(0); Appearance.selectFont(1); prefs.accentIndex = 0; prefs.avatarIndex = 0; prefs.fontScaleIndex = 1 }, Modifier.fillMaxWidth(), filled = false)
    }
}

// ───────────────────────── About ─────────────────────────
@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var privacy by remember { mutableStateOf(false) }
    fun market() = ctx.openUrl("market://details?id=${ctx.packageName}") || ctx.openUrl("https://play.google.com/store/apps/details?id=${ctx.packageName}")
    ScreenScaffold("About", "App information & support", onBack) {
        GlassCard {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(Appearance.avatarRes()), null, Modifier.size(84.dp).clip(CircleShape).border(2.dp, JarvisColors.Cyan, CircleShape))
                Spacer(Modifier.height(8.dp))
                Text("JARVIS AI", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                Text("Your Smart AI Assistant", color = JarvisColors.TextDim, fontSize = 13.sp, textAlign = TextAlign.Center)
                Text("Version ${BuildConfig.VERSION_NAME}", color = JarvisColors.Cyan, fontSize = 13.sp)
            }
        }
        LinkCard("Privacy summary", "What JARVIS does with your data") { privacy = true }
        LinkCard("Help & Support", "Chat with support on Telegram (@${Links.TELEGRAM_USERNAME})") { if (!ctx.openTelegram()) Toast.makeText(ctx, "Couldn't open Telegram or a browser.", Toast.LENGTH_SHORT).show() }
        LinkCard("Rate Us", "Opens the Google Play page when the app is published") { if (!market()) Toast.makeText(ctx, "Google Play isn't available.", Toast.LENGTH_SHORT).show() }
        LinkCard("Share App", "Send JARVIS AI to a friend") {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "Try JARVIS AI, a smart AI assistant for Android.")
            try { ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Toast.makeText(ctx, "Nothing to share with.", Toast.LENGTH_SHORT).show() }
        }
        LinkCard("Check for Updates", "Opens the app's Google Play page") { if (!market()) Toast.makeText(ctx, "Google Play isn't available.", Toast.LENGTH_SHORT).show() }
    }
    if (privacy) Disclosure(
        "Privacy summary",
        "• Chats, reminders, shortcuts and settings stay on this phone.\n• API keys and Pro status are kept in Android's encrypted storage.\n• What you say or type goes to the AI provider you selected to be answered.\n• Contacts stay on the phone. Screen content is sent only when you ask about the screen.\n• Accessibility, Notification Access and Screen Share are used only when you switch them on, for the feature you asked for.\n• Nothing is sent, paid or deleted for you without your confirmation.",
        "OK", { privacy = false }, { privacy = false },
    )
}
