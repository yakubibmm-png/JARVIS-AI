package com.jarvis.ai.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class VoiceState(val label: String) {
    IDLE("Tap to speak"),
    LISTENING("Listening…"),
    THINKING("Thinking…"),
    SPEAKING("Speaking…"),
    MUTED("Muted"),
    SLEEPING("Sleeping"),
    STOPPED("Stopped"),
    ERROR("Something went wrong"),
}

enum class NoticeAction { ADD_KEY, OPEN_APP_SETTINGS, OPEN_PERMISSIONS }

/** A one-off message for the UI (snackbar). [id] makes the same text re-trigger. */
data class VoiceNotice(val id: Long, val text: String, val action: NoticeAction? = null)

data class VoiceUiState(
    val state: VoiceState = VoiceState.IDLE,
    val level: Float = 0f,
    val caption: String = "",
    val notice: VoiceNotice? = null,
)

/** UI-facing voice state. [VoiceController] drives it; the orb, waveform and Home controls read it. */
class VoiceSessionHolder {
    private val _ui = MutableStateFlow(VoiceUiState())
    val ui: StateFlow<VoiceUiState> = _ui.asStateFlow()

    fun setState(state: VoiceState) = _ui.update {
        it.copy(state = state, level = if (state == VoiceState.LISTENING || state == VoiceState.SPEAKING) it.level else 0f)
    }
    fun setLevel(level: Float) = _ui.update { it.copy(level = level.coerceIn(0f, 1f)) }
    fun setCaption(text: String) = _ui.update { it.copy(caption = text) }
    fun notify(text: String, action: NoticeAction? = null) = _ui.update { it.copy(notice = VoiceNotice(System.nanoTime(), text, action)) }

    // Kept from Phase 1; the controller now owns the real behaviour.
    fun mute() = setState(VoiceState.MUTED)
    fun sleep() = setState(VoiceState.SLEEPING)
    fun stop() = setState(VoiceState.STOPPED)
}
