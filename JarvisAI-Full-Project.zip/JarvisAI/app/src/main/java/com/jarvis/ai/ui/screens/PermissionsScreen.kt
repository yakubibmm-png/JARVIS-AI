package com.jarvis.ai.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Alarm
import android.app.AlarmManager
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.premium.PremiumFeature
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ProBadge
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.theme.JarvisColors
import android.content.ActivityNotFoundException
import android.widget.Toast

private sealed interface Grant {
    data class Runtime(val permission: String) : Grant
    data class SystemScreen(val action: String) : Grant
    data object None : Grant
}

private class PermItem(
    val title: String,
    val why: String,
    val icon: ImageVector,
    val tint: Color,
    val grant: Grant,
    val feature: PremiumFeature? = null,
    val isOn: (Context) -> Boolean?,   // null = not a persistent permission
)

private fun granted(ctx: Context, p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

private val items = listOf(
    PermItem("Microphone", "Required for voice input.", Icons.Filled.Mic, JarvisColors.Neon, Grant.Runtime(Manifest.permission.RECORD_AUDIO)) { granted(it, Manifest.permission.RECORD_AUDIO) },
    PermItem("Notifications", "Shows reminders and assistant status alerts.", Icons.Filled.Notifications, JarvisColors.Blue, Grant.Runtime(Manifest.permission.POST_NOTIFICATIONS)) {
        if (Build.VERSION.SDK_INT >= 33) granted(it, Manifest.permission.POST_NOTIFICATIONS) else NotificationManagerCompat.from(it).areNotificationsEnabled()
    },
    PermItem("Contacts", "Lets JARVIS work out which person you mean when you say a name.", Icons.Filled.Contacts, JarvisColors.Cyan, Grant.Runtime(Manifest.permission.READ_CONTACTS)) { granted(it, Manifest.permission.READ_CONTACTS) },
    PermItem("Location", "Used only for local weather when you don't name a city (approximate location).", Icons.Filled.LocationOn, JarvisColors.Success, Grant.Runtime(Manifest.permission.ACCESS_COARSE_LOCATION)) { granted(it, Manifest.permission.ACCESS_COARSE_LOCATION) || granted(it, Manifest.permission.ACCESS_FINE_LOCATION) },
    PermItem("Alarms & reminders", "Lets reminders fire at the exact minute. Without it Android may deliver them a few minutes late.", Icons.Filled.Alarm, JarvisColors.Magenta, Grant.SystemScreen(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) {
        Build.VERSION.SDK_INT < 31 || it.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    },
    PermItem("Phone / Calls", "Required only to place calls when you ask JARVIS to call someone.", Icons.Filled.Call, JarvisColors.Success, Grant.Runtime(Manifest.permission.CALL_PHONE)) { granted(it, Manifest.permission.CALL_PHONE) },
    PermItem("Accessibility Service", "Allows supported screen interaction and automation after you enable the service.", Icons.Filled.Accessibility, JarvisColors.Purple, Grant.SystemScreen(Settings.ACTION_ACCESSIBILITY_SETTINGS), PremiumFeature.ACCESSIBILITY_CONTROL) { ctx ->
        val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        enabled.split(':').any { it.startsWith(ctx.packageName + "/") }
    },
    PermItem("Notification Access", "Allows supported notification and message awareness, including WhatsApp where supported.", Icons.Filled.NotificationsActive, JarvisColors.Gold, Grant.SystemScreen(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS), PremiumFeature.NOTIFICATION_ACCESS) {
        NotificationManagerCompat.getEnabledListenerPackages(it).contains(it.packageName)
    },
    PermItem("Background operation", "Lets reminders and approved automation keep working when the app is closed.", Icons.Filled.BatteryChargingFull, Color(0xFFF59E0B), Grant.SystemScreen(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) {
        (it.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(it.packageName)
    },
    PermItem("Screen Share", "Allows JARVIS to understand visible screen content while sharing is active. Android asks for your consent every time you start it.", Icons.Filled.ScreenShare, JarvisColors.Magenta, Grant.None, PremiumFeature.SCREEN_SHARE) { null },
)

@Composable
fun PermissionsScreen(onBack: () -> Unit, onGate: (PremiumFeature) -> Unit) {
    val ctx = LocalContext.current
    val isPremium by LocalContainer.current.premium.isPremium.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var disclosure by remember { mutableStateOf<String?>(null) }

    // Re-check statuses whenever the user returns from a system settings screen.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val states = remember(tick) { items.map { it.isOn(ctx) } }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    fun openSystem(action: String) {
        try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "This settings screen isn't available on your device.", Toast.LENGTH_SHORT).show() }
    }
    fun appSettings() {
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Couldn't open app settings.", Toast.LENGTH_SHORT).show() }
    }

    disclosure?.let { which ->
        val acc = which == "Accessibility Service"
        com.jarvis.ai.ui.components.Disclosure(
            which, if (acc) ACCESSIBILITY_DISCLOSURE else NOTIFICATION_DISCLOSURE, "Open settings",
            { disclosure = null; openSystem(if (acc) Settings.ACTION_ACCESSIBILITY_SETTINGS else Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }, { disclosure = null },
        )
    }

    ScreenScaffold("Permissions", "Grant only what you need, when you need it", onBack) {
                items.forEachIndexed { idx, p ->
            val on = states[idx]
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(p.icon, p.tint, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(p.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (p.feature != null) { Spacer(Modifier.width(6.dp)); ProBadge(locked = !isPremium) }
                        }
                        Text(p.why, color = JarvisColors.TextDim, fontSize = 12.sp)
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    val (label, color) = when (on) {
                        true -> "ON" to JarvisColors.Success
                        false -> "OFF" to JarvisColors.Danger
                        null -> "Asked each time" to JarvisColors.TextDim
                    }
                    Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    if (p.grant !is Grant.None) {
                        NeonButton(if (on == true) "Manage" else "Enable", {
                            if (p.feature != null && !isPremium) { onGate(p.feature); return@NeonButton }
                            when (val g = p.grant) {
                                is Grant.Runtime -> if (on == true) appSettings() else if (Build.VERSION.SDK_INT < 33 && g.permission == Manifest.permission.POST_NOTIFICATIONS) appSettings() else launcher.launch(g.permission)
                                is Grant.SystemScreen -> if (p.title == "Accessibility Service" || p.title == "Notification Access") disclosure = p.title else openSystem(g.action)
                                Grant.None -> Unit
                            }
                        }, filled = on != true)
                    }
                }
            }
        }
        NeonButton("Manage All Permissions", { appSettings() }, Modifier.fillMaxWidth(), filled = false)
        Text("If a permission prompt doesn't appear, Android may have blocked it. Use Manage All Permissions to change it in system settings.", color = JarvisColors.TextDim, fontSize = 11.sp)
    }
}
