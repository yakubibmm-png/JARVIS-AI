package com.jarvis.ai.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

fun Context.isOnline(): Boolean {
    val cm = getSystemService(ConnectivityManager::class.java) ?: return true
    val net = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(net) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
}

/**
 * Opens a connection that is force-closed if the calling coroutine is cancelled (so blocking reads end promptly).
 * IOExceptions are rethrown for the caller to map; if the coroutine was cancelled they become CancellationException.
 */
suspend fun <T> withConnection(url: String, configure: (HttpURLConnection) -> Unit, block: suspend (HttpURLConnection) -> T): T {
    val conn = URL(url).openConnection() as HttpURLConnection
    val job = currentCoroutineContext()[Job]
    val handle = job?.invokeOnCompletion { conn.disconnect() }
    try {
        configure(conn)
        return block(conn)
    } catch (e: IOException) {
        if (job?.isActive == false) throw CancellationException("cancelled")
        throw e
    } finally {
        handle?.dispose()
        conn.disconnect()
    }
}
