package com.jarvis.ai.ui.screens

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.ai.apps.AppInfo
import com.jarvis.ai.automation.TriggerEvents
import com.jarvis.ai.contacts.Contact
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.ChipGrid
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.LabeledField
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.SectionTitle
import com.jarvis.ai.ui.nav.Routes
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.util.TextMatch
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

private fun pickDateTime(ctx: Context, onPicked: (Calendar) -> Unit) {
    val now = Calendar.getInstance()
    DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, min -> onPicked(Calendar.getInstance().apply { set(y, m, d, h, min, 0); set(Calendar.MILLISECOND, 0) }) },
            now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), android.text.format.DateFormat.is24HourFormat(ctx)).show()
    }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
}

private val repeatOptions = listOf("none" to "Once", "daily" to "Daily", "weekly" to "Weekly")
private val fmt: DateFormat = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)

@Composable
private fun Row2(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
            }
            trailing()
        }
    }
}

@Composable
private fun AppPicker(selected: AppInfo?, onSelect: (AppInfo) -> Unit) {
    val c = LocalContainer.current
    var q by remember { mutableStateOf("") }
    val all = remember { c.installedApps.all() }
    val shown = if (q.isBlank()) all.take(5) else all.filter { it.label.contains(q, true) || TextMatch.score(q, it.label) >= 70 }.take(5)
    LabeledField(q, { q = it }, "App", selected?.let { "Selected: ${it.label}" } ?: "Type an app name")
    shown.forEach { a ->
        Text(a.label + if (selected?.pkg == a.pkg) "  ✓" else "", color = if (selected?.pkg == a.pkg) JarvisColors.Cyan else Color.White, fontSize = 14.sp,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onSelect(a) }.padding(vertical = 8.dp, horizontal = 4.dp))
    }
}

// ───────────────────── Task Scheduler ─────────────────────
@Composable
fun TasksScreen(onBack: () -> Unit) {
    val c = LocalContainer.current; val ctx = LocalContext.current
    val tasks by c.automationItems.tasks.collectAsState()
    val enabled by c.automation.enabled.collectAsState()
    var command by remember { mutableStateOf("") }
    var at by remember { mutableStateOf<Calendar?>(null) }
    var repeat by remember { mutableStateOf("none") }
    ScreenScaffold("Task Scheduler", "Run your own commands at set times", onBack) {
        if (!enabled) Text("Automation is OFF, so scheduled tasks will not run. Turn it on in Automation.", color = JarvisColors.Gold, fontSize = 12.sp)
        GlassCard {
            SectionTitle("New task", "Write it the way you would say it to JARVIS, e.g. \"What's the weather today?\"")
            Spacer(Modifier.height(8.dp))
            LabeledField(command, { command = it }, "Command", "What should JARVIS do?")
            Spacer(Modifier.height(8.dp))
            NeonButton(at?.let { fmt.format(it.time) } ?: "Pick date & time", { pickDateTime(ctx) { at = it } }, Modifier.fillMaxWidth(), icon = Icons.Filled.Schedule, filled = false)
            Spacer(Modifier.height(8.dp))
            ChipGrid(repeatOptions, repeat) { repeat = it }
            Spacer(Modifier.height(8.dp))
            NeonButton("Add task", {
                val t = c.automationItems.addTask(command.trim().take(40), command.trim(), at!!.timeInMillis, repeat, null)
                c.taskScheduler.schedule(t); command = ""; at = null; repeat = "none"
            }, Modifier.fillMaxWidth(), enabled = command.isNotBlank() && at != null && at!!.timeInMillis > System.currentTimeMillis())
            Text("Tasks that open other apps ask first or use a notification, because Android blocks silent app launches.", color = JarvisColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
        tasks.filter { it.launchPkg == null }.forEach { t ->
            Row2(t.command, fmt.format(Date(t.triggerAt)) + if (t.repeat != "none") " · ${t.repeat}" else "") {
                Icon(Icons.Filled.Delete, "Delete task", tint = JarvisColors.Danger, modifier = Modifier.clickable { c.taskScheduler.cancel(t.id) }.padding(6.dp))
            }
        }
    }
}

// ───────────────────── App Launch ─────────────────────
@Composable
fun LaunchScreen(onBack: () -> Unit) {
    val c = LocalContainer.current; val ctx = LocalContext.current
    val tasks by c.automationItems.tasks.collectAsState()
    var app by remember { mutableStateOf<AppInfo?>(null) }
    var at by remember { mutableStateOf<Calendar?>(null) }
    var repeat by remember { mutableStateOf("none") }
    ScreenScaffold("App Launch", "Open apps with voice or time", onBack) {
        GlassCard {
            SectionTitle("By voice", "Just say \"Open <app name>\" for any app on your phone.")
        }
        GlassCard {
            SectionTitle("At a set time", "At that time JARVIS opens the app, or shows a notification you tap if Android won't allow a silent launch.")
            Spacer(Modifier.height(8.dp))
            AppPicker(app) { app = it }
            Spacer(Modifier.height(8.dp))
            NeonButton(at?.let { fmt.format(it.time) } ?: "Pick date & time", { pickDateTime(ctx) { at = it } }, Modifier.fillMaxWidth(), icon = Icons.Filled.Schedule, filled = false)
            Spacer(Modifier.height(8.dp))
            ChipGrid(repeatOptions, repeat) { repeat = it }
            Spacer(Modifier.height(8.dp))
            NeonButton("Schedule", {
                val a = app!!
                val t = c.automationItems.addTask("Open ${a.label}", "", at!!.timeInMillis, repeat, a.pkg)
                c.taskScheduler.schedule(t); app = null; at = null; repeat = "none"
            }, Modifier.fillMaxWidth(), enabled = app != null && at != null && at!!.timeInMillis > System.currentTimeMillis())
        }
        tasks.filter { it.launchPkg != null }.forEach { t ->
            Row2(t.label, fmt.format(Date(t.triggerAt)) + if (t.repeat != "none") " · ${t.repeat}" else "") {
                Icon(Icons.Filled.Delete, "Delete", tint = JarvisColors.Danger, modifier = Modifier.clickable { c.taskScheduler.cancel(t.id) }.padding(6.dp))
            }
        }
    }
}

// ───────────────────── Smart Triggers ─────────────────────
@Composable
fun TriggersScreen(onBack: () -> Unit, onOpenAutomation: () -> Unit) {
    val c = LocalContainer.current
    val items by c.automationItems.triggers.collectAsState()
    var event by remember { mutableStateOf(TriggerEvents.all.first().first) }
    var command by remember { mutableStateOf("") }
    ScreenScaffold("Smart Triggers", "Run commands when something changes", onBack) {
        if (!c.prefs.backgroundAssistant) GlassCard {
            Text("Triggers work while the Background assistant is ON (it shows a \"JARVIS is active\" notification).", color = JarvisColors.Gold, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp)); NeonButton("Open Automation", onOpenAutomation, Modifier.fillMaxWidth(), filled = false)
        }
        GlassCard {
            SectionTitle("New trigger")
            Spacer(Modifier.height(8.dp))
            ChipGrid(TriggerEvents.all, event, columns = 2) { event = it }
            Spacer(Modifier.height(8.dp))
            LabeledField(command, { command = it }, "Then JARVIS should", "e.g. Set a reminder in 10 minutes to unplug")
            Spacer(Modifier.height(8.dp))
            NeonButton("Add trigger", { c.automationItems.addTrigger(event, command.trim()); command = "" }, Modifier.fillMaxWidth(), enabled = command.isNotBlank())
        }
        items.forEach { t ->
            Row2(TriggerEvents.label(t.event), t.command) { Icon(Icons.Filled.Delete, "Delete trigger", tint = JarvisColors.Danger, modifier = Modifier.clickable { c.automationItems.removeTrigger(t.id) }.padding(6.dp)) }
        }
    }
}

// ───────────────────── Custom Actions ─────────────────────
@Composable
fun ActionsScreen(onBack: () -> Unit) {
    val c = LocalContainer.current
    val items by c.automationItems.actions.collectAsState()
    val enabled by c.automation.enabled.collectAsState()
    var name by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    ScreenScaffold("Custom Actions", "Your own shortcuts", onBack) {
        GlassCard {
            SectionTitle("New action", "Say \"Run my <name> action\" or tap Run. Example: Good morning → \"Tell me the weather and the time\".")
            Spacer(Modifier.height(8.dp))
            LabeledField(name, { name = it }, "Name", "Good morning")
            Spacer(Modifier.height(6.dp))
            LabeledField(command, { command = it }, "What JARVIS should do", "Tell me the weather and the time")
            Spacer(Modifier.height(8.dp))
            NeonButton("Save action", { c.automationItems.addAction(name.trim(), command.trim()); name = ""; command = "" }, Modifier.fillMaxWidth(), enabled = name.isNotBlank() && command.isNotBlank())
        }
        if (!enabled) Text("Automation is OFF: Run is disabled.", color = JarvisColors.Gold, fontSize = 12.sp)
        items.forEach { a ->
            Row2(a.name, a.command) {
                NeonButton("Run", { c.automationRunner.run(a.name, a.command) }, filled = false, icon = Icons.Filled.PlayArrow, enabled = enabled)
                Icon(Icons.Filled.Delete, "Delete action", tint = JarvisColors.Danger, modifier = Modifier.clickable { c.automationItems.removeAction(a.id) }.padding(6.dp))
            }
        }
    }
}

// ───────────────────── Saved contact shortcuts ─────────────────────
@Composable
fun AliasesScreen(onBack: () -> Unit) {
    val c = LocalContainer.current; val ctx = LocalContext.current
    val aliases by c.aliasStore.all.collectAsState()
    var alias by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<Contact?>(null) }
    var granted by remember { mutableStateOf(c.contacts.hasPermission()) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    ScreenScaffold("Contact Shortcuts", "Say \"Message 72 on WhatsApp: hello\"", onBack) {
        if (!granted) GlassCard {
            Text("JARVIS needs the Contacts permission to pick a contact. Contact names and numbers stay on this phone.", color = JarvisColors.Gold, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp)); NeonButton("Allow contacts", { perm.launch(Manifest.permission.READ_CONTACTS) }, Modifier.fillMaxWidth())
        }
        GlassCard {
            SectionTitle("New shortcut")
            Spacer(Modifier.height(8.dp))
            LabeledField(alias, { alias = it }, "Shortcut (a word or number you will say)", "72")
            Spacer(Modifier.height(8.dp))
            LabeledField(query, { query = it; picked = null }, "Contact", picked?.let { "Selected: ${it.name}" } ?: "Search your contacts")
            if (granted && query.isNotBlank()) c.contacts.search(query).take(5).forEach { ct ->
                Text(ct.name + if (picked?.key == ct.key) "  ✓" else "", color = if (picked?.key == ct.key) JarvisColors.Cyan else Color.White, fontSize = 14.sp,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { picked = ct }.padding(vertical = 8.dp, horizontal = 4.dp))
            }
            Spacer(Modifier.height(8.dp))
            NeonButton("Save shortcut", { c.aliasStore.set(alias.trim(), picked!!.key, picked!!.name); alias = ""; query = ""; picked = null }, Modifier.fillMaxWidth(), enabled = alias.isNotBlank() && picked != null)
        }
        aliases.forEach { a ->
            Row2("“${a.alias}” → ${a.contactName}", "Works in voice and chat commands") {
                Icon(Icons.Filled.Delete, "Delete shortcut", tint = JarvisColors.Danger, modifier = Modifier.clickable { c.aliasStore.remove(a.alias) }.padding(6.dp))
            }
        }
    }
}

// ───────────────────── More Features hub ─────────────────────
@Composable
fun MoreFeaturesScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    ScreenScaffold("More Features", "Explore additional tools & services", onBack) {
        listOf(
            Triple("Contact Shortcuts", "Say a number or nickname for a saved contact", Routes.ALIASES),
            Triple("Custom Actions", "Your own named shortcuts", Routes.AUTO_ACTIONS),
            Triple("Smart Triggers", "Charger, headphones and Wi-Fi triggers", Routes.AUTO_TRIGGERS),
            Triple("Task Scheduler", "Run commands at set times", Routes.AUTO_TASKS),
            Triple("App Launch", "Open apps at set times", Routes.AUTO_LAUNCH),
            Triple("Auto Reply log", "See every automatic WhatsApp reply", Routes.AUTO_REPLY),
            Triple("Automation & background assistant", "Master switch, Screen Share, spoken reminders", Routes.AUTOMATION),
            Triple("Super AI", "Use another AI provider for answers", Routes.SUPER_AI),
        ).forEach { (t, s, r) ->
            GlassCard(Modifier.fillMaxWidth(), onClick = { onNavigate(r) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(t, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp); Text(s, color = JarvisColors.TextDim, fontSize = 12.sp) }
                    Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}
