package com.jarvis.ai.command.handlers

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import androidx.core.app.NotificationManagerCompat
import com.jarvis.ai.command.ActionOutcome
import com.jarvis.ai.reminders.ReminderScheduler
import com.jarvis.ai.reminders.ReminderStore
import com.jarvis.ai.weather.WeatherRepository
import com.jarvis.ai.weather.WeatherResult
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

/** Time, weather, reminders and alarms. */
class InfoHandlers(
    private val ctx: Context,
    private val weather: WeatherRepository,
    private val store: ReminderStore,
    private val scheduler: ReminderScheduler,
) {
    private val en = Locale.ENGLISH

    // ───────── time ─────────
    fun time(args: JSONObject): ActionOutcome {
        val tz = args.optString("timezone").trim()
        val zone = try { if (tz.isEmpty()) ZoneId.systemDefault() else ZoneId.of(tz) } catch (e: Exception) { return ActionOutcome.fail("\"$tz\" isn't a time zone I know.", "invalid_timezone") }
        val now = ZonedDateTime.now(zone)
        val t12 = now.format(DateTimeFormatter.ofPattern("h:mm a", en))
        val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", en))
        return ActionOutcome(
            ok = true, summary = "It is $t12 on $date (${zone.id}).",
            data = JSONObject().put("time_12h", t12).put("time_24h", now.format(DateTimeFormatter.ofPattern("HH:mm"))).put("date", date).put("time_zone", zone.id),
        )
    }

    // ───────── weather ─────────
    suspend fun weather(args: JSONObject): ActionOutcome {
        val loc = args.optString("location").trim()
        return when (val r = if (loc.isEmpty()) weather.forDevice() else weather.forPlace(loc)) {
            is WeatherResult.Ok -> {
                val w = r.weather
                val f = JSONArray()
                w.days.forEach { d -> f.put(JSONObject().put("date", d.date).put("conditions", d.summary).put("high_c", d.maxC).put("low_c", d.minC).apply { d.rainChance?.let { put("rain_chance_percent", it) } }) }
                ActionOutcome(
                    ok = true, summary = "${w.place}: ${w.summary}, ${w.tempC.toInt()}°C.",
                    data = JSONObject().put("place", w.place).put("conditions", w.summary).put("temperature_c", w.tempC)
                        .put("temperature_f", w.tempC * 9 / 5 + 32).put("feels_like_c", w.feelsC).put("humidity_percent", w.humidity)
                        .put("wind_kmh", w.windKmh).put("precipitation_mm_now", w.precipMm).put("is_daytime", w.isDay)
                        .put("forecast_days_starting_today", f).put("source", "Open-Meteo"),
                )
            }
            WeatherResult.NeedsPermission -> ActionOutcome.permission("location", "Local weather needs the Location permission. Enable it on the Permissions page, or name a city.")
            WeatherResult.NoLocation -> ActionOutcome.fail("I couldn't determine your location. Turn on Location or name a city.", "no_location")
            is WeatherResult.PlaceNotFound -> ActionOutcome.fail("I couldn't find a place called \"${r.name}\".", "place_not_found")
            WeatherResult.Offline -> ActionOutcome.fail("You're offline. Weather needs an internet connection.", "offline")
            WeatherResult.Failed -> ActionOutcome.fail("The weather service didn't answer correctly.", "service_error")
        }
    }

    // ───────── reminders ─────────
    fun setReminder(args: JSONObject): ActionOutcome {
        val msg = args.optString("message").trim().ifEmpty { "Reminder" }
        val repeat = args.optString("repeat", "none").lowercase().let { if (it == "daily" || it == "weekly") it else "none" }
        val now = System.currentTimeMillis()
        val mins = args.optInt("in_minutes", 0)
        val at: Long = when {
            mins > 0 -> now + mins * 60_000L
            args.optString("datetime").isNotBlank() -> parseLocal(args.optString("datetime")) ?: return ActionOutcome.fail("I couldn't understand that date and time.", "invalid_time")
            else -> return ActionOutcome.fail("I need a time for the reminder.", "missing_time")
        }
        if (at <= now + 5_000) return ActionOutcome.fail("That time has already passed.", "time_in_past")
        val r = store.add(msg, at, repeat)
        val res = scheduler.schedule(r)
        val whenText = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(at), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEEE d MMM, h:mm a", en))
        val warnings = ArrayList<String>()
        if (!res.notificationsEnabled) warnings.add("Notifications are off for JARVIS, so this reminder would be silent. Turn them on in the Permissions page.")
        if (!res.exact) warnings.add("Exact alarms are not allowed, so Android may deliver it a few minutes late. Allow \"Alarms & reminders\" on the Permissions page for exact timing.")
        return ActionOutcome(
            ok = true, summary = "Reminder \"$msg\" is set for $whenText.",
            data = JSONObject().put("when_local", whenText).put("repeat", repeat).put("exact_timing", res.exact).put("notifications_enabled", res.notificationsEnabled)
                .put("warnings", JSONArray(warnings)),
            needsUserAction = warnings.firstOrNull(),
        )
    }

    fun listReminders(): ActionOutcome {
        val list = store.items.value
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().put("message", r.message).put("repeat", r.repeat)
                .put("when_local", ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(r.triggerAt), ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("EEEE d MMM, h:mm a", en))))
        }
        return ActionOutcome(true, if (list.isEmpty()) "No upcoming reminders." else "${list.size} upcoming reminder(s).", JSONObject().put("reminders", arr))
    }

    fun cancelReminder(args: JSONObject): ActionOutcome {
        val q = args.optString("message_contains").trim()
        if (q.isEmpty()) return ActionOutcome.fail("Tell me which reminder to cancel.", "missing_argument")
        val hit = store.items.value.filter { it.message.contains(q, ignoreCase = true) }
        if (hit.isEmpty()) return ActionOutcome.fail("No reminder matches \"$q\".", "not_found")
        hit.forEach { scheduler.cancel(it.id) }
        return ActionOutcome(true, "Cancelled ${hit.size} reminder(s).", JSONObject().put("cancelled", JSONArray(hit.map { it.message })))
    }

    // ───────── alarm (system Clock app) ─────────
    fun setAlarm(args: JSONObject): ActionOutcome {
        val h = args.optInt("hour", -1); val m = args.optInt("minute", -1)
        if (h !in 0..23 || m !in 0..59) return ActionOutcome.fail("That isn't a valid alarm time.", "invalid_time")
        val label = args.optString("label").trim()
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        val days = args.optJSONArray("days")
        if (days != null && days.length() > 0) {
            val map = mapOf("mon" to Calendar.MONDAY, "tue" to Calendar.TUESDAY, "wed" to Calendar.WEDNESDAY, "thu" to Calendar.THURSDAY, "fri" to Calendar.FRIDAY, "sat" to Calendar.SATURDAY, "sun" to Calendar.SUNDAY)
            val list = ArrayList<Int>()
            for (k in 0 until days.length()) map[days.optString(k).lowercase().take(3)]?.let { list.add(it) }
            if (list.isNotEmpty()) i.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, list)
        }
        val shown = LocalDateTime.of(2000, 1, 1, h, m).format(DateTimeFormatter.ofPattern("h:mm a", en))
        return if (ctx.tryStart(i)) ActionOutcome(
            ok = true, summary = "Sent an alarm for $shown to the Clock app.",
            data = JSONObject().put("alarm_time", shown).put("confirmed_by_clock_app", false)
                .put("note", "Android does not let JARVIS read back the alarm list; the user can check the Clock app."),
        ) else ActionOutcome.fail("No Clock app could take the alarm.", "no_handler")
    }

    private fun parseLocal(s: String): Long? {
        val t = s.trim().replace(' ', 'T')
        val zone = ZoneId.systemDefault()
        return runCatching { LocalDateTime.parse(t).atZone(zone).toInstant().toEpochMilli() }.getOrNull()
            ?: runCatching { OffsetDateTime.parse(t).toInstant().toEpochMilli() }.getOrNull()
            ?: runCatching { LocalDateTime.parse(t + ":00").atZone(zone).toInstant().toEpochMilli() }.getOrNull()
    }
}
