package com.jarvis.ai.voice

import android.content.Context
import com.jarvis.ai.ai.GeminiClient
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.data.CredentialsRepository
import com.jarvis.ai.data.ModelRepository
import com.jarvis.ai.premium.PremiumRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class VoiceProviderId { ANDROID, GEMINI, ELEVENLABS }

class VoiceProviderException(val userMessage: String) : Exception(userMessage)

data class SpeakReport(val used: VoiceProviderId, val note: String?)

/**
 * Speaks text with the chosen provider and falls back automatically:
 * ElevenLabs/Gemini voice -> device voice. Never crashes because a key or service is missing.
 * Non-device voices are Premium (Voice Pack); free users always get the device voice.
 */
class TtsManager(
    ctx: Context,
    private val prefs: AppPrefs,
    private val creds: CredentialsRepository,
    private val gemini: GeminiClient,
    private val models: ModelRepository,
    private val premium: PremiumRepository,
) {
    private val android = AndroidTts(ctx)
    private val eleven = ElevenLabsTts(ctx)
    @Volatile private var player: PcmPlayer? = null

    fun effectiveProvider(): VoiceProviderId {
        val pref = runCatching { VoiceProviderId.valueOf(prefs.voiceProvider) }.getOrDefault(VoiceProviderId.ANDROID)
        return if (pref != VoiceProviderId.ANDROID && !premium.isPremium.value) VoiceProviderId.ANDROID else pref
    }

    /** [providerOverride]/[voiceOverride] are for previews in the Voice Pack; normal speech uses the saved settings. */
    suspend fun speak(text: String, providerOverride: VoiceProviderId? = null, voiceOverride: String? = null, onLevel: (Float) -> Unit): SpeakReport {
        val clean = SpeechText.clean(text)
        if (clean.isBlank()) return SpeakReport(VoiceProviderId.ANDROID, null)
        var note: String? = null
        val requested = providerOverride?.takeIf { it == VoiceProviderId.ANDROID || premium.isPremium.value } ?: effectiveProvider()
        val chain = when (requested) {
            VoiceProviderId.ELEVENLABS ->
                if (!creds.hasElevenLabsKey) { note = "Add your ElevenLabs API key to use this voice. Using the device voice instead."; listOf(VoiceProviderId.ANDROID) }
                else listOf(VoiceProviderId.ELEVENLABS, VoiceProviderId.ANDROID)
            VoiceProviderId.GEMINI ->
                if (!creds.hasGeminiKey) { note = "Add your Gemini API key to use this voice. Using the device voice instead."; listOf(VoiceProviderId.ANDROID) }
                else listOf(VoiceProviderId.GEMINI, VoiceProviderId.ANDROID)
            VoiceProviderId.ANDROID -> listOf(VoiceProviderId.ANDROID)
        }
        for (p in chain) {
            try {
                when (p) {
                    VoiceProviderId.ELEVENLABS -> speakEleven(clean, onLevel, voiceOverride)
                    VoiceProviderId.GEMINI -> speakGemini(clean, onLevel, voiceOverride)
                    VoiceProviderId.ANDROID -> android.speak(clean, prefs.voiceSpeed, prefs.voicePitch, prefs.voiceVolume, onLevel)
                }
                return SpeakReport(p, note)
            } catch (e: CancellationException) {
                throw e
            } catch (e: VoiceProviderException) {
                if (p == VoiceProviderId.ANDROID) throw e
                note = e.userMessage + " Using the device voice instead."
            }
        }
        return SpeakReport(VoiceProviderId.ANDROID, note)
    }

    fun stop() {
        player?.release()
        android.stop()
    }

    private suspend fun speakEleven(text: String, onLevel: (Float) -> Unit, voice: String?) = withContext(Dispatchers.IO) {
        val p = PcmPlayer(24000, prefs.voiceVolume, onLevel)
        player = p
        try {
            p.start()
            for (chunk in SpeechText.chunks(text, 800)) {
                try {
                    eleven.streamInto(p, chunk, creds.elevenLabsKey.value, voice ?: prefs.elevenVoiceId, prefs.voiceSpeed)
                } catch (e: VoiceProviderException) {
                    if (!p.hasPlayed) throw e else break // already speaking: don't repeat the text in another voice
                }
            }
            p.drain()
        } finally {
            p.release(); player = null
        }
    }

    private suspend fun speakGemini(text: String, onLevel: (Float) -> Unit, voice: String?) = withContext(Dispatchers.IO) {
        var p: PcmPlayer? = null
        try {
            for (chunk in SpeechText.chunks(text, 600)) {
                val (pcm, rate) = try {
                    gemini.synthesize(chunk, voice ?: prefs.geminiVoiceName, models.ttsModelId)
                } catch (e: VoiceProviderException) {
                    if (p?.hasPlayed != true) throw e else break
                }
                val out = p ?: PcmPlayer(rate, prefs.voiceVolume, onLevel).also { it.start(); player = it; p = it }
                out.write(pcm)
            }
            p?.drain()
        } finally {
            p?.release(); player = null
        }
    }
}
