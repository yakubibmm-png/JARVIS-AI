package com.jarvis.ai.command

import org.json.JSONArray
import org.json.JSONObject

/**
 * What an action REALLY did. Serialised and sent back to Gemini, so replies are based on facts:
 * [ok] is true only when Android accepted/performed the step; [needsUserAction] says what the user must still do.
 */
class ActionOutcome(
    val ok: Boolean,
    val summary: String,
    val data: JSONObject = JSONObject(),
    val reason: String? = null,
    val needsPermission: String? = null,
    val candidates: List<String>? = null,
    val needsUserAction: String? = null,
    val launchedExternal: Boolean = false,
) {
    fun toResponse(): JSONObject = JSONObject().apply {
        put("ok", ok)
        put("summary", summary)
        reason?.let { put("reason", it) }
        needsPermission?.let { put("needs_permission", it) }
        candidates?.let { put("candidates", JSONArray(it)) }
        needsUserAction?.let { put("needs_user_action", it) }
        val keys = data.keys()
        while (keys.hasNext()) { val k = keys.next(); put(k, data.get(k)) }
    }

    companion object {
        fun fail(summary: String, reason: String? = null, data: JSONObject = JSONObject()) = ActionOutcome(false, summary, data, reason)
        fun permission(what: String, summary: String) = ActionOutcome(false, summary, reason = "permission_missing", needsPermission = what)
    }
}

/** A record of one executed action, shown under the assistant message in Chat. */
data class ActionRecord(val tool: String, val ok: Boolean, val summary: String)

fun interface ActionHandler {
    suspend fun handle(args: JSONObject): ActionOutcome
}

/** Per-request context passed through the planner/executor. */
class RunContext(val viaVoice: Boolean, val onStatus: (String) -> Unit = {})
