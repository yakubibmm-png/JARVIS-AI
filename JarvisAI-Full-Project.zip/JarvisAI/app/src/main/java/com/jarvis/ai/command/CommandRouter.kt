package com.jarvis.ai.command

data class ActionContext(val viaVoice: Boolean, val recentUserTexts: List<String> = emptyList())

/**
 * Phase 3 hook. Every utterance (typed or spoken) is offered to the router BEFORE it goes to Gemini.
 * Return an ActionResult when the router handled it (open app, reminder, ...); return null to continue to the AI.
 */
interface CommandRouter {
    suspend fun tryHandle(utterance: String, context: ActionContext): ActionResult?
}

object PassThroughRouter : CommandRouter {
    override suspend fun tryHandle(utterance: String, context: ActionContext): ActionResult? = null
}
