package com.jarvis.ai.premium

import android.os.SystemClock
import com.jarvis.ai.data.SecureStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** The single, centralized Premium entitlement. No other flag may exist. */
class PremiumRepository(
    private val store: SecureStore,
    private val validator: LicenseValidator,
) {
    private val _isPremium = MutableStateFlow(store.getBoolean(K_ACTIVE))
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    private var failures = 0
    private var lockedUntil = 0L

    suspend fun unlock(key: String): LicenseResult {
        val now = SystemClock.elapsedRealtime()
        if (now < lockedUntil) return LicenseResult.TooManyAttempts(((lockedUntil - now) / 1000).toInt() + 1)
        if (key.isBlank()) return LicenseResult.Invalid("Enter your premium key.")

        val result = validator.validate(key)
        when (result) {
            LicenseResult.Valid -> {
                failures = 0
                store.putBoolean(K_ACTIVE, true)
                store.putLong(K_AT, System.currentTimeMillis())
                _isPremium.value = true
            }
            is LicenseResult.Invalid -> {
                failures++
                if (failures >= MAX_FAILURES) {
                    failures = 0
                    lockedUntil = SystemClock.elapsedRealtime() + LOCK_MS
                }
            }
            is LicenseResult.TooManyAttempts -> Unit
        }
        return result
    }

    /** For future license-revocation / sign-out flows. */
    fun revoke() {
        store.putBoolean(K_ACTIVE, false)
        store.remove(K_AT)
        _isPremium.value = false
    }

    private companion object {
        const val K_ACTIVE = "premium_active"
        const val K_AT = "premium_activated_at"
        const val MAX_FAILURES = 5
        const val LOCK_MS = 30_000L
    }
}
