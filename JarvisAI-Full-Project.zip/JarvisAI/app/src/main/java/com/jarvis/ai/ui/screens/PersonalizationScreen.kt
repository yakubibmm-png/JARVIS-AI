package com.jarvis.ai.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.ChipGrid
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.LabeledField
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.SectionTitle
import com.jarvis.ai.ui.theme.Accent
import com.jarvis.ai.ui.theme.Appearance
import com.jarvis.ai.ui.theme.JarvisColors

@Composable
fun PersonalizationScreen(onBack: () -> Unit) {
    val prefs = LocalContainer.current.prefs
    var aiName by remember { mutableStateOf(prefs.assistantName) }
    var userName by remember { mutableStateOf(prefs.userCallName) }
    var style by remember { mutableStateOf(prefs.aiStyle) }
    var mode by remember { mutableStateOf(prefs.personalityMode) }
    var saved by remember { mutableStateOf("") }

    ScreenScaffold("Personalization", "Make JARVIS truly yours", onBack) {
        GlassCard {
            Row(verticalAlignment = Alignment.Bottom) {
                LabeledField(aiName, { aiName = it; saved = "" }, "AI Name", "Default: JARVIS", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                NeonButton("SAVE", { prefs.assistantName = aiName.trim().ifBlank { "JARVIS" }; aiName = prefs.assistantName; saved = "AI name saved" })
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                LabeledField(userName, { userName = it; saved = "" }, "Your Name (what JARVIS calls you)", "e.g. Boss", Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                NeonButton("SAVE", { prefs.userCallName = userName.trim(); saved = "Your name saved" })
            }
            if (saved.isNotEmpty()) Text(saved, color = JarvisColors.Success, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        GlassCard {
            SectionTitle("AI Avatar / Character", "Shown on Home, in Chat and in Settings")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                repeat(Appearance.avatarCount) { i ->
                    val sel = Appearance.avatar == i
                    Image(
                        painterResource(Appearance.avatarRes(i)), Appearance.avatarNames[i],
                        Modifier.size(66.dp).clip(CircleShape).border(if (sel) 3.dp else 1.dp, if (sel) JarvisColors.Cyan else JarvisColors.Blue.copy(alpha = 0.5f), CircleShape)
                            .clickable { Appearance.selectAvatar(i); prefs.avatarIndex = i },
                    )
                }
            }
        }
        GlassCard {
            SectionTitle("AI Style")
            Spacer(Modifier.height(8.dp))
            ChipGrid(listOf("FRIENDLY" to "Friendly", "PROFESSIONAL" to "Professional", "CASUAL" to "Casual", "CUTE" to "Cute"), style, columns = 2) { style = it; prefs.aiStyle = it }
            Spacer(Modifier.height(12.dp))
            SectionTitle("Personality Mode")
            Spacer(Modifier.height(8.dp))
            ChipGrid(listOf("CARE" to "Care", "BOSS" to "Boss", "FRIEND" to "Friend"), mode) { mode = it; prefs.personalityMode = it }
        }
        GlassCard {
            SectionTitle("Appearance", "Accent color")
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Accent.options.forEachIndexed { i, o ->
                    val sel = Accent.index == i
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color.Transparent, CircleShape)
                            .clickable { Accent.select(i); prefs.accentIndex = i }.padding(5.dp),
                    ) { Box(Modifier.size(28.dp).clip(CircleShape).border(14.dp, o.primary, CircleShape)) }
                }
            }
            Text("Some icons update after you reopen the app.", color = JarvisColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
        NeonButton("Reset to Default", {
            prefs.assistantName = "JARVIS"; prefs.userCallName = "Boss"; prefs.aiStyle = "FRIENDLY"; prefs.personalityMode = "FRIEND"
            prefs.avatarIndex = 0; prefs.accentIndex = 0; Appearance.selectAvatar(0); Accent.select(0)
            aiName = "JARVIS"; userName = "Boss"; style = "FRIENDLY"; mode = "FRIEND"; saved = "Defaults restored"
        }, Modifier.fillMaxWidth(), filled = false)
    }
}
