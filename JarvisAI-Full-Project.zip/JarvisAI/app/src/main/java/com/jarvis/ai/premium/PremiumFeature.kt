package com.jarvis.ai.premium

/** Every Premium-gated capability. Drives lock badges and the "Premium explanation" screen. */
enum class PremiumFeature(val title: String, val why: String, val benefits: List<String>) {
    VOICE_PACK(
        "Voice Pack",
        "Premium voices use paid voice providers and custom voice workflows.",
        listOf("Gemini and ElevenLabs voice choices", "Voice Changer and My Voice", "Girls, Boys, Deep, Soft and Professional voice styles"),
    ),
    SUPER_AI(
        "Super AI",
        "Advanced models and providers cost more to run, so they are part of Pro.",
        listOf("Advanced AI models", "Flexible provider architecture", "Only integrated providers are shown as available"),
    ),
    PREFERENCES(
        "Preferences",
        "Fine-tuning how JARVIS thinks and speaks is a Pro customization.",
        listOf("Voice Brain: Balanced, Compact, Full", "Care, Boss and Friend modes", "Language Mirror for 19+ languages"),
    ),
    PERSONALIZATION(
        "Personalization",
        "Personal identity and style options are part of Pro.",
        listOf("Custom AI name and your name", "Character style and accent options", "Assistant style and personality"),
    ),
    AUTOMATION(
        "Automation",
        "Automation can act on your phone, so it is a Pro feature with its own controls.",
        listOf("Auto Reply, App Launch, Task Scheduler", "Smart Triggers and Custom Actions", "One clear ON/OFF switch you control"),
    ),
    MORE_FEATURES(
        "More Features",
        "Additional tools and services are released to Pro members.",
        listOf("Extra tools and services", "Early access to new features"),
    ),
    SCREEN_SHARE(
        "Screen Share",
        "Screen understanding needs advanced AI processing and is a Pro feature.",
        listOf("Ask what is on your screen", "Works only while you share, with Android's consent prompt"),
    ),
    AUTO_REPLY(
        "WhatsApp Auto Reply",
        "Context-aware replies use AI and notification access, which are Pro features.",
        listOf("Context-aware replies in your style", "Emergency OFF switch", "Saved contact aliases"),
    ),
    ADVANCED_AI_MODELS(
        "Advanced AI Models",
        "Thinking and reasoning models are part of Pro.",
        listOf("Deeper reasoning for hard questions", "Better coding help"),
    ),
    ACCESSIBILITY_CONTROL(
        "Phone Control",
        "Screen-aware phone control is an advanced Pro capability.",
        listOf("Tap, scroll, type and go back by voice", "Semantic targeting instead of fragile coordinates"),
    ),
    NOTIFICATION_ACCESS(
        "Message Awareness",
        "Reading supported notifications powers Auto Reply and message reading, which are Pro features.",
        listOf("Read supported message notifications", "Powers Auto Reply"),
    ),
}
