package com.jarvis.ai.command

import com.jarvis.ai.command.handlers.ContactHandlers
import com.jarvis.ai.command.handlers.DeviceHandlers
import com.jarvis.ai.command.handlers.InfoHandlers
import com.jarvis.ai.command.handlers.ScreenController

/** tool name -> handler. Phase 4 swaps in a real ScreenController and adds messaging-send handlers here. */
object HandlerRegistry {
    fun build(
        device: DeviceHandlers, contact: ContactHandlers, info: InfoHandlers,
        screen: () -> ScreenController, custom: (String) -> ActionOutcome,
    ): Map<String, ActionHandler> = mapOf(
        "open_app" to ActionHandler { device.openApp(it) },
        "install_app" to ActionHandler { device.installApp(it) },
        "search" to ActionHandler { device.search(it) },
        "open_url" to ActionHandler { device.openUrl(it) },
        "open_settings" to ActionHandler { device.openSettings(it) },
        "play_media" to ActionHandler { device.playMedia(it) },
        "media_control" to ActionHandler { device.mediaControl(it) },
        "set_flashlight" to ActionHandler { device.flashlight(it) },
        "find_contact" to ActionHandler { contact.find(it) },
        "call_contact" to ActionHandler { contact.call(it) },
        "draft_message" to ActionHandler { contact.draft(it) },
        "get_time" to ActionHandler { info.time(it) },
        "get_weather" to ActionHandler { info.weather(it) },
        "set_reminder" to ActionHandler { info.setReminder(it) },
        "list_reminders" to ActionHandler { info.listReminders() },
        "cancel_reminder" to ActionHandler { info.cancelReminder(it) },
        "set_alarm" to ActionHandler { info.setAlarm(it) },
        "screen_action" to ActionHandler { screen().perform(it.optString("action"), it.optString("target"), it.optString("text"), it.optInt("ordinal", 0)) },
        "screen_question" to ActionHandler { screen().ask(it.optString("question")) },
        "confirm_action" to ActionHandler { screen().confirm(it.optBoolean("approve", false)) },
        "run_custom_action" to ActionHandler { custom(it.optString("name")) },
    )
}
