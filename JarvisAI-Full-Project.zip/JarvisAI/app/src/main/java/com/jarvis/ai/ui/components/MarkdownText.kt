package com.jarvis.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.clickable
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.ui.theme.JarvisColors

private sealed interface Block {
    data class Prose(val lines: List<String>) : Block
    data class Code(val lang: String, val code: String) : Block
}

private fun parse(text: String): List<Block> {
    val out = ArrayList<Block>()
    val parts = text.split("```")
    parts.forEachIndexed { i, part ->
        if (i % 2 == 0) {
            if (part.isNotBlank()) out.add(Block.Prose(part.trim('\n').lines()))
        } else {
            val nl = part.indexOf('\n')
            val lang = if (nl >= 0) part.substring(0, nl).trim() else ""
            val code = (if (nl >= 0) part.substring(nl + 1) else part).trimEnd('\n')
            out.add(Block.Code(lang, code))
        }
    }
    return out
}

private fun inline(s: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        when {
            s.startsWith("**", i) -> {
                val e = s.indexOf("**", i + 2)
                if (e > 0) { withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.substring(i + 2, e)) }; i = e + 2 } else { append("**"); i += 2 }
            }
            s[i] == '`' -> {
                val e = s.indexOf('`', i + 1)
                if (e > 0) {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33000000), color = JarvisColors.Cyan)) { append(s.substring(i + 1, e)) }
                    i = e + 1
                } else { append('`'); i++ }
            }
            s[i] == '*' && i + 1 < s.length && s[i + 1] != ' ' && s[i + 1] != '*' -> {
                val e = s.indexOf('*', i + 1)
                if (e > 0) { withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(s.substring(i + 1, e)) }; i = e + 1 } else { append('*'); i++ }
            }
            else -> { append(s[i]); i++ }
        }
    }
}

private val bullet = Regex("^(\\s*)[-*]\\s+(.*)$")
private val heading = Regex("^#{1,6}\\s+(.*)$")

/** Lightweight Markdown: headings, bullets, **bold**, *italic*, `code` and fenced code blocks (with Copy). */
@Composable
fun MarkdownText(text: String, color: Color = Color.White, onCopyCode: (String) -> Unit = {}) {
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            parse(text).forEach { block ->
                when (block) {
                    is Block.Prose -> block.lines.forEach { raw ->
                        val h = heading.matchEntire(raw)
                        val b = bullet.matchEntire(raw)
                        when {
                            raw.isBlank() -> androidx.compose.foundation.layout.Spacer(Modifier.height(2.dp))
                            h != null -> Text(inline(h.groupValues[1]), color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            b != null -> Row {
                                Text("•  ", color = JarvisColors.Cyan, fontSize = 14.sp, modifier = Modifier.padding(start = (b.groupValues[1].length * 4).dp))
                                Text(inline(b.groupValues[2]), color = color, fontSize = 14.sp)
                            }
                            else -> Text(inline(raw), color = color, fontSize = 14.sp)
                        }
                    }
                    is Block.Code -> Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF020A1C)).padding(8.dp),
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(block.lang.ifBlank { "code" }, color = JarvisColors.TextDim, fontSize = 11.sp)
                            Text("Copy", color = JarvisColors.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { onCopyCode(block.code) })
                        }
                        Text(block.code, color = Color(0xFFE2E8F0), fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp))
                    }
                }
            }
        }
    }
}
