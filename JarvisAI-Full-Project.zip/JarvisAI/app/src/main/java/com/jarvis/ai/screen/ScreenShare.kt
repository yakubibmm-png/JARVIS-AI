package com.jarvis.ai.screen

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.jarvis.ai.R
import com.jarvis.ai.reminders.Notifier
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

/**
 * Screen Share: Android's own consent dialog starts a MediaProjection; a visible foreground notification stays up
 * while it is active. A frame is read ONLY when you ask a screen question, and is never stored or sent otherwise.
 */
class ScreenShareService : Service() {
    companion object {
        const val ACTION_START = "com.jarvis.ai.SCREEN_SHARE_START"
        const val ACTION_STOP = "com.jarvis.ai.SCREEN_SHARE_STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val NOTIF_ID = 7101
        @Volatile var instance: ScreenShareService? = null
        private val _active = MutableStateFlow(false)
        val active: StateFlow<Boolean> = _active.asStateFlow()
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var held: Image? = null
    private var width = 0
    private var height = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION") val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) { shutdown(); return START_NOT_STICKY }

        Notifier.ensureChannels(this)
        val stop = PendingIntent.getService(this, 1, Intent(this, ScreenShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n: Notification = NotificationCompat.Builder(this, Notifier.CH_STATUS)
            .setSmallIcon(R.drawable.ic_notification).setContentTitle("JARVIS is sharing your screen")
            .setContentText("It looks at the screen only when you ask a screen question.").setOngoing(true)
            .addAction(0, "Stop sharing", stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(NOTIF_ID, n)

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { shutdown() } }, handler)
            val dm = resources.displayMetrics
            val scale = min(1f, 1280f / max(dm.widthPixels, dm.heightPixels))
            width = (dm.widthPixels * scale).toInt().coerceAtLeast(2); height = (dm.heightPixels * scale).toInt().coerceAtLeast(2)
            val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
            r.setOnImageAvailableListener({ rd ->
                val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
                synchronized(this) { held?.close(); held = img }
            }, handler)
            display = p.createVirtualDisplay("jarvis-screen", width, height, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
            projection = p; reader = r; instance = this; _active.value = true
        } catch (e: Exception) {
            shutdown()
        }
        return START_NOT_STICKY
    }

    /** Latest frame as JPEG, or null if nothing arrived yet. */
    suspend fun captureJpeg(): ByteArray? {
        var tries = 0
        while (tries < 10 && synchronized(this) { held } == null) { delay(150); tries++ }
        val img = synchronized(this) { held } ?: return null
        return try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * width
            val bmp = Bitmap.createBitmap(width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer.also { it.rewind() })
            val cropped = Bitmap.createBitmap(bmp, 0, 0, width, height)
            ByteArrayOutputStream().also { cropped.compress(Bitmap.CompressFormat.JPEG, 70, it) }.toByteArray()
        } catch (e: Exception) { null }
    }

    private fun shutdown() {
        synchronized(this) { held?.close(); held = null }
        runCatching { display?.release() }; display = null
        runCatching { reader?.close() }; reader = null
        runCatching { projection?.stop() }; projection = null
        instance = null; _active.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { shutdown(); super.onDestroy() }
}

class ScreenShareManager(private val ctx: Context) {
    val active: StateFlow<Boolean> = ScreenShareService.active

    /** [data] is the result of MediaProjectionManager.createScreenCaptureIntent() (Android's consent dialog). */
    fun start(resultCode: Int, data: Intent) {
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, ScreenShareService::class.java).setAction(ScreenShareService.ACTION_START)
                .putExtra(ScreenShareService.EXTRA_CODE, resultCode).putExtra(ScreenShareService.EXTRA_DATA, data),
        )
    }

    fun stop() { ctx.startService(Intent(ctx, ScreenShareService::class.java).setAction(ScreenShareService.ACTION_STOP)) }

    fun consentIntent(): Intent = ctx.getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent()

    suspend fun captureJpeg(): ByteArray? = ScreenShareService.instance?.captureJpeg()
}
