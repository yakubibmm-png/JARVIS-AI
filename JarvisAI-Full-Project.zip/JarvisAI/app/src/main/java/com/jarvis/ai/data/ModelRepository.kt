package com.jarvis.ai.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

enum class ModelCategory(val label: String) {
    FAST_LIVE("Fast / Live"),
    BALANCED("Balanced"),
    THINKING("Thinking"),
}

data class AiModel(
    val id: String,
    val label: String,
    val category: ModelCategory,
    val description: String,
    val premium: Boolean,
)

/** Model list comes from assets/gemini_models.json so IDs can change without code changes. */
class ModelRepository(context: Context, private val prefs: AppPrefs) {
    val catalog: List<AiModel>
    val defaultModelId: String
    val ttsModelId: String

    private val _selectedId: MutableStateFlow<String>
    val selectedId: StateFlow<String> get() = _selectedId.asStateFlow()

    init {
        var models = emptyList<AiModel>()
        var def = ""
        var tts = "gemini-2.5-flash-preview-tts"
        try {
            val text = context.assets.open("gemini_models.json").bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            val arr = root.getJSONArray("models")
            models = (0 until arr.length()).mapNotNull { i ->
                val o = arr.getJSONObject(i)
                val cat = runCatching { ModelCategory.valueOf(o.getString("category")) }.getOrNull() ?: return@mapNotNull null
                AiModel(o.getString("id"), o.getString("label"), cat, o.optString("description"), o.optBoolean("premium"))
            }
            def = root.optString("default", models.firstOrNull()?.id.orEmpty())
            tts = root.optString("ttsModel", tts)
        } catch (e: Exception) {
            // keep empty catalog; the custom model field still works
        }
        catalog = models
        defaultModelId = def
        ttsModelId = tts
        _selectedId = MutableStateFlow(prefs.selectedModelId.ifBlank { def })
    }

    fun select(id: String) {
        prefs.selectedModelId = id
        _selectedId.value = id
    }

    /** Accepts a user-supplied model ID. Returns an error message or null on success. */
    fun selectCustom(raw: String): String? {
        val id = raw.trim()
        if (!CUSTOM_ID.matches(id)) return "Use letters, numbers, dots and dashes only (3–80 characters)."
        prefs.customModelId = id
        select(id)
        return null
    }

    /** The model to really use: premium models fall back to a free one for free users. */
    fun effective(isPremium: Boolean): String {
        val id = selectedId.value.ifBlank { defaultModelId }
        val m = find(id)
        return if (m != null && m.premium && !isPremium) catalog.firstOrNull { !it.premium }?.id ?: defaultModelId else id
    }

    fun find(id: String): AiModel? = catalog.firstOrNull { it.id == id }
    fun labelFor(id: String): String = find(id)?.label ?: "Custom model"
    fun categoryOf(id: String): ModelCategory = find(id)?.category ?: ModelCategory.BALANCED

    private companion object {
        val CUSTOM_ID = Regex("^[A-Za-z0-9._\\-]{3,80}$")
    }
}
