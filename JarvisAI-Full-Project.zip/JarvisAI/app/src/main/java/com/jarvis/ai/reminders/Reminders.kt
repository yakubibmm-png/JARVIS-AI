package com.jarvis.ai.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.MainActivity
import com.jarvis.ai.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class Reminder(val id: Int, val message: String, val triggerAt: Long, val repeat: String)

class ReminderStore(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("jarvis_reminders", Context.MODE_PRIVATE)
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<Reminder>> = _items.asStateFlow()

    @Synchronized fun add(message: String, triggerAt: Long, repeat: String): Reminder {
        val id = sp.getInt("next_id", 1)
        sp.edit().putInt("next_id", id + 1).apply()
        val r = Reminder(id, message, triggerAt, repeat)
        save(_items.value + r)
        return r
    }
    @Synchronized fun remove(id: Int) = save(_items.value.filterNot { it.id == id })
    @Synchronized fun update(r: Reminder) = save(_items.value.map { if (it.id == r.id) r else it })
    fun get(id: Int): Reminder? = _items.value.firstOrNull { it.id == id }

    private fun save(list: List<Reminder>) {
        val sorted = list.sortedBy { it.triggerAt }
        val arr = JSONArray()
        sorted.forEach { arr.put(JSONObject().put("i", it.id).put("m", it.message).put("t", it.triggerAt).put("r", it.repeat)) }
        sp.edit().putString("items", arr.toString()).apply()
        _items.value = sorted
    }

    private fun load(): List<Reminder> = runCatching {
        val arr = JSONArray(sp.getString("items", "[]"))
        (0 until arr.length()).map { val o = arr.getJSONObject(it); Reminder(o.getInt("i"), o.getString("m"), o.getLong("t"), o.optString("r", "none")) }
    }.getOrDefault(emptyList())
}

data class ScheduleResult(val exact: Boolean, val notificationsEnabled: Boolean)

class ReminderScheduler(private val ctx: Context, private val store: ReminderStore) {
    private val alarms = ctx.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(): Boolean = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms()

    fun schedule(r: Reminder): ScheduleResult {
        val pi = pending(r.id)
        val exact = canScheduleExact()
        if (exact) alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAt, pi)
        else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAt, pi)
        return ScheduleResult(exact, NotificationManagerCompat.from(ctx).areNotificationsEnabled())
    }

    fun cancel(id: Int) { alarms.cancel(pending(id)); store.remove(id) }

    fun rescheduleAll() {
        val now = System.currentTimeMillis()
        store.items.value.forEach { r ->
            if (r.triggerAt <= now) Notifier.reminder(ctx, r.id, r.message + " (missed)").also { advanceOrRemove(r) }
            else schedule(r)
        }
    }

    /** After a reminder fires: repeat it or delete it. */
    fun advanceOrRemove(r: Reminder) {
        val step = when (r.repeat) { "daily" -> 24L * 3600_000; "weekly" -> 7L * 24 * 3600_000; else -> 0L }
        if (step == 0L) { store.remove(r.id); return }
        var next = r.triggerAt
        while (next <= System.currentTimeMillis()) next += step
        val updated = r.copy(triggerAt = next)
        store.update(updated); schedule(updated)
    }

    private fun pending(id: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, id,
        Intent(ctx, ReminderReceiver::class.java).setAction(ACTION).setData(Uri.parse("jarvis://reminder/$id")).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    companion object { const val ACTION = "com.jarvis.ai.REMINDER" }
}

object Notifier {
    const val CH_REMINDERS = "reminders"
    const val CH_EVENTS = "assistant_events"
    const val CH_STATUS = "assistant_status"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_REMINDERS, "Reminders", NotificationManager.IMPORTANCE_HIGH).apply { description = "Reminders you ask JARVIS to set" })
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Assistant status", NotificationManager.IMPORTANCE_LOW).apply { description = "Shown while JARVIS runs in the background or shares your screen" })
        nm.createNotificationChannel(NotificationChannel(CH_EVENTS, "Assistant events", NotificationManager.IMPORTANCE_DEFAULT).apply { description = "App installs and other assistant updates" })
    }

    fun reminder(ctx: Context, id: Int, message: String) = post(ctx, CH_REMINDERS, 10_000 + id, "JARVIS reminder", message)
    fun info(ctx: Context, title: String, text: String) = post(ctx, CH_EVENTS, (System.currentTimeMillis() % 100_000).toInt() + 200_000, title, text)

    fun withIntent(ctx: Context, title: String, text: String, pi: PendingIntent) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(ctx, CH_EVENTS).setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(text)
            .setAutoCancel(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { nm.notify((System.currentTimeMillis() % 100_000).toInt() + 300_000, n) } catch (e: SecurityException) { }
    }

    private fun post(ctx: Context, channel: String, nid: Int, title: String, text: String) {
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return
        val open = PendingIntent.getActivity(ctx, nid, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_HIGH).build()
        try { nm.notify(nid, n) } catch (e: SecurityException) { /* notification permission revoked meanwhile */ }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val c = (context.applicationContext as JarvisApp).container
        val id = intent.getIntExtra("id", -1)
        val r = c.reminderStore.get(id) ?: return
        Notifier.reminder(context, r.id, r.message)
        if (c.prefs.spokenReminders) c.backgroundVoice.speak("Reminder: ${r.message}", force = true)
        c.reminderScheduler.advanceOrRemove(r)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val c = (context.applicationContext as JarvisApp).container
            c.reminderScheduler.rescheduleAll()
            c.taskScheduler.rescheduleAll()
            if (c.prefs.backgroundAssistant && c.premium.isPremium.value) runCatching { com.jarvis.ai.automation.AssistantService.start(context) }
        }
    }
}
