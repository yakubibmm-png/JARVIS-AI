package com.jarvis.ai.ui.screens

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.ai.AttachResult
import com.jarvis.ai.ai.AttachmentLoader
import com.jarvis.ai.ai.PendingAttachment
import com.jarvis.ai.chat.ChatMessage
import com.jarvis.ai.chat.ChatRole
import com.jarvis.ai.chat.Conversation
import com.jarvis.ai.di.AppContainer
import com.jarvis.ai.voice.SpeechCallback
import com.jarvis.ai.voice.SpeechError
import com.jarvis.ai.voice.SpeechInput
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class ChatViewModel(private val c: AppContainer, private val appCtx: Context) : ViewModel() {
    private val repo = c.chatRepository
    private val engine = c.conversation

    val active: StateFlow<Conversation?> = repo.active
    val recents: StateFlow<List<Conversation>> = repo.conversations
        .map { list -> list.filter { it.messages.isNotEmpty() }.sortedByDescending { it.updatedAt } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val generating: StateFlow<Boolean> = engine.generating

    var input by mutableStateOf("")
    var attachment by mutableStateOf<PendingAttachment?>(null); private set
    var notice by mutableStateOf<String?>(null)

    var dictating by mutableStateOf(false); private set
    var dictLevel by mutableStateOf(0f); private set
    private var dictBase = ""
    private val dictation = SpeechInput(appCtx)

    fun send() {
        val t = input.trim()
        if (engine.generating.value || (t.isEmpty() && attachment == null)) return
        cancelDictation()
        c.voiceController.interruptAll()
        engine.submit(t.ifEmpty { "Please look at the attached file." }, attachment)
        input = ""; attachment = null
    }

    fun stopGenerating() = engine.cancel()

    fun newChat() { cancelDictation(); repo.newChat() }
    fun clearChat() { repo.currentId().let(repo::clear) }
    fun select(id: String) { repo.select(id) }
    fun deleteCurrent() { repo.delete(repo.currentId()) }
    fun setHistoryEnabled(enabled: Boolean) = repo.setHistoryEnabled(enabled)
    val historyEnabled: Boolean get() = c.prefs.chatHistoryEnabled

    fun retry(errorMessageId: String) {
        val conv = active.value ?: return
        val idx = conv.messages.indexOfFirst { it.id == errorMessageId }
        if (idx < 1) return
        val user = conv.messages[idx - 1]
        if (user.role != ChatRole.USER) return
        repo.deleteMessages(conv.id, setOf(user.id, errorMessageId))
        engine.submit(user.text, null)
    }

    fun transcript(): String = active.value?.messages.orEmpty().joinToString("\n\n") {
        (if (it.role == ChatRole.USER) "You" else "JARVIS") + ": " + it.text
    }

    // ── attachments ──
    fun attach(uri: Uri) {
        viewModelScope.launch {
            when (val r = withContext(Dispatchers.IO) { AttachmentLoader.load(appCtx, uri) }) {
                is AttachResult.Ok -> attachment = r.attachment
                is AttachResult.Error -> notice = r.message
            }
        }
    }
    fun removeAttachment() { attachment = null }

    // ── dictation (microphone in the message box) ──
    fun toggleDictation() { if (dictating) dictation.finish() else startDictation() }

    private fun startDictation() {
        c.voiceController.interruptAll()
        dictBase = input.trimEnd()
        dictating = true
        val tag = c.prefs.speechLocaleTag
        dictation.start(if (tag.isBlank()) Locale.getDefault() else Locale.forLanguageTag(tag), object : SpeechCallback {
            override fun onLevel(level: Float) { dictLevel = level }
            override fun onPartial(text: String) { input = join(dictBase, text) }
            override fun onFinal(text: String) { input = join(dictBase, text); dictating = false; dictLevel = 0f }
            override fun onError(error: SpeechError) {
                dictating = false; dictLevel = 0f
                when (error) {
                    SpeechError.NO_SPEECH -> Unit
                    SpeechError.PERMISSION -> notice = "Microphone permission is required for voice input."
                    SpeechError.NETWORK -> notice = "Speech recognition needs an internet connection on this device."
                    else -> notice = "I couldn't hear you. Please try again."
                }
            }
        })
    }

    private fun cancelDictation() { if (dictating) { dictation.cancel(); dictating = false; dictLevel = 0f } }

    private fun join(a: String, b: String) = if (a.isEmpty()) b else "$a $b"

    override fun onCleared() { dictation.cancel() }
}
