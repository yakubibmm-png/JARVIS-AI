package com.jarvis.ai.ai

import android.graphics.Bitmap
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.toList
import org.json.JSONArray
import org.json.JSONObject

/** A file or image the user attached to ONE message. Bytes are sent once and are not stored in chat history. */
class PendingAttachment(
    val name: String,
    val mime: String,
    val bytes: ByteArray? = null,   // images / PDF (sent inline)
    val text: String? = null,       // text-like files (sent as text)
    val thumbnail: Bitmap? = null,
)

/** A tool call requested by the model. [raw] is the original response part, replayed verbatim on the next round. */
class FnCall(val name: String, val args: JSONObject, val raw: JSONObject? = null)

/** What a tool really did, sent back to the model so it can report the true outcome. */
class ToolResult(val name: String, val response: JSONObject)

data class ChatTurn(
    val role: Role,
    val text: String,
    val attachment: PendingAttachment? = null,
    val modelParts: List<JSONObject>? = null,       // set on a model turn that contained tool calls
    val toolResults: List<ToolResult> = emptyList(), // set on the user turn that returns tool results
) {
    enum class Role { USER, ASSISTANT }
}

data class AiOptions(val model: String, val voiceMode: Boolean, val tools: JSONArray? = null)

sealed interface AiEvent {
    data class Text(val text: String, val raw: JSONObject? = null) : AiEvent
    data class Call(val call: FnCall) : AiEvent
}

class AiException(val kind: Kind, val detail: String = "", val provider: String = "Gemini") : Exception(detail.ifBlank { kind.name }) {
    enum class Kind { NO_KEY, OFFLINE, INVALID_KEY, MODEL_NOT_FOUND, RATE_LIMIT, BLOCKED, SERVER, BAD_REQUEST, EMPTY, NETWORK, UNKNOWN }

    val userMessage: String
        get() = when (kind) {
            Kind.NO_KEY -> "Add your Gemini API key to start using JARVIS AI."
            Kind.OFFLINE -> "You're offline. This feature needs an internet connection."
            Kind.INVALID_KEY -> if (provider == "Gemini") "Gemini rejected your API key. Check it on the API Key page." else "$provider rejected your API key. Check it on the Super AI page."
            Kind.MODEL_NOT_FOUND -> "The selected AI model isn't available. Pick another model on the API Key page."
            Kind.RATE_LIMIT -> "$provider is rate-limiting requests right now. Please wait a moment and try again."
            Kind.BLOCKED -> "$provider couldn't answer that request."
            Kind.SERVER -> "$provider is having trouble right now. Please try again shortly."
            Kind.BAD_REQUEST -> "$provider couldn't process that request."
            Kind.EMPTY -> "I didn't get a response. Please try again."
            Kind.NETWORK, Kind.UNKNOWN -> "Something went wrong talking to $provider. Please try again."
        }
}

/** Future providers (Super AI) implement this only when truly integrated. */
interface AiProvider {
    val id: String
    suspend fun isConfigured(): Boolean
    /** False for providers that can't call phone tools (everything except Gemini). */
    val supportsTools: Boolean get() = true
    fun events(history: List<ChatTurn>, systemPrompt: String, options: AiOptions): Flow<AiEvent>

    fun stream(history: List<ChatTurn>, systemPrompt: String, options: AiOptions): Flow<String> =
        events(history, systemPrompt, options).filterIsInstance<AiEvent.Text>().map { it.text }

    suspend fun reply(history: List<ChatTurn>, systemPrompt: String, options: AiOptions): String =
        stream(history, systemPrompt, options).toList().joinToString("")
}
