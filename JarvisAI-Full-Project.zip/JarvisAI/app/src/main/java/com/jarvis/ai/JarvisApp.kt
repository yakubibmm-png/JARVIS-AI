package com.jarvis.ai

import android.app.Application
import com.jarvis.ai.di.AppContainer
import com.jarvis.ai.reminders.Notifier

class JarvisApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        Notifier.ensureChannels(this)
        com.jarvis.ai.ui.theme.Appearance.load(container.prefs)
    }
}
