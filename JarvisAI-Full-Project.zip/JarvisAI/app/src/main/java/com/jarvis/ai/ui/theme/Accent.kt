package com.jarvis.ai.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.jarvis.ai.R
import com.jarvis.ai.data.AppPrefs

data class AccentOption(val name: String, val primary: Color, val secondary: Color)

/** Snapshot state: composables that read JarvisColors.Cyan/Neon recompose when the accent changes. */
object Accent {
    val options = listOf(
        AccentOption("Cyan", Color(0xFF22D3EE), Color(0xFF38BDF8)),
        AccentOption("Violet", Color(0xFFA78BFA), Color(0xFF8B5CF6)),
        AccentOption("Pink", Color(0xFFF472B6), Color(0xFFEC4899)),
        AccentOption("Teal", Color(0xFF2DD4BF), Color(0xFF14B8A6)),
        AccentOption("Orange", Color(0xFFFB923C), Color(0xFFF97316)),
        AccentOption("Red", Color(0xFFF87171), Color(0xFFEF4444)),
    )
    var index by mutableIntStateOf(0); private set
    var cyan by mutableStateOf(options[0].primary); private set
    var neon by mutableStateOf(options[0].secondary); private set

    fun select(i: Int) {
        val o = options.getOrElse(i) { options[0] }
        index = options.indexOf(o); cyan = o.primary; neon = o.secondary
    }
}

object Appearance {
    private val avatars = intArrayOf(R.drawable.jarvis_logo, R.drawable.avatar_1, R.drawable.avatar_2, R.drawable.avatar_3)
    val avatarNames = listOf("Original", "Violet", "Mint", "Sunset")
    var avatar by mutableIntStateOf(0); private set
    fun avatarRes(): Int = avatars[avatar.coerceIn(0, avatars.lastIndex)]
    fun avatarRes(i: Int): Int = avatars[i.coerceIn(0, avatars.lastIndex)]
    val avatarCount get() = avatars.size
    fun selectAvatar(i: Int) { avatar = i.coerceIn(0, avatars.lastIndex) }

    val fontScales = listOf("Small" to 0.9f, "Medium" to 1.0f, "Large" to 1.15f, "Extra large" to 1.3f)
    var fontIndex by mutableIntStateOf(1); private set
    val fontScale: Float get() = fontScales[fontIndex.coerceIn(0, fontScales.lastIndex)].second
    fun selectFont(i: Int) { fontIndex = i.coerceIn(0, fontScales.lastIndex) }

    fun load(prefs: AppPrefs) { Accent.select(prefs.accentIndex); selectAvatar(prefs.avatarIndex); selectFont(prefs.fontScaleIndex) }
}
