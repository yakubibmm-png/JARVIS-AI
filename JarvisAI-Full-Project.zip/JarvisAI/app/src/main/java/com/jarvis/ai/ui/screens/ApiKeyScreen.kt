package com.jarvis.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.jarvis.ai.data.ModelCategory
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.premium.PremiumFeature
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ProBadge
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.jarvisTextFieldColors
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.util.Links
import com.jarvis.ai.util.openUrl
import android.widget.Toast

@Composable
fun ApiKeyScreen(onBack: () -> Unit, onOpenGate: (PremiumFeature) -> Unit) {
    val c = LocalContainer.current
    val vm: ApiKeyViewModel = viewModel(factory = viewModelFactory { initializer { ApiKeyViewModel(c.credentials, c.models) } })
    val ctx = LocalContext.current
    val isPremium by c.premium.isPremium.collectAsState()
    val selectedId by vm.models.selectedId.collectAsState()

    fun open(url: String) { if (!ctx.openUrl(url)) Toast.makeText(ctx, "No browser available to open the link.", Toast.LENGTH_SHORT).show() }

    ScreenScaffold("AI API Keys", "Connect Gemini and ElevenLabs", onBack) {
        // ── Gemini ──
        KeyCard(
            title = "Gemini API Key", placeholder = "Enter Gemini API Key", icon = Icons.Filled.AutoAwesome, tint = JarvisColors.Cyan,
            field = vm.gemini, getLabel = "GET FREE KEY", onGet = { open(Links.GEMINI_KEY_URL) },
        )
        Text(
            "Gemini powers the main intelligence and voice conversation features of JARVIS AI. Add your Gemini API key to connect the assistant and enable AI conversations.",
            color = JarvisColors.TextDim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp),
        )

        // ── Model selection ──
        GlassCard {
            Text("AI Model", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("Currently selected", color = JarvisColors.TextDim, fontSize = 12.sp)
            Text("${vm.models.labelFor(selectedId)}  ·  $selectedId", color = JarvisColors.Cyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModelCategory.entries.forEach { cat ->
                    val sel = vm.category == cat
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                            .background(if (sel) JarvisColors.Blue else JarvisColors.BgTop)
                            .border(1.dp, if (sel) JarvisColors.Cyan else JarvisColors.Blue.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .clickable(role = Role.Tab) { vm.pickCategory(cat) }.padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text(cat.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
            Spacer(Modifier.height(8.dp))
            val inCat = vm.models.catalog.filter { it.category == vm.category }
            if (inCat.isEmpty()) Text("No models configured for this category. Edit assets/gemini_models.json or enter a custom model ID below.", color = JarvisColors.TextDim, fontSize = 12.sp)
            inCat.forEach { m ->
                val locked = m.premium && !isPremium
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .clickable(role = Role.RadioButton) { if (locked) onOpenGate(PremiumFeature.ADVANCED_AI_MODELS) else vm.models.select(m.id) }
                        .padding(vertical = 8.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(20.dp).clip(CircleShape).border(2.dp, if (selectedId == m.id) JarvisColors.Cyan else JarvisColors.TextDim, CircleShape).padding(4.dp)
                            .background(if (selectedId == m.id) JarvisColors.Cyan else Color.Transparent, CircleShape),
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(m.description, color = JarvisColors.TextDim, fontSize = 12.sp)
                        Text(m.id, color = JarvisColors.Neon.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                    if (m.premium) ProBadge(locked = locked)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Custom model ID (advanced)", color = JarvisColors.TextDim, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = vm.customDraft, onValueChange = { vm.customDraft = it; vm.customError = null },
                    placeholder = { Text("e.g. a model ID from Google's list") }, singleLine = true,
                    colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f),
                    isError = vm.customError != null,
                )
                Spacer(Modifier.width(8.dp))
                NeonButton("USE", { vm.applyCustom() }, enabled = vm.customDraft.isNotBlank())
            }
            vm.customError?.let { Text(it, color = JarvisColors.Danger, fontSize = 12.sp) }
        }

        // ── ElevenLabs ──
        KeyCard(
            title = "ElevenLabs API Key", placeholder = "Enter ElevenLabs API Key", icon = Icons.Filled.GraphicEq, tint = JarvisColors.Purple,
            field = vm.eleven, getLabel = "GET KEY", onGet = { open(Links.ELEVENLABS_KEY_URL) },
        )
        Text(
            "ElevenLabs enables additional high-quality voice generation and premium voice options for JARVIS AI.",
            color = JarvisColors.TextDim, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun KeyCard(
    title: String, placeholder: String, icon: ImageVector, tint: Color,
    field: KeyField, getLabel: String, onGet: () -> Unit,
) {
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlowIcon(icon, tint)
            Spacer(Modifier.width(12.dp))
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = field.text, onValueChange = field::onChange, singleLine = true,
            placeholder = { Text(placeholder) },
            visualTransformation = if (field.visible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            leadingIcon = { Icon(Icons.Filled.Key, null, tint = JarvisColors.TextDim) },
            colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(6.dp))
        val (msg, color) = when (field.status) {
            KeyStatus.SAVED -> "Key saved" to JarvisColors.Success
            KeyStatus.INCOMPLETE -> "Key looks incomplete" to JarvisColors.Gold
            KeyStatus.EMPTY -> "No key added" to JarvisColors.TextDim
        }
        Text(msg, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton(
                if (field.visible) "HIDE KEY" else "SHOW KEY", field::toggleVisible, Modifier.weight(1f),
                icon = if (field.visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, filled = false,
            )
            NeonButton(getLabel, onGet, Modifier.weight(1f), icon = Icons.Filled.OpenInNew)
        }
    }
}
