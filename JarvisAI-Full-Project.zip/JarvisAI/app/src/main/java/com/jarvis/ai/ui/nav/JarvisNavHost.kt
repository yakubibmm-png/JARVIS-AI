package com.jarvis.ai.ui.nav

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.premium.PremiumFeature
import com.jarvis.ai.ui.screens.AboutScreen
import com.jarvis.ai.ui.screens.ActionsScreen
import com.jarvis.ai.ui.screens.AppearanceScreen
import com.jarvis.ai.ui.screens.NotificationsScreen
import com.jarvis.ai.ui.screens.PrivacyScreen
import com.jarvis.ai.ui.screens.AliasesScreen
import com.jarvis.ai.ui.screens.ApiKeyScreen
import com.jarvis.ai.ui.screens.AutoReplyScreen
import com.jarvis.ai.ui.screens.AutomationScreen
import com.jarvis.ai.ui.screens.LaunchScreen
import com.jarvis.ai.ui.screens.MoreFeaturesScreen
import com.jarvis.ai.ui.screens.PersonalizationScreen
import com.jarvis.ai.ui.screens.PreferencesScreen
import com.jarvis.ai.ui.screens.SuperAiScreen
import com.jarvis.ai.ui.screens.TasksScreen
import com.jarvis.ai.ui.screens.TriggersScreen
import com.jarvis.ai.ui.screens.VoicePackScreen
import com.jarvis.ai.ui.components.ConfirmationOverlay
import com.jarvis.ai.ui.screens.MusicScreen
import com.jarvis.ai.ui.screens.QuickActionsScreen
import com.jarvis.ai.ui.screens.RemindersScreen
import com.jarvis.ai.ui.screens.WeatherScreen
import com.jarvis.ai.ui.screens.ChatScreen
import com.jarvis.ai.ui.screens.VoiceAudioScreen
import com.jarvis.ai.ui.screens.HomeScreen
import com.jarvis.ai.ui.screens.OnboardingScreen
import com.jarvis.ai.ui.screens.PermissionsScreen
import com.jarvis.ai.ui.screens.PhaseScreen
import com.jarvis.ai.ui.screens.PremiumGateScreen
import com.jarvis.ai.ui.screens.ProScreen
import com.jarvis.ai.ui.screens.SettingsScreen
import com.jarvis.ai.ui.screens.ToolsScreen
import com.jarvis.ai.ui.theme.JarvisColors

private class NavItem(val route: String, val label: String, val icon: ImageVector, val gold: Boolean = false)

private val bottomItems = listOf(
    NavItem(Routes.HOME, "Home", Icons.Filled.Home),
    NavItem(Routes.TOOLS, "Tools", Icons.Filled.GridView),
    NavItem(Routes.CHAT, "Chat", Icons.Filled.Chat),
    NavItem(Routes.SETTINGS, "Settings", Icons.Filled.Settings),
    NavItem(Routes.PRO, "Pro", Icons.Filled.WorkspacePremium, true),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JarvisNavHost() {
    val c = LocalContainer.current
    val nav = rememberNavController()
    val isPremium by c.premium.isPremium.collectAsState()
    val start = remember { if (c.prefs.onboardingDone) Routes.HOME else Routes.ONBOARDING }

    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val imeVisible = WindowInsets.isImeVisible
    val showBar = route in Routes.topLevel && !imeVisible

    fun goTop(r: String) = nav.navigate(r) {
        popUpTo(Routes.HOME)
        launchSingleTop = true
    }
    fun go(r: String) = nav.navigate(r) { launchSingleTop = true }
    fun gate(f: PremiumFeature) = nav.navigate(Routes.gate(f)) { launchSingleTop = true }
    val back: () -> Unit = { nav.popBackStack() }

    Scaffold(
        containerColor = JarvisColors.Bg,
        contentWindowInsets = WindowInsets(0),
        bottomBar = { if (showBar) BottomBar(route, ::goTop) },
    ) { inner ->
        androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
        NavHost(
            nav, startDestination = start,
            modifier = Modifier.fillMaxSize().padding(bottom = inner.calculateBottomPadding()).then(if (showBar) Modifier else Modifier.navigationBarsPadding()),
        ) {
            composable(Routes.ONBOARDING) {
                OnboardingScreen(
                    onAddKey = { go(Routes.API_KEY) },
                    onPermissions = { go(Routes.PERMISSIONS) },
                    onFinish = {
                        c.prefs.onboardingDone = true
                        nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                    },
                )
            }
            composable(Routes.HOME) {
                HomeScreen(
                    onOpenSettings = { goTop(Routes.SETTINGS) }, onOpenApiKey = { go(Routes.API_KEY) },
                    onQuickActions = { go(Routes.QUICK_ACTIONS) }, onReminders = { go(Routes.REMINDERS) },
                    onMusic = { go(Routes.MUSIC) }, onWeather = { go(Routes.WEATHER) }, onOpenPermissions = { go(Routes.PERMISSIONS) },
                )
            }
            composable(Routes.TOOLS) { ToolsScreen(onNavigate = ::go, onGate = ::gate) }
            composable(Routes.CHAT) { ChatScreen(onOpenApiKey = { go(Routes.API_KEY) }, onQuickActions = { go(Routes.QUICK_ACTIONS) }) }
            composable(Routes.SETTINGS) { SettingsScreen(onNavigate = ::go, onGate = ::gate) }
            composable(Routes.PRO) { ProScreen(onStartExploring = { goTop(Routes.HOME) }) }
            composable(Routes.API_KEY) { ApiKeyScreen(onBack = back, onOpenGate = ::gate) }
            composable(Routes.PERMISSIONS) { PermissionsScreen(onBack = back, onGate = ::gate) }

            composable(
                Routes.GATE_PATTERN, arguments = listOf(navArgument("feature") { type = NavType.StringType }),
            ) { e ->
                val f = runCatching { PremiumFeature.valueOf(e.arguments?.getString("feature").orEmpty()) }.getOrNull()
                if (f == null) LaunchedEffect(Unit) { nav.popBackStack() }
                else PremiumGateScreen(f, onUnlock = { goTop(Routes.PRO) }, onBack = back)
            }

            // Home quick cards (real screens, backed by the action engine)
            composable(Routes.QUICK_ACTIONS) { QuickActionsScreen(onBack = back, onNavigate = ::go) }
            composable(Routes.REMINDERS) { RemindersScreen(onBack = back) }
            composable(Routes.MUSIC) { MusicScreen(onBack = back) }
            composable(Routes.WEATHER) { WeatherScreen(onBack = back) }

            // Premium tools (a free user is redirected to the Premium explanation)
            gated(nav, isPremium, Routes.VOICE_PACK, PremiumFeature.VOICE_PACK) { VoicePackScreen(onBack = back, onOpenApiKey = { go(Routes.API_KEY) }) }
            gated(nav, isPremium, Routes.SUPER_AI, PremiumFeature.SUPER_AI) { SuperAiScreen(onBack = back, onOpenApiKey = { go(Routes.API_KEY) }) }
            gated(nav, isPremium, Routes.PREFERENCES, PremiumFeature.PREFERENCES) { PreferencesScreen(onBack = back, onOpenVoicePack = { go(Routes.VOICE_PACK) }) }
            gated(nav, isPremium, Routes.PERSONALIZATION, PremiumFeature.PERSONALIZATION) { PersonalizationScreen(onBack = back) }
            gated(nav, isPremium, Routes.AUTOMATION, PremiumFeature.AUTOMATION) { AutomationScreen(onBack = back, onNavigate = ::go) }
            gated(nav, isPremium, Routes.MORE_FEATURES, PremiumFeature.MORE_FEATURES) { MoreFeaturesScreen(onBack = back, onNavigate = ::go) }
            gated(nav, isPremium, Routes.AUTO_REPLY, PremiumFeature.AUTO_REPLY) { AutoReplyScreen(onBack = back, onOpenAutomation = { go(Routes.AUTOMATION) }) }
            gated(nav, isPremium, Routes.AUTO_LAUNCH, PremiumFeature.AUTOMATION) { LaunchScreen(onBack = back) }
            gated(nav, isPremium, Routes.AUTO_TASKS, PremiumFeature.AUTOMATION) { TasksScreen(onBack = back) }
            gated(nav, isPremium, Routes.AUTO_TRIGGERS, PremiumFeature.AUTOMATION) { TriggersScreen(onBack = back, onOpenAutomation = { go(Routes.AUTOMATION) }) }
            gated(nav, isPremium, Routes.AUTO_ACTIONS, PremiumFeature.AUTOMATION) { ActionsScreen(onBack = back) }
            gated(nav, isPremium, Routes.ALIASES, PremiumFeature.AUTO_REPLY) { AliasesScreen(onBack = back) }

            // Settings sub-pages (Phase 5)
            composable(Routes.SETTINGS_VOICE) {
                VoiceAudioScreen(onBack = back, onNavigate = ::go, onGate = ::gate, onOpenApiKey = { go(Routes.API_KEY) })
            }
            composable(Routes.SETTINGS_NOTIFICATIONS) { NotificationsScreen(onBack = back, onNavigate = ::go) }
            composable(Routes.SETTINGS_PRIVACY) { PrivacyScreen(onBack = back, onNavigate = ::go) }
            composable(Routes.SETTINGS_APPEARANCE) { AppearanceScreen(onBack = back) }
            composable(Routes.SETTINGS_ABOUT) { AboutScreen(onBack = back) }
        }
        ConfirmationOverlay(Modifier.align(Alignment.TopCenter))
        }
    }
}

private fun androidx.navigation.NavGraphBuilder.phase(
    route: String, title: String, subtitle: String, icon: ImageVector, phase: Int, items: List<String>, onBack: () -> Unit,
) = composable(route) { PhaseScreen(title, subtitle, icon, phase, items, onBack) }

private fun androidx.navigation.NavGraphBuilder.gated(
    nav: NavHostController, isPremium: Boolean, route: String, feature: PremiumFeature, content: @Composable () -> Unit,
) = composable(route) {
    if (isPremium) content()
    else LaunchedEffect(Unit) { nav.navigate(Routes.gate(feature)) { popUpTo(route) { inclusive = true } } }
}

@Composable
private fun BottomBar(current: String?, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(JarvisColors.BgBottom.copy(alpha = 0.97f)).border(1.dp, JarvisColors.Blue.copy(alpha = 0.35f)).navigationBarsPadding().height(62.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        bottomItems.forEach { item ->
            val sel = current == item.route
            val accent = if (item.gold) JarvisColors.Gold else JarvisColors.Neon
            val tint = if (sel || item.route == Routes.PRO) accent else JarvisColors.TextDim
            Column(
                Modifier.weight(1f).fillMaxSize().clickable(role = Role.Tab) { if (!sel) onSelect(item.route) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
            ) {
                Icon(item.icon, null, tint = tint, modifier = Modifier.size(24.dp))
                Text(item.label, color = tint, fontSize = 11.sp)
                Box(Modifier.padding(top = 3.dp).width(if (sel) 22.dp else 0.dp).height(2.dp).background(tint))
            }
        }
    }
}
