package com.jarvis.ai.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.theme.JarvisColors

/** Shown on every screen while an action waits for the user's yes. Nothing consequential happens without it. */
@Composable
fun ConfirmationOverlay(modifier: Modifier = Modifier) {
    val c = LocalContainer.current
    val pending by c.confirmations.pending.collectAsState()
    val p = pending ?: return
    GlassCard(modifier.statusBarsPadding().padding(12.dp).fillMaxWidth()) {
        Text(p.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(p.detail, color = JarvisColors.TextDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        Text("You can also say \"yes\" or \"no\".", color = JarvisColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("Cancel", { c.confirmations.cancel() }, Modifier.weight(1f), filled = false)
            NeonButton("Confirm", { c.confirmations.approveFromUi() }, Modifier.weight(1f), colors = listOf(Color(0xFF15803D), JarvisColors.Success))
        }
    }
}
