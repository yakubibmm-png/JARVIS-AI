package com.jarvis.ai.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.random.Random

/** Device text-to-speech. Always available as the last fallback. Call from the main thread. */
class AndroidTts(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private val ids = AtomicInteger()
    @Volatile private var pulse = 0f

    private suspend fun ensure(): TextToSpeech {
        tts?.let { return it }
        return suspendCancellableCoroutine { cont ->
            var created: TextToSpeech? = null
            created = TextToSpeech(ctx.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts = created
                    if (cont.isActive) cont.resume(created!!)
                } else if (cont.isActive) cont.resumeWithException(VoiceProviderException("Text-to-speech isn't available on this device."))
            }
        }
    }

    suspend fun speak(text: String, rate: Float, pitch: Float, volume: Float, onLevel: (Float) -> Unit) {
        val engine = ensure()
        val wanted = ScriptLocale.guess(text) ?: Locale.getDefault()
        val r = engine.setLanguage(wanted)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) engine.setLanguage(Locale.getDefault())
        engine.setSpeechRate(rate.coerceIn(0.3f, 3f))
        engine.setPitch(pitch.coerceIn(0.3f, 3f))
        val parts = SpeechText.chunks(text, (TextToSpeech.getMaxSpeechInputLength() - 100).coerceIn(500, 3500))
        coroutineScope {
            // The device engine exposes no audio samples, so the waveform pulses on each spoken word.
            val ticker = launch {
                while (isActive) { pulse *= 0.82f; onLevel(pulse); delay(45) }
            }
            try {
                for (p in parts) speakOne(engine, p, volume)
            } finally {
                ticker.cancel(); pulse = 0f; onLevel(0f)
            }
        }
    }

    fun stop() { tts?.stop() }

    private suspend fun speakOne(engine: TextToSpeech, text: String, volume: Float) = suspendCancellableCoroutine<Unit> { cont ->
        val id = "u${ids.incrementAndGet()}"
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (utteranceId == id && cont.isActive) cont.resume(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId == id && cont.isActive) cont.resumeWithException(VoiceProviderException("Text-to-speech failed."))
            }
            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) { pulse = 0.45f + Random.nextFloat() * 0.45f }
        })
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f)) }
        val res = engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, id)
        if (res != TextToSpeech.SUCCESS && cont.isActive) cont.resumeWithException(VoiceProviderException("Text-to-speech failed."))
        cont.invokeOnCancellation { engine.stop() }
    }
}
