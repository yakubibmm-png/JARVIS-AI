package com.jarvis.ai.voice

/** Phase 2: Gemini voice, ElevenLabs and Android TTS implement this. ElevenLabs missing => fall back, never crash. */
interface TtsProvider {
    val id: String
    suspend fun isAvailable(): Boolean
    suspend fun speak(text: String, onLevel: (Float) -> Unit = {})
    fun stop()
}
