package com.jarvis.ai.ai

import android.content.Context
import com.jarvis.ai.util.isOnline
import com.jarvis.ai.util.withConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

private fun errorKind(code: Int, body: String, provider: String): AiException {
    val msg = runCatching { JSONObject(body).let { it.optJSONObject("error")?.optString("message") ?: it.optString("message") } }.getOrNull().orEmpty()
    val kind = when {
        code == 401 || code == 403 -> AiException.Kind.INVALID_KEY
        code == 404 -> AiException.Kind.MODEL_NOT_FOUND
        code == 429 -> AiException.Kind.RATE_LIMIT
        code in 500..599 -> AiException.Kind.SERVER
        code == 400 -> AiException.Kind.BAD_REQUEST
        else -> AiException.Kind.UNKNOWN
    }
    return AiException(kind, msg, provider)
}

private fun plainText(t: ChatTurn): String = buildString {
    append(t.text)
    t.attachment?.let { a -> if (a.text != null) append("\n\nAttached file \"${a.name}\":\n${a.text}") else append("\n\n[An attachment named ${a.name} was not sent: this AI is used in text-only mode.]") }
}

/** OpenAI, Perplexity, xAI and any OpenAI-compatible service: /chat/completions with streaming. Text only (no phone tools). */
class OpenAiCompatProvider(
    override val id: String,
    private val providerName: String,
    private val ctx: Context,
    private val baseUrl: () -> String,
    private val path: String,
    private val apiKey: () -> String,
    private val model: () -> String,
) : AiProvider {
    override val supportsTools = false
    override suspend fun isConfigured() = apiKey().isNotBlank() && model().isNotBlank()

    override fun events(history: List<ChatTurn>, systemPrompt: String, options: AiOptions): Flow<AiEvent> = flow {
        val key = apiKey(); val m = model()
        if (key.isBlank() || m.isBlank()) throw AiException(AiException.Kind.NO_KEY, provider = providerName)
        if (!ctx.isOnline()) throw AiException(AiException.Kind.OFFLINE, provider = providerName)
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
        history.forEach { t ->
            if (t.modelParts == null && t.toolResults.isEmpty()) msgs.put(JSONObject().put("role", if (t.role == ChatTurn.Role.USER) "user" else "assistant").put("content", plainText(t)))
        }
        val body = JSONObject().put("model", m).put("messages", msgs).put("stream", true).toString().toByteArray(Charsets.UTF_8)
        try {
            withConnection(baseUrl().trimEnd('/') + path, { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 60_000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Authorization", "Bearer $key")
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) throw errorKind(code, c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty(), providerName)
                var any = false
                c.inputStream.bufferedReader().use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val json = line.removePrefix("data:").trim()
                        if (json.isEmpty() || json == "[DONE]") continue
                        val delta = JSONObject(json).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content").orEmpty()
                        if (delta.isNotEmpty()) { any = true; emit(AiEvent.Text(delta)) }
                    }
                }
                if (!any) throw AiException(AiException.Kind.EMPTY, provider = providerName)
            }
        } catch (e: IOException) {
            throw AiException(if (e is UnknownHostException || e is ConnectException || e is SocketTimeoutException) AiException.Kind.OFFLINE else AiException.Kind.NETWORK, provider = providerName)
        }
    }.flowOn(Dispatchers.IO)
}

/** Anthropic Claude: /v1/messages with streaming. Text only (no phone tools). */
class AnthropicProvider(
    private val ctx: Context,
    private val baseUrl: () -> String,
    private val apiKey: () -> String,
    private val model: () -> String,
) : AiProvider {
    override val id = "anthropic"
    override val supportsTools = false
    override suspend fun isConfigured() = apiKey().isNotBlank() && model().isNotBlank()

    override fun events(history: List<ChatTurn>, systemPrompt: String, options: AiOptions): Flow<AiEvent> = flow {
        val key = apiKey(); val m = model()
        if (key.isBlank() || m.isBlank()) throw AiException(AiException.Kind.NO_KEY, provider = NAME)
        if (!ctx.isOnline()) throw AiException(AiException.Kind.OFFLINE, provider = NAME)
        val msgs = JSONArray()
        history.forEach { t ->
            if (t.modelParts == null && t.toolResults.isEmpty()) msgs.put(JSONObject().put("role", if (t.role == ChatTurn.Role.USER) "user" else "assistant").put("content", plainText(t)))
        }
        val body = JSONObject().put("model", m).put("max_tokens", 2048).put("system", systemPrompt).put("messages", msgs).put("stream", true).toString().toByteArray(Charsets.UTF_8)
        try {
            withConnection(baseUrl().trimEnd('/') + "/v1/messages", { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 60_000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01")
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) throw errorKind(code, c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty(), NAME)
                var any = false
                c.inputStream.bufferedReader().use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val o = JSONObject(line.removePrefix("data:").trim())
                        if (o.optString("type") == "content_block_delta") {
                            val d = o.optJSONObject("delta")
                            if (d?.optString("type") == "text_delta" && d.optString("text").isNotEmpty()) { any = true; emit(AiEvent.Text(d.optString("text"))) }
                        }
                    }
                }
                if (!any) throw AiException(AiException.Kind.EMPTY, provider = NAME)
            }
        } catch (e: IOException) {
            throw AiException(if (e is UnknownHostException || e is ConnectException || e is SocketTimeoutException) AiException.Kind.OFFLINE else AiException.Kind.NETWORK, provider = NAME)
        }
    }.flowOn(Dispatchers.IO)

    private companion object { const val NAME = "Claude" }
}
