package com.jarvis.ai.chat

import com.jarvis.ai.ai.AiEvent
import com.jarvis.ai.ai.AiException
import com.jarvis.ai.ai.AiOptions
import com.jarvis.ai.ai.AiProvider
import com.jarvis.ai.ai.AssistantProfile
import com.jarvis.ai.ai.ChatTurn
import com.jarvis.ai.ai.FnCall
import com.jarvis.ai.ai.PendingAttachment
import com.jarvis.ai.ai.SystemPrompt
import com.jarvis.ai.ai.ToolResult
import com.jarvis.ai.command.ActionContext
import com.jarvis.ai.command.ActionEngine
import com.jarvis.ai.command.ActionMemory
import com.jarvis.ai.command.ActionRecord
import com.jarvis.ai.command.ActionResult
import com.jarvis.ai.command.CommandRouter
import com.jarvis.ai.command.CommandUnderstanding
import com.jarvis.ai.command.JarvisIntent
import com.jarvis.ai.command.RunContext
import com.jarvis.ai.command.ToolSpecs
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.data.ModelRepository
import com.jarvis.ai.premium.PremiumRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

data class Outcome(
    val text: String,
    val error: String?,
    val keyProblem: Boolean = false,
    /** JARVIS opened another app during this request (so JARVIS is no longer on screen). */
    val launchedExternal: Boolean = false,
    /** A permission the user must enable for the request to work. */
    val permissionHint: String? = null,
)

/**
 * The single pipeline for Chat AND voice:
 *   user message -> Gemini (with phone tools) -> [tool calls -> planner -> executor -> REAL results -> Gemini] -> reply.
 * Questions go straight to Gemini; phone commands become tool calls that really run on the device. If Gemini isn't
 * reachable (no key / offline), a small local parser still handles simple commands.
 */
class ConversationEngine(
    private val repo: ChatRepository,
    private val ai: AiProvider,
    private val models: ModelRepository,
    private val prefs: AppPrefs,
    private val premium: PremiumRepository,
    private val router: CommandRouter,
    private val scope: CoroutineScope,
    private val actions: ActionEngine,
    private val memory: ActionMemory,
    private val local: CommandUnderstanding,
    private val shortcutNames: () -> List<String> = { emptyList() },
) {
    private val _generating = MutableStateFlow(false)
    val generating: StateFlow<Boolean> = _generating.asStateFlow()
    private val gate = Mutex()
    private var job: Job? = null

    /** Fire-and-forget from the UI; survives leaving the Chat screen. */
    fun submit(text: String, attachment: PendingAttachment? = null) {
        if (_generating.value) return
        job = scope.launch { send(text, attachment, viaVoice = false) }
    }

    fun cancel() { job?.cancel() }

    /** Adds an assistant message without calling Gemini (e.g. "Spotify has been installed"). */
    fun postAssistantNote(text: String) {
        val id = repo.currentId()
        repo.append(id, ChatMessage(UUID.randomUUID().toString(), ChatRole.ASSISTANT, text, System.currentTimeMillis()))
        repo.flush()
    }

    suspend fun send(
        text: String, attachment: PendingAttachment?, viaVoice: Boolean,
        onPartial: (String) -> Unit = {}, onStatus: (String) -> Unit = {},
    ): Outcome {
        if (!gate.tryLock()) return Outcome("", "I'm still working on your last message.")
        _generating.value = true
        actions.requestId += 1
        try {
            return run(text, attachment, viaVoice, onPartial, onStatus)
        } finally {
            _generating.value = false
            gate.unlock()
            repo.flush()
        }
    }

    private suspend fun run(text: String, attachment: PendingAttachment?, viaVoice: Boolean, onPartial: (String) -> Unit, onStatus: (String) -> Unit): Outcome {
        val convId = repo.currentId()
        repo.append(convId, ChatMessage(uid(), ChatRole.USER, text, System.currentTimeMillis(), viaVoice = viaVoice, attachment = attachment?.let { AttachmentInfo(it.name, it.mime) }))
        val aId = uid()
        repo.append(convId, ChatMessage(aId, ChatRole.ASSISTANT, "", System.currentTimeMillis(), MessageStatus.STREAMING, viaVoice))

        // Optional pre-AI hook (kept from Phase 2; the default router passes everything through).
        router.tryHandle(text, ActionContext(viaVoice))?.let { r ->
            val reply = when (r) {
                is ActionResult.Success -> r.spokenSummary
                is ActionResult.NeedsClarification -> r.question
                is ActionResult.NeedsPermission -> r.message
                is ActionResult.Failed -> r.message
            }
            repo.updateMessage(convId, aId) { it.copy(text = reply, status = if (r is ActionResult.Failed) MessageStatus.ERROR else MessageStatus.OK) }
            onPartial(reply)
            return Outcome(reply, (r as? ActionResult.Failed)?.message)
        }

        val withTools = ai.supportsTools
        val system = SystemPrompt.build(AssistantProfile.from(prefs), viaVoice, phoneContext = if (withTools) memory.snapshot() else "", tools = withTools, shortcuts = shortcutNames())
        val tools = if (withTools) ToolSpecs.declarations() else null
        var turns = buildHistory(convId, aId, attachment)
        val sb = StringBuilder()
        val records = ArrayList<ActionRecord>()
        var launched = false
        var permissionHint: String? = null

        try {
            var round = 0
            while (true) {
                sb.setLength(0)
                val calls = ArrayList<FnCall>()
                val raws = ArrayList<JSONObject>()
                try {
                    ai.events(turns, system, AiOptions(effectiveModel(), viaVoice, if (round < MAX_ROUNDS) tools else null)).collect { ev ->
                        when (ev) {
                            is AiEvent.Text -> {
                                sb.append(ev.text); ev.raw?.let { raws.add(it) }
                                if (calls.isEmpty()) { val t = sb.toString(); repo.updateMessage(convId, aId) { it.copy(text = t) }; onPartial(t) }
                            }
                            is AiEvent.Call -> { calls.add(ev.call); ev.call.raw?.let { raws.add(it) } }
                        }
                    }
                } catch (e: AiException) {
                    if (round == 0) throw e
                    sb.setLength(0)   // actions already ran: report them from their real results below
                    break
                }
                if (calls.isEmpty()) break

                sb.setLength(0)
                repo.updateMessage(convId, aId) { it.copy(text = "") }
                val results = actions.execute(calls, RunContext(viaVoice, onStatus))
                results.forEachIndexed { i, o ->
                    records.add(ActionRecord(calls[i].name, o.ok, o.summary))
                    if (o.launchedExternal) launched = true
                    if (o.needsPermission != null && permissionHint == null) permissionHint = o.summary
                }
                val snapshot = records.toList()
                repo.updateMessage(convId, aId) { it.copy(actions = snapshot) }
                turns = turns +
                    ChatTurn(ChatTurn.Role.ASSISTANT, "", modelParts = raws.toList()) +
                    ChatTurn(ChatTurn.Role.USER, "", toolResults = calls.mapIndexed { i, c -> ToolResult(c.name, results[i].toResponse()) })
                round++
            }

            var finalText = sb.toString().trim()
            if (finalText.isEmpty() && records.isNotEmpty()) finalText = records.joinToString(" ") { it.summary }
            if (finalText.isEmpty()) throw AiException(AiException.Kind.EMPTY)
            val snapshot = records.toList()
            repo.updateMessage(convId, aId) { it.copy(text = finalText, status = MessageStatus.OK, timestamp = System.currentTimeMillis(), actions = snapshot) }
            return Outcome(finalText, null, launchedExternal = launched, permissionHint = permissionHint)
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                repo.updateMessage(convId, aId) {
                    if (sb.isEmpty() && records.isEmpty()) null
                    else it.copy(text = sb.toString().trim().ifEmpty { records.joinToString(" ") { r -> r.summary } }, status = MessageStatus.CANCELLED, actions = records.toList())
                }
            }
            throw e
        } catch (e: AiException) {
            // No Gemini (no key / offline): simple commands still work through the local parser.
            if ((e.kind == AiException.Kind.NO_KEY || e.kind == AiException.Kind.OFFLINE) && records.isEmpty()) {
                tryLocal(text, viaVoice, onStatus)?.let { fb ->
                    repo.updateMessage(convId, aId) { it.copy(text = fb.text, status = MessageStatus.OK, actions = fb.records) }
                    onPartial(fb.text)
                    return Outcome(fb.text, null, launchedExternal = fb.launched, permissionHint = fb.permissionHint)
                }
            }
            val msg = e.userMessage
            if (sb.isEmpty() && records.isEmpty()) repo.updateMessage(convId, aId) { it.copy(text = msg, status = MessageStatus.ERROR) }
            else repo.updateMessage(convId, aId) { it.copy(status = MessageStatus.OK) }
            val keyProblem = e.kind == AiException.Kind.NO_KEY || e.kind == AiException.Kind.INVALID_KEY
            return if (sb.isEmpty() && records.isEmpty()) Outcome("", msg, keyProblem) else Outcome(sb.toString().trim(), null)
        }
    }

    private class LocalReply(val text: String, val records: List<ActionRecord>, val launched: Boolean, val permissionHint: String?)

    private suspend fun tryLocal(text: String, viaVoice: Boolean, onStatus: (String) -> Unit): LocalReply? {
        val parsed = local.parse(text)
        if (parsed.intent == JarvisIntent.UNKNOWN) return null
        val (name, args) = ToolSpecs.callFor(parsed) ?: return null
        val o = actions.execute(listOf(FnCall(name, args)), RunContext(viaVoice, onStatus)).first()
        val reply = buildString {
            append(o.summary)
            o.needsUserAction?.let { append(' ').append(it) }
            o.candidates?.let { append(" Which one: ").append(it.joinToString(", ")).append('?') }
        }
        return LocalReply(reply, listOf(ActionRecord(name, o.ok, o.summary)), o.launchedExternal, if (o.needsPermission != null) o.summary else null)
    }

    private fun effectiveModel(): String {
        val id = models.selectedId.value.ifBlank { models.defaultModelId }
        val m = models.find(id)
        if (m != null && m.premium && !premium.isPremium.value) {
            return models.catalog.firstOrNull { !it.premium }?.id ?: models.defaultModelId
        }
        return id
    }

    private fun buildHistory(convId: String, placeholderId: String, attachment: PendingAttachment?): List<ChatTurn> {
        val msgs = (repo.current()?.takeIf { it.id == convId }?.messages ?: emptyList())
            .filter { it.id != placeholderId && it.status != MessageStatus.ERROR && it.text.isNotBlank() }
            .takeLast(24)
        val out = ArrayList<ChatTurn>()
        msgs.forEachIndexed { i, m ->
            val role = if (m.role == ChatRole.USER) ChatTurn.Role.USER else ChatTurn.Role.ASSISTANT
            val isLast = i == msgs.lastIndex
            var t = m.text
            if (m.attachment != null && !isLast) t += "\n[Attached earlier: ${m.attachment.name}]"
            val turn = ChatTurn(role, t, if (isLast && role == ChatTurn.Role.USER) attachment else null)
            val prev = out.lastOrNull()
            if (prev != null && prev.role == role) out[out.lastIndex] = ChatTurn(role, prev.text + "\n\n" + turn.text, turn.attachment ?: prev.attachment)
            else out.add(turn)
        }
        while (out.isNotEmpty() && out.first().role == ChatTurn.Role.ASSISTANT) out.removeAt(0)
        return out
    }

    private fun uid() = UUID.randomUUID().toString()

    private companion object { const val MAX_ROUNDS = 3 }
}
