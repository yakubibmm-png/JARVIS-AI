package com.jarvis.ai.contacts

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.jarvis.ai.util.TextMatch

data class PhoneNumber(val number: String, val type: String, val isMobile: Boolean)
data class Contact(val key: String, val name: String, val numbers: List<PhoneNumber>)

sealed interface ContactMatch {
    data class Found(val contact: Contact) : ContactMatch
    data class Ambiguous(val contacts: List<Contact>) : ContactMatch
    data object NotFound : ContactMatch
    data object NoPermission : ContactMatch
}

data class Alias(val alias: String, val contactKey: String, val contactName: String)

/** Saved short names ("72" -> a contact) usable in voice commands: "Message 72 on WhatsApp: hello". */
class AliasStore(ctx: Context) {
    private val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("jarvis_aliases2", Context.MODE_PRIVATE)
    private val _all = kotlinx.coroutines.flow.MutableStateFlow(read())
    val all: kotlinx.coroutines.flow.StateFlow<List<Alias>> = _all

    fun get(alias: String): String? = _all.value.firstOrNull { TextMatch.norm(it.alias) == TextMatch.norm(alias) }?.contactKey

    @Synchronized fun set(alias: String, contactKey: String, contactName: String) {
        val a = alias.trim(); if (a.isEmpty()) return
        save(_all.value.filterNot { TextMatch.norm(it.alias) == TextMatch.norm(a) } + Alias(a, contactKey, contactName))
    }
    @Synchronized fun remove(alias: String) = save(_all.value.filterNot { it.alias == alias })

    private fun save(l: List<Alias>) {
        val arr = org.json.JSONArray(); l.forEach { arr.put(org.json.JSONObject().put("a", it.alias).put("k", it.contactKey).put("n", it.contactName)) }
        sp.edit().putString("aliases", arr.toString()).apply(); _all.value = l.sortedBy { it.alias.lowercase() }
    }
    private fun read(): List<Alias> = runCatching {
        val arr = org.json.JSONArray(sp.getString("aliases", "[]"))
        (0 until arr.length()).map { arr.getJSONObject(it).let { o -> Alias(o.getString("a"), o.getString("k"), o.getString("n")) } }
    }.getOrDefault(emptyList())
}

/** Contact lookup is done on the device. Phone numbers are never sent to Gemini. */
class ContactsRepository(private val ctx: Context, private val aliases: AliasStore) {
    @Volatile private var cache: List<Contact> = emptyList()
    @Volatile private var at = 0L

    fun hasPermission() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun all(): List<Contact> {
        if (!hasPermission()) return emptyList()
        if (System.currentTimeMillis() - at < 60_000 && cache.isNotEmpty()) return cache
        val map = LinkedHashMap<String, Pair<String, MutableList<PhoneNumber>>>()
        val P = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.LABEL,
        )
        ctx.contentResolver.query(P, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val key = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val number = c.getString(2) ?: continue
                val type = c.getInt(3)
                val label = ContactsContract.CommonDataKinds.Phone.getTypeLabel(ctx.resources, type, c.getString(4)).toString()
                val entry = map.getOrPut(key) { name to mutableListOf() }
                if (entry.second.none { TextMatch.norm(it.number) == TextMatch.norm(number) }) {
                    entry.second.add(PhoneNumber(number, label, type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE))
                }
            }
        }
        cache = map.map { (k, v) -> Contact(k, v.first, v.second) }
        at = System.currentTimeMillis()
        return cache
    }

    fun resolve(query: String): ContactMatch {
        if (!hasPermission()) return ContactMatch.NoPermission
        val all = all()
        aliases.get(query)?.let { key -> all.firstOrNull { it.key == key }?.let { return ContactMatch.Found(it) } }
        val scored = all.map { it to TextMatch.score(query, it.name) }.filter { it.second >= 70 }.sortedByDescending { it.second }
        if (scored.isEmpty()) return ContactMatch.NotFound
        val best = scored.first().second
        val near = scored.filter { it.second >= best - 6 }
        return if (near.size == 1 || (best == 100 && near.count { it.second == 100 } == 1)) ContactMatch.Found(near.first().first)
        else ContactMatch.Ambiguous(near.take(5).map { it.first })
    }

    fun search(query: String): List<Contact> =
        all().map { it to TextMatch.score(query, it.name) }.filter { it.second >= 60 }.sortedByDescending { it.second }.take(8).map { it.first }
}
