package com.jarvis.ai.chat

import android.content.Context
import com.jarvis.ai.command.ActionRecord
import com.jarvis.ai.data.AppPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Conversations shared by the Chat page and voice sessions. Stored as JSON in the app's private storage
 * (not additionally encrypted). Turn history off in [AppPrefs.chatHistoryEnabled] to keep chats in memory only.
 */
class ChatRepository(context: Context, private val prefs: AppPrefs, private val scope: CoroutineScope) {
    private val file = File(context.filesDir, "chats_v1.json")
    private val _all = MutableStateFlow(if (prefs.chatHistoryEnabled) readFile() else emptyList())
    val conversations: StateFlow<List<Conversation>> = _all.asStateFlow()
    private val _activeId = MutableStateFlow(prefs.activeConversationId)
    val activeId: StateFlow<String> = _activeId.asStateFlow()

    val active: StateFlow<Conversation?> = combine(_all, _activeId) { all, id -> all.firstOrNull { it.id == id } }
        .stateIn(scope, SharingStarted.Eagerly, null)

    private var saveJob: Job? = null

    init { currentId() }

    fun current(): Conversation? = _all.value.firstOrNull { it.id == _activeId.value }

    fun currentId(): String {
        current()?.let { return it.id }
        val latest = _all.value.filter { it.messages.isNotEmpty() }.maxByOrNull { it.updatedAt }
        if (latest != null) { setActive(latest.id); return latest.id }
        return newChat()
    }

    fun newChat(): String {
        current()?.let { if (it.messages.isEmpty()) return it.id }
        val now = System.currentTimeMillis()
        val c = Conversation(UUID.randomUUID().toString(), NEW_TITLE, now, now, emptyList())
        _all.update { listOf(c) + it.filter { x -> x.messages.isNotEmpty() } }
        setActive(c.id)
        return c.id
    }

    fun select(id: String) { if (_all.value.any { it.id == id }) setActive(id) }

    fun clear(id: String) = mutate(id) { it.copy(messages = emptyList(), title = NEW_TITLE, updatedAt = System.currentTimeMillis()) }

    /** Removes every conversation (Preferences → Clear Memory). */
    fun clearAll() {
        _all.value = emptyList()
        file.delete()
        newChat()
    }

    fun delete(id: String) {
        _all.update { list -> list.filterNot { it.id == id } }
        if (_activeId.value == id) {
            val next = _all.value.filter { it.messages.isNotEmpty() }.maxByOrNull { it.updatedAt }
            if (next != null) setActive(next.id) else newChat()
        }
        schedule()
    }

    fun append(convId: String, m: ChatMessage) = mutate(convId) { c ->
        c.copy(
            messages = c.messages + m,
            updatedAt = maxOf(c.updatedAt, m.timestamp),
            title = if (c.title == NEW_TITLE && m.role == ChatRole.USER) titleFrom(m) else c.title,
        )
    }

    /** Return null from [transform] to remove the message. */
    fun updateMessage(convId: String, msgId: String, transform: (ChatMessage) -> ChatMessage?) = mutate(convId) { c ->
        c.copy(messages = c.messages.mapNotNull { if (it.id == msgId) transform(it) else it })
    }

    fun deleteMessages(convId: String, ids: Set<String>) = mutate(convId) { c -> c.copy(messages = c.messages.filterNot { it.id in ids }) }

    fun setHistoryEnabled(enabled: Boolean) {
        prefs.chatHistoryEnabled = enabled
        if (enabled) schedule() else file.delete()
    }

    fun flush() {
        saveJob?.cancel()
        if (prefs.chatHistoryEnabled) writeFile(_all.value)
    }

    private fun setActive(id: String) { prefs.activeConversationId = id; _activeId.value = id }

    private fun titleFrom(m: ChatMessage): String {
        val t = m.text.trim().replace(Regex("\\s+"), " ")
        return when {
            t.isNotEmpty() -> if (t.length > 36) t.take(36).trimEnd() + "…" else t
            m.attachment != null -> m.attachment.name
            else -> NEW_TITLE
        }
    }

    private fun mutate(id: String, f: (Conversation) -> Conversation) {
        _all.update { list -> list.map { if (it.id == id) f(it) else it } }
        schedule()
    }

    private fun schedule() {
        if (!prefs.chatHistoryEnabled) return
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(600)
            val snapshot = _all.value
            withContext(Dispatchers.IO) { writeFile(snapshot) }
        }
    }

    private fun writeFile(list: List<Conversation>) {
        runCatching {
            val arr = JSONArray()
            list.filter { it.messages.isNotEmpty() }.sortedByDescending { it.updatedAt }.take(MAX_CONVERSATIONS).forEach { c ->
                arr.put(JSONObject().apply {
                    put("id", c.id); put("title", c.title); put("createdAt", c.createdAt); put("updatedAt", c.updatedAt)
                    put("messages", JSONArray().also { ma ->
                        c.messages.forEach { m ->
                            ma.put(JSONObject().apply {
                                put("id", m.id); put("role", m.role.name); put("text", m.text); put("ts", m.timestamp)
                                put("status", m.status.name); put("voice", m.viaVoice)
                                m.attachment?.let { put("attName", it.name); put("attMime", it.mime) }
                                if (m.actions.isNotEmpty()) put("actions", JSONArray().also { aa -> m.actions.forEach { a -> aa.put(JSONObject().put("t", a.tool).put("ok", a.ok).put("s", a.summary)) } })
                            })
                        }
                    })
                })
            }
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
        }
    }

    private fun readFile(): List<Conversation> = runCatching {
        if (!file.exists()) return emptyList()
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ma = o.getJSONArray("messages")
            Conversation(
                o.getString("id"), o.getString("title"), o.getLong("createdAt"), o.getLong("updatedAt"),
                (0 until ma.length()).map { j ->
                    val m = ma.getJSONObject(j)
                    val st = runCatching { MessageStatus.valueOf(m.getString("status")) }.getOrDefault(MessageStatus.OK)
                    ChatMessage(
                        m.getString("id"), ChatRole.valueOf(m.getString("role")), m.getString("text"), m.getLong("ts"),
                        if (st == MessageStatus.STREAMING) MessageStatus.OK else st, m.optBoolean("voice"),
                        if (m.has("attName")) AttachmentInfo(m.getString("attName"), m.optString("attMime")) else null,
                        m.optJSONArray("actions")?.let { aa -> (0 until aa.length()).map { k -> aa.getJSONObject(k).let { x -> ActionRecord(x.optString("t"), x.optBoolean("ok"), x.optString("s")) } } } ?: emptyList(),
                    )
                },
            )
        }
    }.getOrDefault(emptyList())

    companion object {
        const val NEW_TITLE = "New chat"
        private const val MAX_CONVERSATIONS = 100
    }
}
