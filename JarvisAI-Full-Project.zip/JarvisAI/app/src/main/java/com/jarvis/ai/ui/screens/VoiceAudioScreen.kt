package com.jarvis.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.premium.PremiumFeature
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ProBadge
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.jarvisTextFieldColors
import com.jarvis.ai.ui.nav.Routes
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.voice.VoiceProviderId
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

private val geminiVoices = listOf("Kore", "Puck", "Charon", "Fenrir", "Aoede", "Zephyr", "Leda", "Orus")

@Composable
fun VoiceAudioScreen(onBack: () -> Unit, onNavigate: (String) -> Unit, onGate: (PremiumFeature) -> Unit, onOpenApiKey: () -> Unit) {
    val c = LocalContainer.current
    val prefs = c.prefs
    val isPremium by c.premium.isPremium.collectAsState()
    val elevenKey by c.credentials.elevenLabsKey.collectAsState()
    val scope = rememberCoroutineScope()

    var provider by remember { mutableStateOf(runCatching { VoiceProviderId.valueOf(prefs.voiceProvider) }.getOrDefault(VoiceProviderId.ANDROID)) }
    var volume by remember { mutableFloatStateOf(prefs.voiceVolume) }
    var speed by remember { mutableFloatStateOf(prefs.voiceSpeed) }
    var pitch by remember { mutableFloatStateOf(prefs.voicePitch) }
    var gVoice by remember { mutableStateOf(prefs.geminiVoiceName) }
    var eVoice by remember { mutableStateOf(prefs.elevenVoiceId) }
    var continuous by remember { mutableStateOf(prefs.continuousConversation) }
    var testJob by remember { mutableStateOf<Job?>(null) }
    var testNote by remember { mutableStateOf<String?>(null) }

    val effective = c.tts.effectiveProvider()

    fun choose(p: VoiceProviderId) {
        if (p != VoiceProviderId.ANDROID && !isPremium) { onGate(PremiumFeature.VOICE_PACK); return }
        provider = p; prefs.voiceProvider = p.name
        if (p == VoiceProviderId.ELEVENLABS) speed = speed.coerceIn(0.7f, 1.2f).also { prefs.voiceSpeed = it }
    }

    ScreenScaffold("Voice & Audio", "Manage voice, TTS and audio settings", onBack) {
        GlassCard {
            Text("Voice Provider", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            ProviderRow(Icons.Filled.RecordVoiceOver, "Device Voice", "Built-in Android voice. Free, works offline.", provider == VoiceProviderId.ANDROID, false, false) { choose(VoiceProviderId.ANDROID) }
            ProviderRow(Icons.Filled.AutoAwesome, "Gemini Voice", "High-quality AI voices from Gemini.", provider == VoiceProviderId.GEMINI, true, !isPremium) { choose(VoiceProviderId.GEMINI) }
            ProviderRow(Icons.Filled.GraphicEq, "ElevenLabs Voice", "Ultra-realistic voice generation.", provider == VoiceProviderId.ELEVENLABS, true, !isPremium) { choose(VoiceProviderId.ELEVENLABS) }
            if (provider == VoiceProviderId.ELEVENLABS && elevenKey.isBlank() && isPremium) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Add your ElevenLabs API key to use this voice.", color = JarvisColors.Gold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    NeonButton("ADD KEY", onOpenApiKey)
                }
            }
            if (effective != provider) Text("Pro is needed for this voice, so the device voice is used.", color = JarvisColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        if (effective == VoiceProviderId.GEMINI) GlassCard {
            Text("Gemini voice", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                geminiVoices.forEach { v ->
                    val sel = v == gVoice
                    Text(
                        v, color = Color.White, fontSize = 12.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) JarvisColors.Blue else JarvisColors.BgTop)
                            .border(1.dp, if (sel) JarvisColors.Cyan else JarvisColors.Blue.copy(alpha = 0.5f), RoundedCornerShape(50))
                            .clickable { gVoice = v; prefs.geminiVoiceName = v }.padding(horizontal = 14.dp, vertical = 7.dp),
                    )
                }
            }
        }
        if (effective == VoiceProviderId.ELEVENLABS) GlassCard {
            Text("ElevenLabs voice ID", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            OutlinedTextField(
                value = eVoice, onValueChange = { eVoice = it.trim(); prefs.elevenVoiceId = eVoice }, singleLine = true,
                colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            Text("Paste the ID of any voice from your ElevenLabs account. Leave empty for the default voice.", color = JarvisColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }

        // Voice Changer / My Voice (built in Phase 4)
        GlassCard {
            LinkRow(Icons.Filled.GraphicEq, "Voice Changer", "Change your voice style & tone") { if (isPremium) onNavigate(Routes.VOICE_PACK) else onGate(PremiumFeature.VOICE_PACK) }
            Spacer(Modifier.height(8.dp))
            LinkRow(Icons.Filled.Mic, "My Voice", "Upload your voice or choose a sample") { if (isPremium) onNavigate(Routes.VOICE_PACK) else onGate(PremiumFeature.VOICE_PACK) }
        }

        GlassCard {
            Text("Voice Settings", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            LabeledSlider("Volume", "${(volume * 100).toInt()}%", volume, 0f..1f) { volume = it; prefs.voiceVolume = it }
            if (effective == VoiceProviderId.ANDROID || effective == VoiceProviderId.ELEVENLABS) {
                val range = if (effective == VoiceProviderId.ELEVENLABS) 0.7f..1.2f else 0.5f..2f
                LabeledSlider("Speed", "%.1fx".format(speed.coerceIn(range)), speed.coerceIn(range), range) { speed = it; prefs.voiceSpeed = it }
            }
            if (effective == VoiceProviderId.ANDROID) {
                LabeledSlider("Pitch", "${((pitch - 1f) * 100).toInt()}%", pitch, 0.5f..2f) { pitch = it; prefs.voicePitch = it }
            }
            Text("Only the controls supported by the active voice are shown.", color = JarvisColors.TextDim, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            NeonButton(
                if (testJob?.isActive == true) "Stop" else "Test Voice",
                {
                    if (testJob?.isActive == true) { testJob?.cancel(); c.tts.stop() }
                    else {
                        c.voiceController.interruptAll(); testNote = null
                        testJob = scope.launch {
                            try { testNote = c.tts.speak("Hello, I'm Jarvis. This is how I sound.") { }.note }
                            catch (e: CancellationException) { throw e }
                            catch (e: Exception) { testNote = "Couldn't play the voice on this device." }
                        }
                    }
                },
                Modifier.fillMaxWidth(), icon = if (testJob?.isActive == true) Icons.Filled.Stop else Icons.Filled.PlayArrow,
            )
            testNote?.let { Text(it, color = JarvisColors.Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        }

        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlowIcon(Icons.Filled.VolumeUp, JarvisColors.Cyan, size = 40.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Keep listening after replies", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("JARVIS listens again when it finishes speaking, until you say nothing or tap STOP.", color = JarvisColors.TextDim, fontSize = 11.sp)
                }
                Switch(
                    continuous, { continuous = it; prefs.continuousConversation = it },
                    colors = SwitchDefaults.colors(checkedTrackColor = JarvisColors.Blue, checkedThumbColor = Color.White),
                )
            }
        }
    }
}

@Composable
private fun ProviderRow(icon: ImageVector, title: String, subtitle: String, selected: Boolean, pro: Boolean, locked: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(role = Role.RadioButton, onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlowIcon(icon, JarvisColors.Neon, size = 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
        }
        if (pro) { ProBadge(locked = locked); Spacer(Modifier.width(8.dp)) }
        Box(Modifier.size(20.dp).clip(CircleShape).border(2.dp, if (selected) JarvisColors.Cyan else JarvisColors.TextDim, CircleShape).padding(4.dp).background(if (selected) JarvisColors.Cyan else Color.Transparent, CircleShape))
    }
}

@Composable
private fun LinkRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(role = Role.Button, onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        GlowIcon(icon, JarvisColors.Purple, size = 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim)
    }
}

@Composable
private fun LabeledSlider(label: String, value: String, current: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Row {
            Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(value, color = JarvisColors.Cyan, fontSize = 13.sp)
        }
        Slider(
            current, onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = JarvisColors.Cyan, activeTrackColor = JarvisColors.Blue, inactiveTrackColor = JarvisColors.Card),
        )
    }
}
