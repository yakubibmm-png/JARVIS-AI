package com.jarvis.ai.command

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Offline / no-key fallback ONLY. It understands generic English patterns (a verb + whatever name follows), never a
 * list of specific apps. Normal operation uses Gemini tool calling, which handles any wording and language.
 */
class LocalIntentParser : CommandUnderstanding {
    private val lead = "^(?:(?:hey |ok |okay )?jarvis[, ]*)?(?:(?:please|can you|could you|would you|will you)[, ]*)*"
    private val tail = "(?:\\s+(?:please|for me|now))*[.!?]*$"
    private fun rx(body: String) = Regex(lead + body + tail, RegexOption.IGNORE_CASE)

    private val open = rx("(?:open|launch|start|run|go to|take me to)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?")
    private val install = rx("(?:install|download|get)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?")
    private val time = rx("(?:what(?:'s| is)? the time|what time is it|tell me the time|current time)(?: now)?")
    private val alarm = rx("(?:set|create|make)\\s+(?:an?\\s+)?alarm\\s+(?:for|at)\\s+(.+)")
    private val remindIn = rx("remind me\\s+(?:to|about)\\s+(.+?)\\s+in\\s+(\\d+)\\s*(minutes?|mins?|hours?|hrs?)")
    private val remindAt = rx("remind me\\s+(?:to|about)\\s+(.+?)\\s+at\\s+(\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)?)")
    private val weather = rx("(?:what(?:'s| is)? the weather|weather|will it rain|how(?:'s| is) the weather)(?:\\s+(?:today|now|like))?(?:\\s+in\\s+(.+))?")
    private val play = rx("play\\s+(.+)")
    private val search = rx("(?:search(?: the web)?(?: for)?|google|look up)\\s+(.+)")

    override suspend fun parse(utterance: String): ParsedCommand {
        val u = utterance.trim()
        search.matchEntire(u)?.let { return ParsedCommand(JarvisIntent.SEARCH, query = it.groupValues[1].trim(), confidence = 0.7f) }
        time.matchEntire(u)?.let { return ParsedCommand(JarvisIntent.GET_TIME, confidence = 0.9f) }
        weather.matchEntire(u)?.let { return ParsedCommand(JarvisIntent.GET_WEATHER, query = it.groupValues[1].ifBlank { null }, confidence = 0.8f) }
        alarm.matchEntire(u)?.let { m -> clock(m.groupValues[1])?.let { return ParsedCommand(JarvisIntent.SET_ALARM, time = it, confidence = 0.8f) } }
        remindIn.matchEntire(u)?.let { m ->
            val n = m.groupValues[2].toInt(); val mins = if (m.groupValues[3].lowercase().startsWith("h")) n * 60 else n
            return ParsedCommand(JarvisIntent.SET_REMINDER, text = m.groupValues[1].trim(), time = "in:$mins", confidence = 0.8f)
        }
        remindAt.matchEntire(u)?.let { m ->
            val hm = clock(m.groupValues[2])?.split(":") ?: return@let
            var at = LocalDateTime.now().withHour(hm[0].toInt()).withMinute(hm[1].toInt()).withSecond(0).withNano(0)
            if (!at.isAfter(LocalDateTime.now())) at = at.plusDays(1)
            return ParsedCommand(JarvisIntent.SET_REMINDER, text = m.groupValues[1].trim(), time = at.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME), confidence = 0.8f)
        }
        play.matchEntire(u)?.let { return ParsedCommand(JarvisIntent.PLAY_MEDIA, query = it.groupValues[1].trim(), confidence = 0.6f) }
        install.matchEntire(u)?.let { return ParsedCommand(JarvisIntent.INSTALL_APP, app = it.groupValues[1].trim(), confidence = 0.7f) }
        open.matchEntire(u)?.let { return ParsedCommand(JarvisIntent.OPEN_APP, app = it.groupValues[1].trim(), confidence = 0.7f) }
        return ParsedCommand(JarvisIntent.UNKNOWN)
    }

    /** "6 am", "6:30 pm", "18:00" -> "HH:mm", or null. */
    private fun clock(text: String): String? {
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE).find(text.trim().lowercase(Locale.ENGLISH)) ?: return null
        var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        when (m.groupValues[3]) { "pm" -> if (h < 12) h += 12; "am" -> if (h == 12) h = 0 }
        if (h !in 0..23 || min !in 0..59) return null
        return "%02d:%02d".format(h, min)
    }
}
