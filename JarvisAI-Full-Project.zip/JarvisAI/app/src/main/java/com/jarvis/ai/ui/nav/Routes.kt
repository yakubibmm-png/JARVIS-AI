package com.jarvis.ai.ui.nav

import com.jarvis.ai.premium.PremiumFeature

object Routes {
    const val ONBOARDING = "onboarding"

    // Bottom navigation (top-level)
    const val HOME = "home"
    const val TOOLS = "tools"
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val PRO = "pro"

    // Home
    const val API_KEY = "api_key"
    const val QUICK_ACTIONS = "quick_actions"
    const val REMINDERS = "reminders"
    const val MUSIC = "music"
    const val WEATHER = "weather"

    // Tools
    const val VOICE_PACK = "voice_pack"
    const val SUPER_AI = "super_ai"
    const val PREFERENCES = "preferences"
    const val PERSONALIZATION = "personalization"
    const val PERMISSIONS = "permissions"
    const val AUTOMATION = "automation"
    const val MORE_FEATURES = "more_features"

    // Settings sub-pages
    const val SETTINGS_VOICE = "settings_voice"
    const val SETTINGS_NOTIFICATIONS = "settings_notifications"
    const val SETTINGS_PRIVACY = "settings_privacy"
    const val SETTINGS_APPEARANCE = "settings_appearance"
    const val SETTINGS_ABOUT = "settings_about"

    // Automation modules
    const val AUTO_REPLY = "auto_reply"
    const val AUTO_LAUNCH = "auto_launch"
    const val AUTO_TASKS = "auto_tasks"
    const val AUTO_TRIGGERS = "auto_triggers"
    const val AUTO_ACTIONS = "auto_actions"
    const val ALIASES = "aliases"

    const val GATE_PATTERN = "gate/{feature}"
    fun gate(f: PremiumFeature) = "gate/${f.name}"

    val topLevel = setOf(HOME, TOOLS, CHAT, SETTINGS, PRO)
}
