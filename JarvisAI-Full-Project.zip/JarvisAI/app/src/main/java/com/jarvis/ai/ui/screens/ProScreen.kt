package com.jarvis.ai.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AllInclusive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.jarvis.ai.R
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.premium.LicenseResult
import com.jarvis.ai.premium.PremiumRepository
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.JarvisBackground
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.jarvisTextFieldColors
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.util.Links
import com.jarvis.ai.util.openTelegram
import kotlinx.coroutines.launch
import android.widget.Toast

class ProViewModel(private val premium: PremiumRepository) : ViewModel() {
    var input by mutableStateOf(""); private set
    var busy by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var showSuccess by mutableStateOf(false); private set

    fun onInput(v: String) { input = v; error = null }
    fun dismissSuccess() { showSuccess = false }

    fun unlock() {
        if (busy) return
        busy = true; error = null
        viewModelScope.launch {
            when (val r = premium.unlock(input)) {
                LicenseResult.Valid -> { showSuccess = true; input = "" }
                is LicenseResult.Invalid -> error = r.message
                is LicenseResult.TooManyAttempts -> error = "Too many attempts. Try again in ${r.seconds}s."
            }
            busy = false
        }
    }
}

private data class Perk(val icon: ImageVector, val tint: Color, val title: String, val body: String)

private val perks = listOf(
    Perk(Icons.Filled.SmartToy, JarvisColors.Purple, "All Premium Features", "Voice packs, automation, personalization and more."),
    Perk(Icons.Filled.AllInclusive, JarvisColors.Success, "Unlimited Usage", "Use features without Pro-tier limits."),
    Perk(Icons.Filled.Bolt, JarvisColors.Magenta, "Advanced AI Models", "Access advanced Gemini models for smarter results."),
    Perk(Icons.Filled.Mic, JarvisColors.Neon, "Premium Voices", "Gemini, ElevenLabs and custom voice packs."),
    Perk(Icons.Filled.Settings, JarvisColors.Gold, "Automation & Tools", "Automation, app control, screen share and more."),
    Perk(Icons.Filled.SupportAgent, JarvisColors.Purple, "Priority Support", "Faster help whenever you need it."),
)

private val steps = listOf(
    "Open Telegram", "Contact the seller/admin", "Purchase / receive the Premium Key",
    "Return to JARVIS AI", "Enter the key below", "Unlock Premium",
)

@Composable
fun ProScreen(onStartExploring: () -> Unit) {
    val c = LocalContainer.current
    val vm: ProViewModel = viewModel(factory = viewModelFactory { initializer { ProViewModel(c.premium) } })
    val isPremium by c.premium.isPremium.collectAsState()
    val ctx = LocalContext.current
    var showKey by remember { mutableStateOf(false) }

    ScreenScaffold("JARVIS AI", "Unlock Full Potential") {
        // Hero
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.TopCenter) {
                    Image(
                        painterResource(R.drawable.jarvis_logo), "JARVIS AI logo",
                        Modifier.padding(top = 14.dp).size(92.dp).clip(CircleShape).border(2.dp, JarvisColors.Cyan, CircleShape),
                    )
                    Icon(Icons.Filled.WorkspacePremium, null, tint = JarvisColors.Gold, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("PREMIUM", color = JarvisColors.Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(
                        buildAnnotatedString {
                            append("Upgrade to ")
                            withStyle(SpanStyle(color = JarvisColors.Magenta)) { append("Pro") }
                        },
                        color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                    )
                    Text("Unlock the full power of JARVIS AI.", color = JarvisColors.Cyan, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Chip(Icons.Filled.Bolt, "More Power"); Chip(Icons.Filled.Shield, "More Control"); Chip(Icons.Filled.Star, "Better Experience")
            }
        }

        if (isPremium) {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(Icons.Filled.WorkspacePremium, JarvisColors.Gold)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("PRO is active", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("All premium features are available.", color = JarvisColors.TextDim, fontSize = 13.sp)
                    }
                }
            }
        }

        // What you get
        GlassCard {
            Text("What You Get with Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(10.dp))
            perks.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { p ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(JarvisColors.BgTop.copy(alpha = 0.7f))
                                .border(1.dp, p.tint.copy(alpha = 0.5f), RoundedCornerShape(14.dp)).padding(10.dp),
                        ) {
                            GlowIcon(p.icon, p.tint, size = 34.dp)
                            Spacer(Modifier.height(6.dp))
                            Text(p.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(p.body, color = JarvisColors.TextDim, fontSize = 11.sp)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        if (!isPremium) {
            // How to get the key
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(Icons.Filled.Key, JarvisColors.Cyan, size = 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("How to Get Your Pro Key", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Contact @${Links.TELEGRAM_USERNAME} on Telegram to get your Premium Key.", color = JarvisColors.TextDim, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                steps.forEachIndexed { i, s ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                        Box(Modifier.size(22.dp).clip(CircleShape).background(JarvisColors.Blue), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(s, color = Color.White, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                NeonButton(
                    "Open Telegram", {
                        if (!ctx.openTelegram()) Toast.makeText(ctx, "Couldn't open Telegram or a browser.", Toast.LENGTH_SHORT).show()
                    },
                    Modifier.fillMaxWidth(), icon = Icons.AutoMirrored.Filled.Send,
                )
            }

            // Enter key
            GlassCard {
                Text("Enter Your Premium Key", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Enter the key you received to unlock all features.", color = JarvisColors.TextDim, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = vm.input, onValueChange = vm::onInput, singleLine = true,
                    placeholder = { Text("Enter your premium key") },
                    leadingIcon = { Icon(Icons.Filled.Key, null, tint = JarvisColors.TextDim) },
                    trailingIcon = {
                        IconButton({ showKey = !showKey }) {
                            Icon(if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, if (showKey) "Hide key" else "Show key", tint = JarvisColors.TextDim)
                        }
                    },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    isError = vm.error != null, colors = jarvisTextFieldColors(),
                    shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth(),
                )
                vm.error?.let { Text(it, color = JarvisColors.Danger, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
                Spacer(Modifier.height(10.dp))
                NeonButton(
                    if (vm.busy) "Checking…" else "Unlock", vm::unlock, Modifier.fillMaxWidth(),
                    icon = Icons.Filled.Lock, enabled = !vm.busy && vm.input.isNotBlank(),
                    colors = listOf(JarvisColors.Purple, JarvisColors.Blue),
                )
                Spacer(Modifier.height(6.dp))
                Text("Your key is checked on this device and the Pro status is kept in encrypted storage.", color = JarvisColors.TextDim, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (vm.showSuccess) {
        Dialog(
            onDismissRequest = vm::dismissSuccess,
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
        ) {
            JarvisBackground {
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Filled.WorkspacePremium, null, tint = JarvisColors.Gold, modifier = Modifier.size(72.dp))
                    Text("PRO", color = JarvisColors.Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("You're All Set!", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("All premium features are now unlocked.", color = JarvisColors.Cyan, fontSize = 14.sp)
                    Spacer(Modifier.height(20.dp))
                    GlassCard(Modifier.fillMaxWidth()) {
                        listOf(
                            "Premium Features Unlocked", "Premium Voice Pack", "Advanced Personalization",
                            "Automation", "Screen Share", "Additional AI Tools",
                        ).forEach {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                                Icon(Icons.Filled.Check, null, tint = JarvisColors.Success, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(10.dp))
                                Text(it, color = Color.White, fontSize = 14.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    NeonButton("Start Exploring", { vm.dismissSuccess(); onStartExploring() }, Modifier.fillMaxWidth(), icon = Icons.Filled.AutoAwesome)
                }
            }
        }
    }
}

@Composable
private fun Chip(icon: ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = JarvisColors.Cyan, modifier = Modifier.size(22.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}
