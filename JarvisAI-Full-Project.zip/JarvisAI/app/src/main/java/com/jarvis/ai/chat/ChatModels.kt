package com.jarvis.ai.chat

import com.jarvis.ai.command.ActionRecord

enum class ChatRole { USER, ASSISTANT }
enum class MessageStatus { OK, STREAMING, ERROR, CANCELLED }

data class AttachmentInfo(val name: String, val mime: String)

data class ChatMessage(
    val id: String,
    val role: ChatRole,
    val text: String,
    val timestamp: Long,
    val status: MessageStatus = MessageStatus.OK,
    val viaVoice: Boolean = false,
    val attachment: AttachmentInfo? = null,
    val actions: List<ActionRecord> = emptyList(),
)

data class Conversation(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val messages: List<ChatMessage>,
)
