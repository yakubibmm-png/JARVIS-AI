package com.jarvis.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.premium.PremiumFeature
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ProBadge
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.theme.JarvisColors

/** Shown when a free user taps any Premium feature: name, why it is Premium, benefits, Unlock Pro. */
@Composable
fun PremiumGateScreen(feature: PremiumFeature, onUnlock: () -> Unit, onBack: () -> Unit) {
    ScreenScaffold("Premium Feature", "Unlock with a Pro key", onBack) {
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlowIcon(Icons.Filled.WorkspacePremium, JarvisColors.Gold, size = 52.dp)
                Spacer(Modifier.width(12.dp))
                Text(feature.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                ProBadge(locked = true)
            }
            Spacer(Modifier.height(12.dp))
            Text("Why it's Premium", color = JarvisColors.Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(feature.why, color = JarvisColors.TextDim, fontSize = 13.sp)
        }
        GlassCard {
            Text("What you get", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            feature.benefits.forEach {
                Row(horizontalArrangement = Arrangement.Start) {
                    Icon(Icons.Filled.Check, null, tint = JarvisColors.Success, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(it, color = Color.White, fontSize = 13.sp)
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        NeonButton("Unlock Pro", onUnlock, Modifier.fillMaxWidth(), icon = Icons.Filled.WorkspacePremium)
    }
}
