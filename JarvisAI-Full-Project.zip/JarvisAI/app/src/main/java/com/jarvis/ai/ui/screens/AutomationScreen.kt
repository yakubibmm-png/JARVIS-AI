package com.jarvis.ai.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.jarvis.ai.automation.AssistantService
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.screen.JarvisAccessibilityService
import com.jarvis.ai.ui.components.Disclosure
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.SectionTitle
import com.jarvis.ai.ui.components.StatusText
import com.jarvis.ai.ui.components.SwitchRow
import com.jarvis.ai.ui.components.rememberResumeTick
import com.jarvis.ai.ui.nav.Routes
import com.jarvis.ai.ui.theme.JarvisColors

private enum class Ask { ACCESSIBILITY, NOTIFICATION, SCREEN_SHARE }

const val ACCESSIBILITY_DISCLOSURE = "JARVIS will use Android's Accessibility Service to read what is on your screen and to tap, scroll or type, ONLY when you ask it to by voice or text, and only while you have Pro and Automation switched ON.\n\n• It never reads password fields.\n• It does not store or upload screen content. Text or a screenshot is sent to Gemini only when you ask a question about the screen.\n• It never sends a message, pays or deletes anything without your confirmation.\n• You can turn it off at any time in Android settings.\n\nOn some phones you must first open App info → ⋮ → \"Allow restricted settings\"."
const val NOTIFICATION_DISCLOSURE = "JARVIS will read incoming WhatsApp message notifications so it can send the auto-reply you set up. Other apps' notifications are ignored.\n\n• It acts only while Auto Reply is ON, and never in groups unless you allow it.\n• Nothing is stored except a short log of the replies on this phone.\n• In AI mode the message text is sent to Gemini to write the reply.\n• Turn it off any time with the Auto Reply switch or in Android settings.\n\nOn some phones you must first open App info → ⋮ → \"Allow restricted settings\"."

@Composable
fun AutomationScreen(onBack: () -> Unit, onNavigate: (String) -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val enabled by c.automation.enabled.collectAsState()
    val autoReply by c.automation.autoReplyEnabled.collectAsState()
    val sharing by c.screenShare.active.collectAsState()
    val a11y by JarvisAccessibilityService.connected.collectAsState()
    val tick = rememberResumeTick()
    val notifAccess = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    val notifOn = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    var background by remember { mutableStateOf(c.prefs.backgroundAssistant) }
    var spoken by remember { mutableStateOf(c.prefs.spokenReminders) }
    var voiceNotif by remember { mutableStateOf(c.prefs.voiceNotifications) }
    var ask by remember { mutableStateOf<Ask?>(null) }

    val shareLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == Activity.RESULT_OK && data != null) c.screenShare.start(r.resultCode, data)
        else Toast.makeText(ctx, "Screen Share wasn't allowed.", Toast.LENGTH_SHORT).show()
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun startBackground() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        c.prefs.backgroundAssistant = true; background = true
        try { AssistantService.start(ctx) } catch (e: Exception) { Toast.makeText(ctx, "Android didn't allow the background assistant to start.", Toast.LENGTH_LONG).show(); c.prefs.backgroundAssistant = false; background = false }
    }

    ScreenScaffold("Automation", "Smart automation & quick actions", onBack) {
        GlassCard {
            SwitchRow(if (enabled) "Automation is ON" else "Automation is OFF", "Master switch. While OFF, Auto Reply, tasks, triggers and screen control do nothing.", enabled) { on ->
                c.automation.setEnabled(on)
                if (!on) c.screenShare.stop()
            }
        }

        GlassCard {
            SectionTitle("What JARVIS needs", "Each item is optional and only used for the feature that needs it.")
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Accessibility Service", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text("Screen reading, tap, scroll, type", color = JarvisColors.TextDim, fontSize = 12.sp) }
                StatusText(a11y); Spacer(Modifier.width(8.dp))
                NeonButton(if (a11y) "Manage" else "Enable", { ask = Ask.ACCESSIBILITY }, filled = !a11y)
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Notification Access", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text("WhatsApp Auto Reply", color = JarvisColors.TextDim, fontSize = 12.sp) }
                StatusText(notifAccess); Spacer(Modifier.width(8.dp))
                NeonButton(if (notifAccess) "Manage" else "Enable", { ask = Ask.NOTIFICATION }, filled = !notifAccess)
            }
            Spacer(Modifier.height(10.dp))
            SwitchRow("Screen Share", if (sharing) "Sharing. JARVIS looks at the screen only when you ask about it. A notification stays visible." else "Lets JARVIS see the screen to answer \"What am I looking at?\". Android asks for your permission each time.", sharing, enabled = enabled) { on ->
                if (on) ask = Ask.SCREEN_SHARE else c.screenShare.stop()
            }
            if (!enabled) Text("Turn Automation ON to use Screen Share.", color = JarvisColors.Gold, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            SwitchRow("Background assistant", "Shows a notification (\"JARVIS is active\") and keeps reminders, voice notifications and smart triggers working. It never listens to the microphone in the background.", background) { on ->
                if (on) startBackground() else { c.prefs.backgroundAssistant = false; background = false; AssistantService.stop(ctx) }
            }
            if (background && !notifOn) Text("Notifications are off, so you won't see the status notification. Turn them on in Permissions.", color = JarvisColors.Gold, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            SwitchRow("Spoken reminders", "JARVIS says your reminders aloud when they go off.", spoken) { spoken = it; c.prefs.spokenReminders = it }
            Spacer(Modifier.height(10.dp))
            SwitchRow("Voice notifications", "JARVIS speaks short updates, such as finished installs and automation results.", voiceNotif) { voiceNotif = it; c.prefs.voiceNotifications = it }
        }

        Module("Auto Reply", "Reply to WhatsApp messages automatically", Icons.Filled.Chat, JarvisColors.Success, if (autoReply) "ON" else "OFF") { onNavigate(Routes.AUTO_REPLY) }
        Module("App Launch", "Open apps with voice or at a set time", Icons.Filled.Apps, JarvisColors.Blue, null) { onNavigate(Routes.AUTO_LAUNCH) }
        Module("Task Scheduler", "Run your own commands at set times", Icons.Filled.Schedule, JarvisColors.Gold, null) { onNavigate(Routes.AUTO_TASKS) }
        Module("Smart Triggers", "Run commands when the charger, headphones or Wi-Fi change", Icons.Filled.SmartToy, JarvisColors.Magenta, null) { onNavigate(Routes.AUTO_TRIGGERS) }
        Module("Custom Actions", "Your own named shortcuts, like \"Good morning\"", Icons.Filled.PlaylistPlay, JarvisColors.Purple, null) { onNavigate(Routes.AUTO_ACTIONS) }
        Module("Contact Shortcuts", "Say \"Message 72\" for a saved contact", Icons.Filled.ContactPhone, JarvisColors.Cyan, null) { onNavigate(Routes.ALIASES) }

        NeonButton("Turn everything OFF", {
            c.automation.setEnabled(false); c.automation.setAutoReply(false); c.screenShare.stop()
            c.prefs.backgroundAssistant = false; background = false; AssistantService.stop(ctx)
            Toast.makeText(ctx, "All automation is off", Toast.LENGTH_SHORT).show()
        }, Modifier.fillMaxWidth(), filled = false, colors = listOf(Color(0xFFB91C1C), Color(0xFFEF4444)))
    }

    when (ask) {
        Ask.ACCESSIBILITY -> Disclosure("Accessibility Service", ACCESSIBILITY_DISCLOSURE, "Open settings", { ask = null; ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, { ask = null })
        Ask.NOTIFICATION -> Disclosure("Notification Access", NOTIFICATION_DISCLOSURE, "Open settings", { ask = null; ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, { ask = null })
        Ask.SCREEN_SHARE -> Disclosure("Share your screen with JARVIS?", "Android will ask for your permission. While sharing, a notification stays visible. JARVIS captures the screen only when you ask a question about it, uses the picture to answer, and does not save it. Pro and Automation must be ON.", "Continue", { ask = null; shareLauncher.launch(c.screenShare.consentIntent()) }, { ask = null })
        null -> Unit
    }
}

@Composable
private fun Module(title: String, subtitle: String, icon: ImageVector, tint: Color, status: String?, onClick: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlowIcon(icon, tint, size = 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
            }
            if (status != null) { StatusText(status == "ON"); Spacer(Modifier.width(6.dp)) }
            Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim, modifier = Modifier.size(20.dp))
        }
    }
}
