package com.jarvis.ai.util

import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min

/** Name matching used for apps and contacts: tolerant of case, accents, spacing and speech-recognition slips. */
object TextMatch {
    private val marks = Regex("\\p{Mn}+")
    private val nonAlnum = Regex("[^\\p{L}\\p{N}]+")

    fun strip(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFD).replace(marks, "").lowercase()
    fun norm(s: String): String = strip(s).replace(nonAlnum, "")
    fun tokens(s: String): List<String> = strip(s).split(nonAlnum).filter { it.isNotEmpty() }

    /** 0..100. 100 = same name. ≥70 = a plausible match. */
    fun score(query: String, target: String): Int {
        val q = norm(query); val t = norm(target)
        if (q.isEmpty() || t.isEmpty()) return 0
        if (q == t) return 100
        var best = 0
        if (q.length >= 3 && t.startsWith(q)) best = max(best, 90 - min(12, t.length - q.length))
        if (t.length >= 3 && q.startsWith(t)) best = max(best, 82)
        if (q.length >= 4 && t.contains(q)) best = max(best, 74)
        val qt = tokens(query); val tt = tokens(target)
        if (qt.isNotEmpty() && qt.all { it in tt }) best = max(best, if (qt.size == tt.size) 98 else 80 - min(8, tt.size - qt.size))
        if (qt.isNotEmpty() && tt.isNotEmpty() && qt.size == 1 && tt.any { it.startsWith(qt[0]) && qt[0].length >= 3 }) best = max(best, 78)
        val jw = jaroWinkler(q, t)
        if (jw >= 0.88) best = max(best, (jw * 100).toInt() - 6)
        return best.coerceIn(0, 99)
    }

    fun jaroWinkler(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val range = max(0, max(a.length, b.length) / 2 - 1)
        val am = BooleanArray(a.length); val bm = BooleanArray(b.length)
        var matches = 0
        for (i in a.indices) {
            val lo = max(0, i - range); val hi = min(b.length - 1, i + range)
            for (j in lo..hi) if (!bm[j] && a[i] == b[j]) { am[i] = true; bm[j] = true; matches++; break }
        }
        if (matches == 0) return 0.0
        var k = 0; var trans = 0
        for (i in a.indices) if (am[i]) { while (!bm[k]) k++; if (a[i] != b[k]) trans++; k++ }
        val m = matches.toDouble()
        val jaro = (m / a.length + m / b.length + (m - trans / 2.0) / m) / 3.0
        var prefix = 0
        while (prefix < min(4, min(a.length, b.length)) && a[prefix] == b[prefix]) prefix++
        return jaro + prefix * 0.1 * (1 - jaro)
    }
}
