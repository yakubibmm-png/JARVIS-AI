package com.jarvis.ai.voice

import android.content.Context
import com.jarvis.ai.util.isOnline
import com.jarvis.ai.util.withConnection
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

/** ElevenLabs streaming speech (raw 24 kHz PCM, so the waveform can follow the real audio). */
class ElevenLabsTts(private val ctx: Context) {
    suspend fun streamInto(player: PcmPlayer, text: String, apiKey: String, voiceId: String, speed: Float) {
        if (!ctx.isOnline()) throw VoiceProviderException("You're offline. This feature needs an internet connection.")
        val voice = URLEncoder.encode(voiceId, "UTF-8")
        val settings = JSONObject().put("stability", 0.5).put("similarity_boost", 0.75)
        if (speed != 1f) settings.put("speed", speed.coerceIn(0.7f, 1.2f).toDouble())
        val body = JSONObject().put("text", text).put("model_id", MODEL).put("voice_settings", settings).toString().toByteArray(Charsets.UTF_8)
        try {
            withConnection("$BASE/text-to-speech/$voice/stream?output_format=pcm_24000", { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 30_000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("xi-api-key", apiKey)
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) {
                    c.errorStream?.close()
                    throw VoiceProviderException(
                        when (code) {
                            401 -> "ElevenLabs rejected your API key."
                            402, 403 -> "Your ElevenLabs plan doesn't allow this voice or request."
                            404, 422 -> "That ElevenLabs voice ID isn't valid."
                            429 -> "ElevenLabs is rate-limiting requests."
                            else -> "ElevenLabs voice is unavailable right now."
                        },
                    )
                }
                val buf = ByteArray(4096)
                c.inputStream.use { input ->
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n > 0) player.write(buf, n)
                    }
                }
            }
        } catch (e: IOException) {
            throw VoiceProviderException("ElevenLabs couldn't be reached.")
        }
    }

    private companion object {
        const val BASE = "https://api.elevenlabs.io/v1"
        const val MODEL = "eleven_flash_v2_5"
    }
}
