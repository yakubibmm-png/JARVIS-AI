package com.jarvis.ai.ai

import android.content.Context
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.data.CredentialsRepository
import com.jarvis.ai.data.SecureStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withTimeout

enum class SuperProvider(val title: String, val subtitle: String, val defaultBase: String, val path: String) {
    GEMINI("Gemini AI", "Google's AI. Built in: powers JARVIS voice, chat and phone control.", "", ""),
    OPENAI("ChatGPT", "OpenAI chat models", "https://api.openai.com/v1", "/chat/completions"),
    ANTHROPIC("Claude", "Anthropic's AI assistant", "https://api.anthropic.com", "/v1/messages"),
    PERPLEXITY("Perplexity", "Answers with live web search", "https://api.perplexity.ai", "/chat/completions"),
    XAI("Grok", "xAI chat models", "https://api.x.ai/v1", "/chat/completions"),
    CUSTOM("Custom AI", "Any OpenAI-compatible service (enter its address)", "", "/chat/completions"),
}

/**
 * A provider is only usable once its key and model are saved, and only shown as Verified after a real test request
 * succeeded. Model IDs are entered by the user (never guessed). Phone control (tools) works with Gemini only.
 */
class SuperAiRepository(private val ctx: Context, private val prefs: AppPrefs, private val secure: SecureStore, private val creds: CredentialsRepository) {
    private val _active = MutableStateFlow(prefs.activeProvider)
    val active: StateFlow<String> = _active.asStateFlow()
    private val _version = MutableStateFlow(0)
    /** Bumps whenever any provider setting changes (so the UI refreshes). */
    val version: StateFlow<Int> = _version.asStateFlow()

    fun key(p: SuperProvider) = secure.getString("superai_key_${p.name}")
    fun setKey(p: SuperProvider, v: String) { val t = v.trim(); if (t.isEmpty()) secure.remove("superai_key_${p.name}") else secure.putString("superai_key_${p.name}", t); reset(p) }
    fun model(p: SuperProvider) = prefs.getStr("superai_model_${p.name}")
    fun setModel(p: SuperProvider, v: String) { prefs.putStr("superai_model_${p.name}", v.trim()); reset(p) }
    fun base(p: SuperProvider) = prefs.getStr("superai_base_${p.name}", p.defaultBase)
    fun setBase(p: SuperProvider, v: String) { prefs.putStr("superai_base_${p.name}", v.trim()); reset(p) }

    /** "", "ok" or "fail:<reason>" */
    fun status(p: SuperProvider) = prefs.getStr("superai_status_${p.name}")
    private fun reset(p: SuperProvider) { prefs.putStr("superai_status_${p.name}", ""); _version.value++ }

    fun isConfigured(p: SuperProvider): Boolean = when (p) {
        SuperProvider.GEMINI -> creds.hasGeminiKey
        SuperProvider.CUSTOM -> key(p).isNotBlank() && model(p).isNotBlank() && base(p).isNotBlank()
        else -> key(p).isNotBlank() && model(p).isNotBlank()
    }

    fun setActive(p: SuperProvider): Boolean {
        if (!isConfigured(p)) return false
        prefs.activeProvider = p.name; _active.value = p.name; _version.value++; return true
    }

    /** The provider actually used: the chosen one if it is configured, otherwise Gemini. */
    fun effective(): SuperProvider = runCatching { SuperProvider.valueOf(_active.value) }.getOrDefault(SuperProvider.GEMINI)
        .takeIf { it == SuperProvider.GEMINI || isConfigured(it) } ?: SuperProvider.GEMINI

    fun build(p: SuperProvider): AiProvider? = when (p) {
        SuperProvider.GEMINI -> null
        SuperProvider.ANTHROPIC -> AnthropicProvider(ctx, { base(p) }, { key(p) }, { model(p) })
        else -> OpenAiCompatProvider(p.name.lowercase(), p.title, ctx, { base(p) }, p.path, { key(p) }, { model(p) })
    }

    /** A tiny real request. Returns null when it works, or the reason it failed. */
    suspend fun verify(p: SuperProvider): String? {
        val provider = build(p) ?: return null
        val result = try {
            withTimeout(30_000) { provider.reply(listOf(ChatTurn(ChatTurn.Role.USER, "Reply with the single word OK.")), "You are a connectivity test.", AiOptions("", false)) }
            null
        } catch (e: AiException) { e.userMessage } catch (e: Exception) { "The test request failed." }
        prefs.putStr("superai_status_${p.name}", if (result == null) "ok" else "fail:$result")
        _version.value++
        return result
    }
}

/** Chat/voice talk to this router; it picks Gemini (with phone tools) or the provider chosen on the Super AI page. */
class SuperAiRouter(private val gemini: GeminiClient, private val repo: SuperAiRepository) : AiProvider {
    override val id = "router"
    private fun current(): Pair<SuperProvider, AiProvider> {
        val p = repo.effective()
        return p to (repo.build(p) ?: gemini)
    }
    override val supportsTools: Boolean get() = repo.effective() == SuperProvider.GEMINI
    override suspend fun isConfigured() = current().second.isConfigured()
    override fun events(history: List<ChatTurn>, systemPrompt: String, options: AiOptions): Flow<AiEvent> = current().second.events(history, systemPrompt, options)
}
