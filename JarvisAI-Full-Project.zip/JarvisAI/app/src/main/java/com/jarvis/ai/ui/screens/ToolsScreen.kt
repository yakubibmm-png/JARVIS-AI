package com.jarvis.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.premium.PremiumFeature
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.ProBadge
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.jarvisTextFieldColors
import com.jarvis.ai.ui.nav.Routes
import com.jarvis.ai.ui.theme.JarvisColors

private data class Tool(val title: String, val subtitle: String, val icon: ImageVector, val tint: Color, val route: String, val feature: PremiumFeature?)

private val tools = listOf(
    Tool("Voice Pack", "Custom voices, voice changer & more", Icons.Filled.Mic, JarvisColors.Blue, Routes.VOICE_PACK, PremiumFeature.VOICE_PACK),
    Tool("Super AI", "Advanced AI models & providers", Icons.Filled.AutoAwesome, JarvisColors.Cyan, Routes.SUPER_AI, PremiumFeature.SUPER_AI),
    Tool("Preferences", "Voice brain, language, mode & settings", Icons.Filled.Tune, Color(0xFF14B8A6), Routes.PREFERENCES, PremiumFeature.PREFERENCES),
    Tool("Personalization", "Set your name, AI name & custom options", Icons.Filled.Person, JarvisColors.Magenta, Routes.PERSONALIZATION, PremiumFeature.PERSONALIZATION),
    Tool("Permissions", "Allow access for full functionality", Icons.Filled.AdminPanelSettings, Color(0xFFF59E0B), Routes.PERMISSIONS, null),
    Tool("Automation", "Smart automation & quick actions", Icons.Filled.Bolt, JarvisColors.Purple, Routes.AUTOMATION, PremiumFeature.AUTOMATION),
    Tool("More Features", "Explore additional tools & services", Icons.Filled.GridView, JarvisColors.Neon, Routes.MORE_FEATURES, PremiumFeature.MORE_FEATURES),
)

@Composable
fun ToolsScreen(onNavigate: (String) -> Unit, onGate: (PremiumFeature) -> Unit) {
    val isPremium by LocalContainer.current.premium.isPremium.collectAsState()
    var query by rememberSaveable { mutableStateOf("") }
    val shown = tools.filter { query.isBlank() || it.title.contains(query, true) || it.subtitle.contains(query, true) }

    ScreenScaffold("Tools", "Powerful tools for your daily tasks") {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search tools…") }, leadingIcon = { Icon(Icons.Filled.Search, null, tint = JarvisColors.TextDim) },
            colors = jarvisTextFieldColors(), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth(),
        )
        shown.forEach { t ->
            GlassCard(Modifier.fillMaxWidth(), onClick = {
                if (t.feature == null || isPremium) onNavigate(t.route) else onGate(t.feature)
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(t.icon, t.tint)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(t.subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
                    }
                    if (t.feature != null) { ProBadge(locked = !isPremium); Spacer(Modifier.width(6.dp)) }
                    Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim, modifier = Modifier.size(20.dp))
                }
            }
        }
        if (shown.isEmpty()) Text("No tools match your search.", color = JarvisColors.TextDim, fontSize = 13.sp)
    }
}
