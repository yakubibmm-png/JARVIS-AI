package com.jarvis.ai.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.jarvis.ai.R
import com.jarvis.ai.chat.ChatMessage
import com.jarvis.ai.chat.ChatRole
import com.jarvis.ai.chat.Conversation
import com.jarvis.ai.chat.MessageStatus
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.CircleIconButton
import com.jarvis.ai.ui.components.JarvisBackground
import com.jarvis.ai.ui.components.MarkdownText
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.jarvisTextFieldColors
import com.jarvis.ai.ui.components.neonBorder
import com.jarvis.ai.ui.theme.JarvisColors
import java.io.File
import java.util.Calendar
import java.util.Date

private val suggestions = listOf("What can you do?", "Tell me a fun fact", "What time is it?", "Help me write code")

@Composable
fun ChatScreen(onOpenApiKey: () -> Unit, onQuickActions: () -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val vm: ChatViewModel = viewModel(factory = viewModelFactory { initializer { ChatViewModel(c, ctx.applicationContext) } })
    val conv by vm.active.collectAsState()
    val recents by vm.recents.collectAsState()
    val generating by vm.generating.collectAsState()
    val reading by c.voiceController.readingId.collectAsState()
    val geminiKey by c.credentials.geminiKey.collectAsState()
    val messages = conv?.messages.orEmpty()

    var menu by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var cameraUri by remember { mutableStateOf<Uri?>(null) }

    // attachments
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(vm::attach) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::attach) }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) cameraUri?.let(vm::attach) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggleDictation() else vm.notice = "Microphone permission is required for voice input."
    }

    LaunchedEffect(vm.notice) { vm.notice?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.notice = null } }

    fun launchCamera() {
        try {
            val dir = File(ctx.cacheDir, "camera").apply { mkdirs() }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", File(dir, "photo_${System.currentTimeMillis()}.jpg"))
            cameraUri = uri
            takePhoto.launch(uri)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "No camera app available.", Toast.LENGTH_SHORT).show()
        }
    }

    fun onMic() {
        val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (ok || vm.dictating) vm.toggleDictation() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val listState = rememberLazyListState()
    val last = messages.lastOrNull()
    LaunchedEffect(messages.size, conv?.id) { if (messages.isNotEmpty()) listState.scrollToItem(0) }
    LaunchedEffect(last?.text?.length) { if (last?.status == MessageStatus.STREAMING) listState.scrollToItem(0) }

    JarvisBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
            // ── Header ──
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        buildAnnotatedString {
                            withStyle(SpanStyle(color = Color.White)) { append("Chat with ") }
                            withStyle(SpanStyle(color = JarvisColors.Cyan)) { append("Jarvis AI") }
                        },
                        fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Text("Your Smart Companion", color = JarvisColors.TextDim, fontSize = 12.sp)
                }
                HeaderPill(Icons.Filled.Add, "New Chat") { vm.newChat() }
                Spacer(Modifier.width(6.dp))
                HeaderPill(Icons.Filled.Delete, "Clear Chat") { if (messages.isNotEmpty()) confirmClear = true }
                Box {
                    CircleIconButton(Icons.Filled.MoreVert, "More options", { menu = true }, Modifier.padding(start = 4.dp).size(38.dp))
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem(text = { Text("Share chat") }, onClick = { menu = false; if (messages.isNotEmpty()) share(ctx, vm.transcript()) })
                        DropdownMenuItem(text = { Text("Delete this chat") }, onClick = { menu = false; if (messages.isNotEmpty()) confirmDelete = true })
                        DropdownMenuItem(
                            text = { Text(if (vm.historyEnabled) "Turn chat history off" else "Turn chat history on") },
                            onClick = { menu = false; vm.setHistoryEnabled(!vm.historyEnabled) },
                        )
                    }
                }
            }

            // ── Recent chats ──
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).clip(RoundedCornerShape(16.dp)).background(JarvisColors.Card.copy(alpha = 0.7f)).neonBorder(RoundedCornerShape(16.dp)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(end = 8.dp)) {
                    Icon(Icons.Filled.History, null, tint = JarvisColors.Cyan, modifier = Modifier.size(22.dp))
                    Text("Recent", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("Chats", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
                if (recents.isEmpty()) Text("Your conversations will appear here.", color = JarvisColors.TextDim, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recents, key = { it.id }) { r ->
                        val sel = r.id == conv?.id
                        Row(
                            Modifier.clip(RoundedCornerShape(12.dp)).background(if (sel) JarvisColors.Blue.copy(alpha = 0.35f) else JarvisColors.BgTop)
                                .border(1.dp, if (sel) JarvisColors.Cyan else JarvisColors.Blue.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .clickable(role = Role.Button) { vm.select(r.id) }.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.ChatBubbleOutline, null, tint = JarvisColors.Neon, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Column(Modifier.width(104.dp)) {
                                Text(r.title, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(relative(ctx, r.updatedAt), color = JarvisColors.TextDim, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }

            if (geminiKey.isBlank()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x33F59E0B)).border(1.dp, JarvisColors.Gold, RoundedCornerShape(14.dp)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Add your Gemini API key to start using JARVIS AI.", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    NeonButton("ADD KEY", onOpenApiKey)
                }
                Spacer(Modifier.height(6.dp))
            }

            // ── Messages (newest at the bottom, list anchored to the bottom) ──
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(), state = listState, reverseLayout = true,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(messages.asReversed(), key = { it.id }) { m ->
                    if (m.role == ChatRole.USER) UserBubble(m) else AssistantBubble(
                        m, reading == m.id,
                        onCopy = { copy(ctx, m.text) }, onShare = { share(ctx, m.text) },
                        onRead = { c.voiceController.readAloud(m.id, m.text) },
                        onRetry = { vm.retry(m.id) }, onAddKey = onOpenApiKey,
                        onCopyCode = { copy(ctx, it) },
                    )
                }
                if (messages.isEmpty()) item(key = "welcome") {
                    Welcome(onPick = { vm.input = it; vm.send() })
                }
            }

            // ── Attachment preview ──
            vm.attachment?.let { a ->
                Row(
                    Modifier.padding(horizontal = 12.dp).clip(RoundedCornerShape(12.dp)).background(JarvisColors.Card).neonBorder(RoundedCornerShape(12.dp)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    a.thumbnail?.let { Image(it.asImageBitmap(), null, Modifier.size(36.dp).clip(RoundedCornerShape(6.dp))) }
                        ?: Icon(Icons.Filled.AttachFile, null, tint = JarvisColors.Cyan, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(a.name, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false).width(180.dp))
                    Icon(Icons.Filled.Close, "Remove attachment", tint = JarvisColors.TextDim, modifier = Modifier.padding(start = 8.dp).size(20.dp).clickable { vm.removeAttachment() })
                }
                Spacer(Modifier.height(6.dp))
            }

            // ── Input ──
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = vm.input, onValueChange = { vm.input = it },
                    placeholder = { Text(if (vm.dictating) "Listening…" else "Message Jarvis…") },
                    maxLines = 4, colors = jarvisTextFieldColors(), shape = RoundedCornerShape(24.dp),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = ImeAction.Default),
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                MicOrb(vm.dictating, vm.dictLevel, ::onMic)
                Spacer(Modifier.width(8.dp))
                val canSend = vm.input.isNotBlank() || vm.attachment != null
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(if (generating || canSend) JarvisColors.Blue else JarvisColors.Blue.copy(alpha = 0.35f))
                        .clickable(enabled = generating || canSend, role = Role.Button) { if (generating) vm.stopGenerating() else vm.send() },
                    contentAlignment = Alignment.Center,
                ) { Icon(if (generating) Icons.Filled.Stop else Icons.AutoMirrored.Filled.Send, if (generating) "Stop" else "Send", tint = Color.White, modifier = Modifier.size(22.dp)) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ToolChip(Icons.Filled.ImageIcon, "Image", Modifier.weight(1f)) { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                ToolChip(Icons.Filled.AttachFile, "File", Modifier.weight(1f)) { pickFile.launch(arrayOf("application/pdf", "text/*", "application/json", "application/xml")) }
                ToolChip(Icons.Filled.CameraAlt, "Camera", Modifier.weight(1f)) { launchCamera() }
                ToolChip(Icons.Filled.AutoAwesome, "Actions", Modifier.weight(1f), onClick = onQuickActions)
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (confirmClear) ConfirmDialog("Clear this chat?", "All messages in this conversation will be removed.", "Clear", { confirmClear = false; vm.clearChat() }) { confirmClear = false }
    if (confirmDelete) ConfirmDialog("Delete this chat?", "This conversation will be removed permanently.", "Delete", { confirmDelete = false; vm.deleteCurrent() }) { confirmDelete = false }
}

@Composable
private fun ConfirmDialog(title: String, body: String, action: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = JarvisColors.Card,
        title = { Text(title, color = Color.White) }, text = { Text(body, color = JarvisColors.TextDim) },
        confirmButton = { TextButton(onConfirm) { Text(action, color = JarvisColors.Danger) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel", color = JarvisColors.Cyan) } },
    )
}

@Composable
private fun HeaderPill(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).border(1.dp, JarvisColors.Neon, RoundedCornerShape(50)).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 9.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun ToolChip(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(12.dp)).background(JarvisColors.Card.copy(alpha = 0.7f)).neonBorder(RoundedCornerShape(12.dp)).clickable(role = Role.Button, onClick = onClick).padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = JarvisColors.Cyan, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
private fun MicOrb(active: Boolean, level: Float, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "dict")
    val pulse by t.animateFloat(0.4f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "p")
    val glow = if (active) (0.4f + 0.6f * level).coerceAtLeast(0.35f * pulse) else 0.3f
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(JarvisColors.Cyan.copy(alpha = glow * 0.35f))
            .border(2.dp, JarvisColors.Neon.copy(alpha = 0.4f + glow * 0.6f), CircleShape).clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(if (active) Icons.Filled.Stop else Icons.Filled.Mic, if (active) "Stop dictation" else "Dictate", tint = Color.White, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun Welcome(onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Avatar(assistant = true)
            Spacer(Modifier.width(8.dp))
            Column(
                Modifier.clip(RoundedCornerShape(16.dp)).background(JarvisColors.Card.copy(alpha = 0.8f)).neonBorder(RoundedCornerShape(16.dp)).padding(12.dp),
            ) {
                Text("Hello! 😊", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text("I'm Jarvis, your AI assistant. How can I help you today?", color = Color.White, fontSize = 14.sp)
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(start = 40.dp)) {
            items(suggestions) { s ->
                Text(
                    s, color = JarvisColors.Cyan, fontSize = 12.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, JarvisColors.Neon, RoundedCornerShape(50)).clickable { onPick(s) }.padding(horizontal = 12.dp, vertical = 7.dp),
                )
            }
        }
    }
}

@Composable
private fun Avatar(assistant: Boolean) {
    if (assistant) Image(painterResource(com.jarvis.ai.ui.theme.Appearance.avatarRes()), null, Modifier.size(32.dp).clip(CircleShape).border(1.5.dp, JarvisColors.Cyan, CircleShape))
    else Box(Modifier.size(32.dp).clip(CircleShape).background(JarvisColors.Card).border(1.5.dp, JarvisColors.Neon, CircleShape), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun UserBubble(m: ChatMessage) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Top) {
        Column(
            Modifier.weight(1f, fill = false).clip(RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp))
                .background(Brush.horizontalGradient(listOf(JarvisColors.Blue, Color(0xFF0EA5E9)))).padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            m.attachment?.let { Text("📎 ${it.name}", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp) }
            if (m.text.isNotBlank()) Text(m.text, color = Color.White, fontSize = 14.sp)
            Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                if (m.viaVoice) { Icon(Icons.Filled.Mic, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(11.dp)); Spacer(Modifier.width(3.dp)) }
                Text(time(ctx, m.timestamp), color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Filled.DoneAll, null, tint = Color(0xFFBAE6FD), modifier = Modifier.size(13.dp))
            }
        }
        Spacer(Modifier.width(8.dp))
        Avatar(assistant = false)
    }
}

@Composable
private fun AssistantBubble(
    m: ChatMessage, reading: Boolean,
    onCopy: () -> Unit, onShare: () -> Unit, onRead: () -> Unit, onRetry: () -> Unit, onAddKey: () -> Unit, onCopyCode: (String) -> Unit,
) {
    val ctx = LocalContext.current
    val isError = m.status == MessageStatus.ERROR
    val streaming = m.status == MessageStatus.STREAMING
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Avatar(assistant = true)
        Spacer(Modifier.width(8.dp))
        Column(
            Modifier.weight(1f, fill = false).clip(RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)).background(JarvisColors.Card.copy(alpha = 0.85f))
                .border(1.dp, if (isError) JarvisColors.Danger else JarvisColors.Blue.copy(alpha = 0.7f), RoundedCornerShape(16.dp, 16.dp, 16.dp, 4.dp)).padding(12.dp),
        ) {
            if (m.text.isEmpty() && streaming) Thinking()
            else if (isError) Text(m.text, color = JarvisColors.Danger, fontSize = 14.sp)
            else MarkdownText(m.text, onCopyCode = onCopyCode)
            if (m.status == MessageStatus.CANCELLED) Text("Stopped", color = JarvisColors.TextDim, fontSize = 11.sp)
            m.actions.forEach { a ->
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.Top) {
                    Icon(if (a.ok) Icons.Filled.Check else Icons.Filled.Close, null, tint = if (a.ok) JarvisColors.Success else JarvisColors.Danger, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(a.summary, color = JarvisColors.TextDim, fontSize = 11.sp)
                }
            }
            Text(time(ctx, m.timestamp), color = JarvisColors.TextDim, fontSize = 10.sp, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
            if (!streaming) {
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (isError) {
                        ActionChip(Icons.Filled.Refresh, "Retry", onRetry)
                        if (m.text.contains("API key", true)) ActionChip(Icons.Filled.AutoAwesome, "Add key", onAddKey)
                    } else {
                        ActionChip(Icons.Filled.ContentCopy, "Copy", onCopy)
                        ActionChip(Icons.Filled.Share, "Share", onShare)
                        ActionChip(if (reading) Icons.Filled.Stop else Icons.Filled.VolumeUp, if (reading) "Stop" else "Read Aloud", onRead)
                    }
                }
            }
        }
    }
}

@Composable
private fun Thinking() {
    val t = rememberInfiniteTransition(label = "think")
    val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "a")
    Text("Thinking…", color = JarvisColors.Cyan, fontSize = 14.sp, modifier = Modifier.alpha(a))
}

@Composable
private fun ActionChip(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, JarvisColors.Blue, RoundedCornerShape(10.dp)).clickable(role = Role.Button, onClick = onClick).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

private fun time(ctx: Context, ts: Long): String = DateFormat.getTimeFormat(ctx).format(Date(ts))

private fun relative(ctx: Context, ts: Long): String {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = ts }
    fun day(c: Calendar) = c.get(Calendar.YEAR) * 400 + c.get(Calendar.DAY_OF_YEAR)
    val diff = day(now) - day(then)
    return when {
        diff <= 0 -> "Today, " + time(ctx, ts)
        diff == 1 -> "Yesterday"
        else -> "$diff days ago"
    }
}

private fun copy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    cm?.setPrimaryClip(ClipData.newPlainText("JARVIS AI", text))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

private fun share(ctx: Context, text: String) {
    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    try { ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(ctx, "Nothing available to share with.", Toast.LENGTH_SHORT).show() }
}
