package com.jarvis.ai.apps

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.jarvis.ai.JarvisApp

/** Keeps the installed-app list fresh and confirms installs started from Google Play. */
class PackageChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val c = (context.applicationContext as JarvisApp).container
        val pkg = intent.data?.schemeSpecificPart ?: return
        c.installedApps.invalidate()
        if (intent.action == Intent.ACTION_PACKAGE_ADDED || intent.action == Intent.ACTION_PACKAGE_REPLACED) c.installTracker.onPackageAdded(pkg)
    }
}
