package com.jarvis.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

enum class SpeechError { NO_SPEECH, PERMISSION, NETWORK, BUSY, UNAVAILABLE, AUDIO, OTHER }

interface SpeechCallback {
    fun onLevel(level: Float) {}
    fun onPartial(text: String) {}
    fun onFinal(text: String)
    fun onError(error: SpeechError)
}

/** Thin wrapper over Android's SpeechRecognizer. Must be used from the main thread. */
class SpeechInput(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private var callback: SpeechCallback? = null
    private var smoothed = 0f
    private val main = Handler(Looper.getMainLooper())

    val isAvailable: Boolean get() = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(locale: Locale, cb: SpeechCallback) {
        cancel()
        callback = cb
        smoothed = 0f
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(listener)
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            },
        )
    }

    /** Stop capturing and deliver the final result. */
    fun finish() { recognizer?.stopListening() }

    /** Abort silently: no callbacks after this. */
    fun cancel() {
        callback = null
        val r = recognizer
        recognizer = null
        if (r != null) {
            runCatching { r.cancel() }
            main.post { runCatching { r.destroy() } }
        }
    }

    private fun deliver(block: (SpeechCallback) -> Unit) {
        val cb = callback ?: return
        callback = null
        val old = recognizer
        recognizer = null
        main.post { runCatching { old?.destroy() } }
        block(cb)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onRmsChanged(rmsdB: Float) {
            val level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            smoothed = smoothed * 0.4f + level * 0.6f
            callback?.onLevel(smoothed)
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (t.isNotBlank()) callback?.onPartial(t)
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            deliver { if (t.isBlank()) it.onError(SpeechError.NO_SPEECH) else it.onFinal(t) }
        }

        override fun onError(error: Int) {
            val e = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> SpeechError.NO_SPEECH
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> SpeechError.PERMISSION
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> SpeechError.NETWORK
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> SpeechError.BUSY
                SpeechRecognizer.ERROR_AUDIO -> SpeechError.AUDIO
                SpeechRecognizer.ERROR_CLIENT -> SpeechError.UNAVAILABLE
                else -> SpeechError.OTHER
            }
            deliver { it.onError(e) }
        }
    }
}
