package com.jarvis.ai.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Single source of truth for provider API keys. Keys are never logged. */
class CredentialsRepository(private val store: SecureStore) {
    private val _gemini = MutableStateFlow(store.getString(K_GEMINI))
    private val _eleven = MutableStateFlow(store.getString(K_ELEVEN))

    val geminiKey: StateFlow<String> = _gemini.asStateFlow()
    val elevenLabsKey: StateFlow<String> = _eleven.asStateFlow()

    val hasGeminiKey: Boolean get() = _gemini.value.isNotBlank()
    val hasElevenLabsKey: Boolean get() = _eleven.value.isNotBlank()

    fun setGeminiKey(value: String) = write(K_GEMINI, value, _gemini)
    fun setElevenLabsKey(value: String) = write(K_ELEVEN, value, _eleven)

    private fun write(storeKey: String, value: String, flow: MutableStateFlow<String>) {
        val v = value.trim()
        if (v.isEmpty()) store.remove(storeKey) else store.putString(storeKey, v)
        flow.value = v
    }

    private companion object {
        const val K_GEMINI = "gemini_api_key"
        const val K_ELEVEN = "elevenlabs_api_key"
    }
}
