package com.jarvis.ai.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.jarvis.ai.R
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.AiOrb
import com.jarvis.ai.ui.components.CircleIconButton
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.JarvisBackground
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.VoiceVisualizer
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.voice.NoticeAction
import com.jarvis.ai.voice.VoiceState

@Composable
fun HomeScreen(
    onOpenSettings: () -> Unit,
    onOpenApiKey: () -> Unit,
    onQuickActions: () -> Unit,
    onReminders: () -> Unit,
    onMusic: () -> Unit,
    onWeather: () -> Unit,
    onOpenPermissions: () -> Unit = {},
) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val controller = c.voiceController
    val voice by c.voiceSession.ui.collectAsState()
    val snack = remember { SnackbarHostState() }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) controller.onMicPressed()
        else c.voiceSession.notify("Microphone permission is required for voice input.", NoticeAction.OPEN_APP_SETTINGS)
    }

    fun onMic() {
        val st = voice.state
        val starting = st != VoiceState.LISTENING && st != VoiceState.THINKING
        val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (starting && c.credentials.hasGeminiKey && !micOk) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        else controller.onMicPressed()
    }

    LaunchedEffect(voice.notice?.id) {
        val n = voice.notice ?: return@LaunchedEffect
        val label = when (n.action) { NoticeAction.ADD_KEY -> "ADD KEY"; NoticeAction.OPEN_APP_SETTINGS -> "SETTINGS"; NoticeAction.OPEN_PERMISSIONS -> "PERMISSIONS"; null -> null }
        val r = snack.showSnackbar(n.text, actionLabel = label, duration = if (label != null) SnackbarDuration.Long else SnackbarDuration.Short)
        if (r == SnackbarResult.ActionPerformed) when (n.action) {
            NoticeAction.ADD_KEY -> onOpenApiKey()
            NoticeAction.OPEN_APP_SETTINGS -> ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            NoticeAction.OPEN_PERMISSIONS -> onOpenPermissions()
            null -> Unit
        }
    }

    JarvisBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
            // Top bar: Settings | brand | Gemini-style key icon
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                CircleIconButton(Icons.Filled.Settings, "Settings", onOpenSettings)
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painterResource(com.jarvis.ai.ui.theme.Appearance.avatarRes()), null,
                        Modifier.size(38.dp).clip(CircleShape).border(1.5.dp, JarvisColors.Cyan, CircleShape),
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(brand(), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Your Smart AI Assistant", color = JarvisColors.TextDim, fontSize = 11.sp)
                    }
                }
                CircleIconButton(Icons.Filled.AutoAwesome, "Gemini and ElevenLabs API keys", onOpenApiKey, tint = Color.White)
            }

            // Orb
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val s = minOf(maxWidth, maxHeight)
                AiOrb(Modifier.size(s), voice.state, voice.level)
            }

            // Live waveform: follows the mic while you speak and JARVIS's audio while it speaks
            VoiceVisualizer(voice.state, voice.level)

            // Live caption: what you are saying / what JARVIS is answering
            Text(
                voice.caption,
                color = if (voice.state == VoiceState.SPEAKING) JarvisColors.Cyan else Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().heightIn(min = 36.dp).padding(horizontal = 8.dp, vertical = 4.dp),
            )

            // Mic + status + session controls
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                MicButton(active = voice.state == VoiceState.LISTENING, level = voice.level, onClick = ::onMic)
                Spacer(Modifier.height(8.dp))
                Text(
                    voice.state.label, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, JarvisColors.Neon, RoundedCornerShape(50)).padding(horizontal = 22.dp, vertical = 6.dp),
                )
                val active = voice.state == VoiceState.LISTENING || voice.state == VoiceState.THINKING ||
                    voice.state == VoiceState.SPEAKING || voice.state == VoiceState.MUTED
                if (active) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NeonButton(if (voice.state == VoiceState.MUTED) "UNMUTE" else "MUTE", controller::toggleMute, filled = false)
                        NeonButton("SLEEP", controller::sleep, filled = false)
                        NeonButton("STOP", controller::stop, colors = listOf(Color(0xFFB91C1C), Color(0xFFEF4444)))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))

            // Quick cards
            GlassCard(Modifier.fillMaxWidth(), padding = 8.dp) {
                Row(Modifier.fillMaxWidth()) {
                    QuickCard(Icons.Filled.Bolt, JarvisColors.Blue, "Quick Actions", "Open apps, search…", onQuickActions, Modifier.weight(1f))
                    QuickCard(Icons.Filled.Event, JarvisColors.Purple, "Reminders", "Never miss anything", onReminders, Modifier.weight(1f))
                    QuickCard(Icons.Filled.MusicNote, JarvisColors.Magenta, "Music", "Play your favorite", onMusic, Modifier.weight(1f))
                    QuickCard(Icons.Filled.WbSunny, JarvisColors.Gold, "Weather", "Check live weather", onWeather, Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        SnackbarHost(snack, Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp))
    }
}

private fun brand(): AnnotatedString = buildAnnotatedString {
    withStyle(SpanStyle(color = Color.White)) { append("JARVIS ") }
    withStyle(SpanStyle(color = JarvisColors.Cyan)) { append("AI") }
}

@Composable
private fun MicButton(active: Boolean, level: Float, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "mic")
    val glow by t.animateFloat(0.35f, 0.9f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "glow")
    // While listening the ring follows your voice; otherwise it breathes gently.
    val ring = if (active) (0.45f + 0.55f * level).coerceIn(0f, 1f) else 0.45f * (0.6f + 0.4f * glow)
    Box(
        Modifier.size(92.dp).clip(CircleShape)
            .background(Brush.radialGradient(listOf(JarvisColors.Cyan.copy(alpha = ring * 0.4f), JarvisColors.Card)))
            .border(3.dp, JarvisColors.Neon.copy(alpha = 0.45f + ring * 0.55f), CircleShape)
            .clickable(role = Role.Button, onClickLabel = "Tap to speak", onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(Icons.Filled.Mic, "Microphone", tint = Color.White, modifier = Modifier.size(42.dp)) }
}

@Composable
private fun QuickCard(icon: ImageVector, tint: Color, title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).clickable(role = Role.Button, onClick = onClick).padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(tint.copy(alpha = 0.35f)).border(1.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1)
        Text(subtitle, color = JarvisColors.TextDim, fontSize = 9.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 11.sp)
    }
}
