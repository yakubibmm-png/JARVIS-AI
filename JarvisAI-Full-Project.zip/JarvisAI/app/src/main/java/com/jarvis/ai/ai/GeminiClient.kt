package com.jarvis.ai.ai

import android.content.Context
import android.util.Base64
import com.jarvis.ai.data.CredentialsRepository
import com.jarvis.ai.util.isOnline
import com.jarvis.ai.util.withConnection
import com.jarvis.ai.voice.VoiceProviderException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/** Gemini REST client (streaming SSE chat + speech synthesis). The API key is read per call and never logged. */
class GeminiClient(private val ctx: Context, private val creds: CredentialsRepository) : AiProvider {
    override val id = "gemini"
    override suspend fun isConfigured() = creds.hasGeminiKey

    override fun events(history: List<ChatTurn>, systemPrompt: String, options: AiOptions): Flow<AiEvent> = flow {
        val tweak = options.voiceMode && options.model.contains("flash", ignoreCase = true)
        var emitted = false
        try {
            streamOnce(history, systemPrompt, options, tweak) { emitted = true; emit(it) }
        } catch (e: AiException) {
            // Some models reject the thinking tweak; retry once without it if nothing was produced.
            if (tweak && !emitted && e.kind == AiException.Kind.BAD_REQUEST && e.detail.contains("thinking", true)) {
                streamOnce(history, systemPrompt, options, false) { emit(it) }
            } else throw e
        }
    }.flowOn(Dispatchers.IO)

    private suspend fun streamOnce(
        history: List<ChatTurn>, system: String, options: AiOptions, disableThinking: Boolean,
        onEvent: suspend (AiEvent) -> Unit,
    ) {
        val key = creds.geminiKey.value
        if (key.isBlank()) throw AiException(AiException.Kind.NO_KEY)
        if (!ctx.isOnline()) throw AiException(AiException.Kind.OFFLINE)
        val body = buildBody(history, system, disableThinking, options.tools).toString().toByteArray(Charsets.UTF_8)
        val url = "$BASE/models/${options.model}:streamGenerateContent?alt=sse"
        try {
            withConnection(url, { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 60_000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) throw errorFor(code, c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty())
                var any = false
                c.inputStream.bufferedReader().use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val json = line.removePrefix("data:").trim()
                        if (json.isEmpty() || json == "[DONE]") continue
                        for (ev in parseChunk(json)) { any = true; onEvent(ev) }
                    }
                }
                if (!any) throw AiException(AiException.Kind.EMPTY)
            }
        } catch (e: IOException) {
            throw AiException(if (e is UnknownHostException || e is ConnectException || e is SocketTimeoutException) AiException.Kind.OFFLINE else AiException.Kind.NETWORK)
        }
    }

    /** One non-streaming Gemini call (used for screen questions and auto-reply drafts). Optional image (JPEG). */
    suspend fun oneShot(model: String, system: String, userText: String, image: ByteArray? = null): String = withContext(Dispatchers.IO) {
        val key = creds.geminiKey.value
        if (key.isBlank()) throw AiException(AiException.Kind.NO_KEY)
        if (!ctx.isOnline()) throw AiException(AiException.Kind.OFFLINE)
        val parts = JSONArray().put(JSONObject().put("text", userText))
        image?.let { parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(it, Base64.NO_WRAP)))) }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .toString().toByteArray(Charsets.UTF_8)
        try {
            withConnection("$BASE/models/$model:generateContent", { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 60_000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) throw errorFor(code, c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty())
                val out = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val ps = out.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val sb = StringBuilder()
                if (ps != null) for (i in 0 until ps.length()) { val p = ps.getJSONObject(i); if (!p.optBoolean("thought", false)) sb.append(p.optString("text")) }
                if (sb.isBlank()) throw AiException(AiException.Kind.EMPTY)
                sb.toString().trim()
            }
        } catch (e: IOException) {
            throw AiException(if (e is UnknownHostException || e is ConnectException || e is SocketTimeoutException) AiException.Kind.OFFLINE else AiException.Kind.NETWORK)
        }
    }

    /** One-shot Gemini speech synthesis. Returns raw 16-bit PCM and its sample rate. */
    suspend fun synthesize(text: String, voiceName: String, ttsModel: String): Pair<ByteArray, Int> = withContext(Dispatchers.IO) {
        val key = creds.geminiKey.value
        if (key.isBlank()) throw VoiceProviderException("Add your Gemini API key to use this voice.")
        if (!ctx.isOnline()) throw VoiceProviderException("You're offline. This feature needs an internet connection.")
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName))))
            })
        }.toString().toByteArray(Charsets.UTF_8)
        try {
            withConnection("$BASE/models/$ttsModel:generateContent", { c ->
                c.requestMethod = "POST"; c.connectTimeout = 15_000; c.readTimeout = 60_000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
            }) { c ->
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                if (code !in 200..299) {
                    val e = errorFor(code, c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty())
                    throw VoiceProviderException(if (e.kind == AiException.Kind.INVALID_KEY) "Gemini rejected your API key." else "Gemini voice isn't available right now.")
                }
                val resp = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val part = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                val inline = part?.optJSONObject("inlineData") ?: part?.optJSONObject("inline_data")
                val data = inline?.optString("data").orEmpty()
                if (data.isEmpty()) throw VoiceProviderException("Gemini voice returned no audio.")
                val mime = inline?.optString("mimeType").orEmpty().ifEmpty { inline?.optString("mime_type").orEmpty() }
                val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                Base64.decode(data, Base64.DEFAULT) to rate
            }
        } catch (e: IOException) {
            throw VoiceProviderException("Gemini voice couldn't be reached.")
        }
    }

    private fun buildBody(history: List<ChatTurn>, system: String, disableThinking: Boolean, tools: JSONArray?): JSONObject {
        val contents = JSONArray()
        for (t in history) {
            val parts = JSONArray()
            val replay = t.modelParts
            when {
                replay != null -> replay.forEach { parts.put(it) }
                t.toolResults.isNotEmpty() -> t.toolResults.forEach {
                    parts.put(JSONObject().put("functionResponse", JSONObject().put("name", it.name).put("response", it.response)))
                }
                else -> {
                    if (t.text.isNotBlank()) parts.put(JSONObject().put("text", t.text))
                    t.attachment?.let { a ->
                        when {
                            a.bytes != null -> parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", a.mime).put("data", Base64.encodeToString(a.bytes, Base64.NO_WRAP))))
                            a.text != null -> parts.put(JSONObject().put("text", "Attached file \"${a.name}\":\n```\n${a.text}\n```"))
                        }
                    }
                }
            }
            if (parts.length() == 0) continue
            contents.put(JSONObject().put("role", if (t.role == ChatTurn.Role.USER) "user" else "model").put("parts", parts))
        }
        return JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            put("contents", contents)
            if (tools != null && tools.length() > 0) put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools)))
            if (disableThinking) put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
        }
    }

    private fun parseChunk(json: String): List<AiEvent> {
        val o = JSONObject(json)
        o.optJSONObject("error")?.let { throw errorFor(it.optInt("code", 500), it.toString()) }
        val cands = o.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            if (o.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty().isNotEmpty()) throw AiException(AiException.Kind.BLOCKED)
            return emptyList()
        }
        val c = cands.getJSONObject(0)
        val parts = c.optJSONObject("content")?.optJSONArray("parts")
        val out = ArrayList<AiEvent>()
        if (parts != null) for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            val fc = p.optJSONObject("functionCall")
            if (fc != null) out.add(AiEvent.Call(FnCall(fc.optString("name"), fc.optJSONObject("args") ?: JSONObject(), p)))
            else if (p.has("text") && p.optString("text").isNotEmpty()) out.add(AiEvent.Text(p.optString("text"), p))
        }
        if (out.isEmpty() && c.optString("finishReason") in BLOCK_REASONS) throw AiException(AiException.Kind.BLOCKED)
        return out
    }

    private fun errorFor(code: Int, body: String): AiException {
        val msg = runCatching {
            val o = JSONObject(body)
            o.optJSONObject("error")?.optString("message") ?: o.optString("message")
        }.getOrNull().orEmpty()
        val kind = when {
            code == 400 && msg.contains("API key", true) -> AiException.Kind.INVALID_KEY
            code == 400 -> AiException.Kind.BAD_REQUEST
            code == 401 || code == 403 -> AiException.Kind.INVALID_KEY
            code == 404 -> AiException.Kind.MODEL_NOT_FOUND
            code == 429 -> AiException.Kind.RATE_LIMIT
            code in 500..599 -> AiException.Kind.SERVER
            else -> AiException.Kind.UNKNOWN
        }
        return AiException(kind, msg)
    }

    private companion object {
        const val BASE = "https://generativelanguage.googleapis.com/v1beta"
        val BLOCK_REASONS = setOf("SAFETY", "BLOCKLIST", "PROHIBITED_CONTENT", "SPII", "RECITATION")
    }
}
