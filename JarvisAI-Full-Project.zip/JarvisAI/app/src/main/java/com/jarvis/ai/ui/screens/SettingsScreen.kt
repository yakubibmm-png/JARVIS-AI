package com.jarvis.ai.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.R
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.premium.PremiumFeature
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.GlowIcon
import com.jarvis.ai.ui.components.ProBadge
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.nav.Routes
import com.jarvis.ai.ui.theme.JarvisColors

private data class SettingsItem(val title: String, val subtitle: String, val icon: ImageVector, val tint: Color, val route: String, val feature: PremiumFeature? = null)

private val items = listOf(
    SettingsItem("AI Personalization", "Customize your AI assistant", Icons.Filled.AutoAwesome, JarvisColors.Purple, Routes.PERSONALIZATION, PremiumFeature.PERSONALIZATION),
    SettingsItem("Voice & Audio", "Voice settings, TTS, volume", Icons.Filled.VolumeUp, JarvisColors.Blue, Routes.SETTINGS_VOICE),
    SettingsItem("Notifications", "App & chat notifications", Icons.Filled.Notifications, Color(0xFFEF4444), Routes.SETTINGS_NOTIFICATIONS),
    SettingsItem("Privacy & Security", "Data, chat, and account security", Icons.Filled.Security, Color(0xFF3B82F6), Routes.SETTINGS_PRIVACY),
    SettingsItem("Permissions", "Manage app permissions", Icons.Filled.AdminPanelSettings, Color(0xFFF59E0B), Routes.PERMISSIONS),
    SettingsItem("Appearance", "Theme, language, UI settings", Icons.Filled.Palette, JarvisColors.Magenta, Routes.SETTINGS_APPEARANCE),
    SettingsItem("About", "Version, help & support", Icons.Filled.Info, JarvisColors.Cyan, Routes.SETTINGS_ABOUT),
)

@Composable
fun SettingsScreen(onNavigate: (String) -> Unit, onGate: (PremiumFeature) -> Unit) {
    val isPremium by LocalContainer.current.premium.isPremium.collectAsState()
    ScreenScaffold("Settings", "Manage your JARVIS AI experience") {
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(com.jarvis.ai.ui.theme.Appearance.avatarRes()), null, Modifier.size(52.dp).clip(CircleShape).border(1.5.dp, JarvisColors.Cyan, CircleShape))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Your Account", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(if (isPremium) "Pro plan active" else "Free plan", color = if (isPremium) JarvisColors.Gold else JarvisColors.TextDim, fontSize = 12.sp)
                }
            }
        }
        items.forEach { s ->
            GlassCard(Modifier.fillMaxWidth(), onClick = {
                if (s.feature == null || isPremium) onNavigate(s.route) else onGate(s.feature)
            }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlowIcon(s.icon, s.tint, size = 40.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(s.subtitle, color = JarvisColors.TextDim, fontSize = 12.sp)
                    }
                    if (s.feature != null) { ProBadge(locked = !isPremium); Spacer(Modifier.width(6.dp)) }
                    Icon(Icons.Filled.ChevronRight, null, tint = JarvisColors.TextDim, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}
