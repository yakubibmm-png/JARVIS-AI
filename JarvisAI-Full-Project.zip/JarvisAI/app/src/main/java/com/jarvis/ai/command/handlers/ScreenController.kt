package com.jarvis.ai.command.handlers

import com.jarvis.ai.command.ActionOutcome
import org.json.JSONObject

/** Screen understanding and UI interaction. The real implementation is AccessibilityScreenController. */
interface ScreenController {
    val isAvailable: Boolean
    suspend fun perform(action: String, target: String, text: String, ordinal: Int): ActionOutcome
    suspend fun ask(question: String): ActionOutcome
    suspend fun confirm(approve: Boolean): ActionOutcome
}

object UnavailableScreenController : ScreenController {
    override val isAvailable = false
    private fun no(action: String) = ActionOutcome(
        ok = false, reason = "accessibility_unavailable",
        summary = "Screen control isn't available. It needs the Accessibility Service, Pro and Automation ON.",
        data = JSONObject().put("requested_action", action),
    )
    override suspend fun perform(action: String, target: String, text: String, ordinal: Int) = no(action)
    override suspend fun ask(question: String) = no("screen_question")
    override suspend fun confirm(approve: Boolean) = no("confirm_action")
}
