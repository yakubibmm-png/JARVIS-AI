package com.jarvis.ai.automation

import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.MainActivity
import com.jarvis.ai.R
import com.jarvis.ai.apps.InstalledApps
import com.jarvis.ai.chat.ConversationEngine
import com.jarvis.ai.command.AppForeground
import com.jarvis.ai.data.AppPrefs
import com.jarvis.ai.premium.PremiumRepository
import com.jarvis.ai.reminders.Notifier
import com.jarvis.ai.screen.JarvisAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** Speaks reminders and assistant events aloud, in the app or (via a legitimate foreground service) in the background. */
class BackgroundVoice(
    private val ctx: Context,
    private val prefs: AppPrefs,
    private val premium: PremiumRepository,
    private val foreground: AppForeground,
    private val inApp: (String) -> Unit,
) {
    /** [force] skips the "voice notifications" switch (used for reminders, which have their own switch). Pro only. */
    fun speak(text: String, force: Boolean = false) {
        if (text.isBlank() || !premium.isPremium.value) return
        if (!force && !prefs.voiceNotifications) return
        if (foreground.isForeground) { inApp(text); return }
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java).setAction(AssistantService.ACTION_SPEAK).putExtra("text", text))
        } catch (e: Exception) {
            // Android refused a background start (e.g. no exact-alarm exemption). The notification was already shown.
        }
    }
}

/** Runs user-defined commands (tasks, triggers, custom actions) through the same engine as voice and chat. */
class AutomationRunner(
    private val ctx: Context,
    private val scope: CoroutineScope,
    private val engine: () -> ConversationEngine,
    private val settings: AutomationSettings,
    private val premium: PremiumRepository,
    private val voice: BackgroundVoice,
    private val apps: InstalledApps,
) {
    fun canRun() = premium.isPremium.value && settings.enabled.value

    fun run(label: String, command: String) {
        if (!canRun()) return
        scope.launch {
            val o = engine().send(command, null, viaVoice = true)
            val text = o.error ?: o.text
            Notifier.info(ctx, "JARVIS: $label", text)
            voice.speak(text)
        }
    }

    /** Scheduled "open app": opens it directly if Accessibility allows background launches, otherwise a tap-to-open notification. */
    fun launchApp(pkg: String, label: String) {
        if (!canRun()) return
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        val appLabel = apps.labelOf(pkg) ?: label
        val svc = JarvisAccessibilityService.instance
        val started = svc != null && runCatching { svc.startActivity(Intent(intent).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
        if (!started) Notifier.withIntent(ctx, "Time to open $appLabel", "Tap to open $appLabel", PendingIntent.getActivity(ctx, pkg.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
    }
}

class TaskScheduler(private val ctx: Context, private val items: AutomationItems) {
    private val alarms = ctx.getSystemService(AlarmManager::class.java)

    fun schedule(t: AutoTask) {
        val exact = Build.VERSION.SDK_INT < 31 || alarms.canScheduleExactAlarms()
        if (exact) alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.triggerAt, pending(t.id))
        else alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.triggerAt, pending(t.id))
    }
    fun cancel(id: Int) { alarms.cancel(pending(id)); items.removeTask(id) }
    fun rescheduleAll() { val now = System.currentTimeMillis(); items.tasks.value.forEach { if (it.triggerAt <= now) advanceOrRemove(it) else schedule(it) } }

    fun advanceOrRemove(t: AutoTask) {
        val step = when (t.repeat) { "daily" -> 24L * 3600_000; "weekly" -> 7L * 24 * 3600_000; else -> 0L }
        if (step == 0L) { items.removeTask(t.id); return }
        var next = t.triggerAt
        while (next <= System.currentTimeMillis()) next += step
        val u = t.copy(triggerAt = next); items.updateTask(u); schedule(u)
    }

    private fun pending(id: Int): PendingIntent = PendingIntent.getBroadcast(
        ctx, 500_000 + id, Intent(ctx, AutomationReceiver::class.java).setAction(ACTION).setData(Uri.parse("jarvis://task/$id")).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )
    companion object { const val ACTION = "com.jarvis.ai.TASK" }
}

class AutomationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val c = (context.applicationContext as JarvisApp).container
        val t = c.automationItems.task(intent.getIntExtra("id", -1)) ?: return
        c.taskScheduler.advanceOrRemove(t) // reschedule repeats first so they survive a crash
        if (t.launchPkg != null) c.automationRunner.launchApp(t.launchPkg, t.label) else c.automationRunner.run(t.label, t.command)
    }
}

object TriggerEvents {
    val all = listOf(
        "POWER_CONNECTED" to "Charger connected", "POWER_DISCONNECTED" to "Charger disconnected",
        "HEADSET_PLUGGED" to "Headphones plugged in", "HEADSET_UNPLUGGED" to "Headphones unplugged",
        "WIFI_CONNECTED" to "Wi-Fi connected", "WIFI_DISCONNECTED" to "Wi-Fi disconnected",
    )
    fun label(event: String) = all.firstOrNull { it.first == event }?.second ?: event
}

/** Watches charger / headphones / Wi-Fi while the background assistant runs. Fires the user's saved commands. */
class TriggerManager(private val ctx: Context, private val items: AutomationItems, private val onFire: (SmartTrigger) -> Unit) {
    private val last = HashMap<String, Long>()
    private var startedAt = 0L
    private val handler = Handler(Looper.getMainLooper())
    private var power: BroadcastReceiver? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var audioCb: AudioDeviceCallback? = null

    private fun fire(event: String) {
        val now = System.currentTimeMillis()
        if (now - startedAt < 4000 || now - (last[event] ?: 0L) < 5000) return // ignore the initial "already connected" callbacks
        last[event] = now
        items.triggers.value.filter { it.event == event }.forEach(onFire)
    }

    fun start() {
        startedAt = System.currentTimeMillis()
        power = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { fire(if (i.action == Intent.ACTION_POWER_CONNECTED) "POWER_CONNECTED" else "POWER_DISCONNECTED") }
        }.also { ContextCompat.registerReceiver(ctx, it, IntentFilter().apply { addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED) }, ContextCompat.RECEIVER_NOT_EXPORTED) }

        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        netCb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { fire("WIFI_CONNECTED") }
            override fun onLost(network: Network) { fire("WIFI_DISCONNECTED") }
        }.also { cm.registerNetworkCallback(NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(), it) }

        val am = ctx.getSystemService(AudioManager::class.java)
        audioCb = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(d: Array<out AudioDeviceInfo>) { if (d.any { isHeadset(it) }) fire("HEADSET_PLUGGED") }
            override fun onAudioDevicesRemoved(d: Array<out AudioDeviceInfo>) { if (d.any { isHeadset(it) }) fire("HEADSET_UNPLUGGED") }
        }.also { am.registerAudioDeviceCallback(it, handler) }
    }

    fun stop() {
        power?.let { runCatching { ctx.unregisterReceiver(it) } }; power = null
        netCb?.let { runCatching { ctx.getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } }; netCb = null
        audioCb?.let { runCatching { ctx.getSystemService(AudioManager::class.java).unregisterAudioDeviceCallback(it) } }; audioCb = null
    }

    private fun isHeadset(d: AudioDeviceInfo) = d.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || d.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || d.type == AudioDeviceInfo.TYPE_USB_HEADSET
}

/**
 * The legitimate background assistant: a visible foreground service ("JARVIS is active") that keeps JARVIS ready for
 * spoken reminders, voice notifications, smart triggers and the auto-reply you enabled. It never listens to the
 * microphone in the background. Stop it any time from the notification.
 */
class AssistantService : Service() {
    companion object {
        const val ACTION_START = "com.jarvis.ai.ASSISTANT_START"
        const val ACTION_SPEAK = "com.jarvis.ai.ASSISTANT_SPEAK"
        const val ACTION_STOP = "com.jarvis.ai.ASSISTANT_STOP"
        const val ACTION_AUTOREPLY_OFF = "com.jarvis.ai.ASSISTANT_AUTOREPLY_OFF"
        private const val NOTIF_ID = 7001
        @Volatile var running = false

        fun start(ctx: Context) = ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java).setAction(ACTION_START))
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, AssistantService::class.java)) }
    }

    private var triggers: TriggerManager? = null
    private var statusJob: Job? = null
    private val container get() = (applicationContext as JarvisApp).container

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val c = container
        when (intent?.action) {
            ACTION_STOP -> { c.prefs.backgroundAssistant = false; shutdown(); return START_NOT_STICKY }
            ACTION_AUTOREPLY_OFF -> { c.automation.setAutoReply(false); if (!c.prefs.backgroundAssistant) { shutdown(); return START_NOT_STICKY } }
            ACTION_SPEAK -> {
                enterForeground()
                val text = intent.getStringExtra("text").orEmpty()
                c.appScope.launch {
                    try { c.tts.speak(text) { } } catch (e: Exception) { /* nothing more to do */ }
                    if (!c.prefs.backgroundAssistant) shutdown()
                }
                return START_NOT_STICKY
            }
        }
        enterForeground()
        if (c.prefs.backgroundAssistant) startPersistent()
        return START_STICKY
    }

    private fun startPersistent() {
        if (running) return
        running = true
        triggers = TriggerManager(this, container.automationItems) { t -> container.automationRunner.run(TriggerEvents.label(t.event), t.command) }.also { it.start() }
        statusJob = container.appScope.launch {
            combine(container.automation.enabled, container.automation.autoReplyEnabled) { a, r -> a to r }.collect { enterForeground() }
        }
    }

    private fun enterForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NOTIF_ID, n)
    }

    private fun buildNotification(): Notification {
        Notifier.ensureChannels(this)
        val c = container
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE)
        fun svc(action: String, code: Int) = PendingIntent.getService(this, code, Intent(this, AssistantService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val auto = c.automation.enabled.value && c.automation.autoReplyEnabled.value
        val b = NotificationCompat.Builder(this, Notifier.CH_STATUS)
            .setSmallIcon(R.drawable.ic_notification).setContentTitle("JARVIS is active")
            .setContentText("Automation ${if (c.automation.enabled.value) "ON" else "OFF"} · Auto-reply ${if (auto) "ON" else "OFF"} · microphone is not in use")
            .setOngoing(true).setContentIntent(open)
        if (auto) b.addAction(0, "Auto-reply OFF", svc(ACTION_AUTOREPLY_OFF, 1))
        b.addAction(0, "Stop", svc(ACTION_STOP, 2))
        return b.build()
    }

    private fun shutdown() {
        running = false
        statusJob?.cancel(); triggers?.stop(); triggers = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { running = false; statusJob?.cancel(); triggers?.stop(); super.onDestroy() }
}
