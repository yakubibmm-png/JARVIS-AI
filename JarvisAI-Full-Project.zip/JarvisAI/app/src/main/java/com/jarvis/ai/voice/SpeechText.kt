package com.jarvis.ai.voice

import java.util.Locale

object SpeechText {
    private val fence = Regex("```.*?```", RegexOption.DOT_MATCHES_ALL)
    private val openFence = Regex("```.*$", RegexOption.DOT_MATCHES_ALL)
    private val link = Regex("\\[([^\\]]+)]\\([^)]*\\)")
    private val emoji = Regex("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}]")
    private val marks = Regex("(?m)^\\s{0,3}#{1,6}\\s*|^\\s*>\\s?|[*`~]+|^\\s*[-•]\\s+")

    /** Markdown/emoji-free text suitable for speaking. */
    fun clean(md: String): String = md
        .replace(fence, " ").replace(openFence, " ")
        .replace(link, "$1")
        .replace(emoji, "")
        .replace(marks, "")
        .replace(Regex("\\s+"), " ")
        .trim()

    /** Splits into sentence-aligned pieces no longer than [max] characters. */
    fun chunks(text: String, max: Int): List<String> {
        if (text.length <= max) return listOf(text)
        val out = ArrayList<String>()
        val cur = StringBuilder()
        for (s in text.split(Regex("(?<=[.!?।؟。！？])\\s+"))) {
            var sentence = s
            while (sentence.length > max) {
                val cut = sentence.lastIndexOf(' ', max).takeIf { it > max / 2 } ?: max
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur.clear() }
                out.add(sentence.substring(0, cut).trim()); sentence = sentence.substring(cut).trim()
            }
            if (cur.length + sentence.length + 1 > max && cur.isNotEmpty()) { out.add(cur.toString()); cur.clear() }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(sentence)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out.filter { it.isNotBlank() }
    }
}

/** Picks a speaking language for the device voice from the dominant script of the text (null = use device language). */
object ScriptLocale {
    fun guess(text: String): Locale? {
        var letters = 0
        val counts = HashMap<String, Int>()
        for (ch in text) {
            if (!ch.isLetter()) continue
            letters++
            val c = ch.code
            val tag = when (c) {
                in 0x0980..0x09FF -> "bn"
                in 0x0900..0x097F -> "hi"
                in 0x0600..0x06FF -> "ar"
                in 0x0400..0x04FF -> "ru"
                in 0x3040..0x30FF -> "ja"
                in 0x4E00..0x9FFF -> "zh"
                in 0xAC00..0xD7AF -> "ko"
                in 0x0E00..0x0E7F -> "th"
                else -> continue
            }
            counts[tag] = (counts[tag] ?: 0) + 1
        }
        if (letters == 0) return null
        val kana = counts["ja"] ?: 0
        val (tag, n) = counts.maxByOrNull { it.value }?.toPair() ?: return null
        if (n * 10 < letters * 3) return null
        return Locale.forLanguageTag(if (tag == "zh" && kana > 0) "ja" else tag)
    }
}
