package com.jarvis.ai.data

import android.content.Context

/** Non-sensitive app settings. Secrets never go here. */
class AppPrefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    var onboardingDone: Boolean
        get() = sp.getBoolean("onboarding_done", false)
        set(v) = sp.edit().putBoolean("onboarding_done", v).apply()

    var selectedModelId: String
        get() = sp.getString("selected_model_id", "") ?: ""
        set(v) = sp.edit().putString("selected_model_id", v).apply()

    var customModelId: String
        get() = sp.getString("custom_model_id", "") ?: ""
        set(v) = sp.edit().putString("custom_model_id", v).apply()
    // ── Phase 2: voice ──
    var voiceProvider: String
        get() = sp.getString("voice_provider", "ANDROID") ?: "ANDROID"
        set(v) = sp.edit().putString("voice_provider", v).apply()
    var voiceVolume: Float
        get() = sp.getFloat("voice_volume", 1f)
        set(v) = sp.edit().putFloat("voice_volume", v).apply()
    var voiceSpeed: Float
        get() = sp.getFloat("voice_speed", 1f)
        set(v) = sp.edit().putFloat("voice_speed", v).apply()
    var voicePitch: Float
        get() = sp.getFloat("voice_pitch", 1f)
        set(v) = sp.edit().putFloat("voice_pitch", v).apply()
    var elevenVoiceId: String
        get() = sp.getString("eleven_voice_id", DEFAULT_ELEVEN_VOICE) ?: DEFAULT_ELEVEN_VOICE
        set(v) = sp.edit().putString("eleven_voice_id", v.ifBlank { DEFAULT_ELEVEN_VOICE }).apply()
    var geminiVoiceName: String
        get() = sp.getString("gemini_voice_name", "Kore") ?: "Kore"
        set(v) = sp.edit().putString("gemini_voice_name", v).apply()
    var continuousConversation: Boolean
        get() = sp.getBoolean("continuous_conversation", true)
        set(v) = sp.edit().putBoolean("continuous_conversation", v).apply()
    var speechLocaleTag: String
        get() = sp.getString("speech_locale_tag", "") ?: ""
        set(v) = sp.edit().putString("speech_locale_tag", v).apply()

    // ── Phase 2: chat + assistant profile (Phase 4 adds the editing UI) ──
    var chatHistoryEnabled: Boolean
        get() = sp.getBoolean("chat_history_enabled", true)
        set(v) = sp.edit().putBoolean("chat_history_enabled", v).apply()
    var activeConversationId: String
        get() = sp.getString("active_conversation_id", "") ?: ""
        set(v) = sp.edit().putString("active_conversation_id", v).apply()
    var brainMode: String
        get() = sp.getString("brain_mode", "BALANCED") ?: "BALANCED"
        set(v) = sp.edit().putString("brain_mode", v).apply()
    var assistantName: String
        get() = sp.getString("assistant_name", "JARVIS") ?: "JARVIS"
        set(v) = sp.edit().putString("assistant_name", v).apply()
    var userCallName: String
        get() = sp.getString("user_call_name", "Boss") ?: "Boss"
        set(v) = sp.edit().putString("user_call_name", v).apply()

    // ── Phase 4 ──
    var personalityMode: String
        get() = sp.getString("personality_mode", "FRIEND") ?: "FRIEND"
        set(v) = sp.edit().putString("personality_mode", v).apply()
    var aiStyle: String
        get() = sp.getString("ai_style", "FRIENDLY") ?: "FRIENDLY"
        set(v) = sp.edit().putString("ai_style", v).apply()
    /** Empty = mirror the user's language. */
    var replyLanguage: String
        get() = sp.getString("reply_language", "") ?: ""
        set(v) = sp.edit().putString("reply_language", v).apply()
    var avatarIndex: Int
        get() = sp.getInt("avatar_index", 0)
        set(v) = sp.edit().putInt("avatar_index", v).apply()
    var accentIndex: Int
        get() = sp.getInt("accent_index", 0)
        set(v) = sp.edit().putInt("accent_index", v).apply()
    var spokenReminders: Boolean
        get() = sp.getBoolean("spoken_reminders", true)
        set(v) = sp.edit().putBoolean("spoken_reminders", v).apply()
    var voiceNotifications: Boolean
        get() = sp.getBoolean("voice_notifications", true)
        set(v) = sp.edit().putBoolean("voice_notifications", v).apply()
    var backgroundAssistant: Boolean
        get() = sp.getBoolean("background_assistant", false)
        set(v) = sp.edit().putBoolean("background_assistant", v).apply()
    var activeProvider: String
        get() = sp.getString("active_provider", "GEMINI") ?: "GEMINI"
        set(v) = sp.edit().putString("active_provider", v).apply()
    var myVoicesJson: String
        get() = sp.getString("my_voices", "[]") ?: "[]"
        set(v) = sp.edit().putString("my_voices", v).apply()

    var fontScaleIndex: Int
        get() = sp.getInt("font_scale_index", 1)
        set(v) = sp.edit().putInt("font_scale_index", v).apply()

    fun getStr(key: String, def: String = ""): String = sp.getString(key, def) ?: def
    fun putStr(key: String, v: String) = sp.edit().putString(key, v).apply()

    companion object {
        const val DEFAULT_ELEVEN_VOICE = "21m00Tcm4TlvDq8ikWAM"
    }
}
