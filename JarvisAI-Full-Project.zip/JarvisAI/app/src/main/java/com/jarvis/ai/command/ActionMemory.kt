package com.jarvis.ai.command

import org.json.JSONObject
import java.util.ArrayDeque

/** Something JARVIS knows about the screen. Phase 4's Accessibility reader fills these in ("the second chat"). */
data class ScreenItem(val index: Int, val label: String, val kind: String)

/**
 * Short-term action context (about 15 minutes). Its snapshot is added to Gemini's prompt so follow-ups like
 * "open the second chat" then "send him hello" can resolve "him" and "that app". Phase 4 adds [visibleItems].
 */
class ActionMemory {
    private class Entry(val tool: String, val ok: Boolean, val summary: String, val at: Long)

    private val items = ArrayDeque<Entry>()
    @Volatile var currentApp: String? = null; private set
    @Volatile var currentAppAt = 0L; private set
    @Volatile var lastContact: String? = null; private set
    @Volatile var lastQuery: String? = null; private set
    @Volatile var visibleItems: List<ScreenItem> = emptyList()
    @Volatile var lastSelected: String? = null; private set

    fun setCurrentApp(label: String) { currentApp = label; currentAppAt = System.currentTimeMillis() }
    @Synchronized fun clear() { items.clear(); currentApp = null; lastContact = null; lastSelected = null; lastQuery = null; visibleItems = emptyList() }

    @Synchronized
    fun record(tool: String, args: JSONObject, o: ActionOutcome) {
        val now = System.currentTimeMillis()
        items.addLast(Entry(tool, o.ok, o.summary, now))
        while (items.size > 12) items.removeFirst()
        if (o.ok) when (tool) {
            "open_app" -> { currentApp = o.data.optString("app_label").ifEmpty { args.optString("app_name") }; currentAppAt = now }
            "draft_message" -> { lastContact = o.data.optString("contact_name").ifEmpty { args.optString("contact") }; currentApp = o.data.optString("app_label").ifEmpty { currentApp }; currentAppAt = now }
            "call_contact", "find_contact" -> lastContact = o.data.optString("contact_name").ifEmpty { args.optString(if (tool == "find_contact") "name" else "contact") }
            "search", "play_media" -> lastQuery = args.optString("query")
            "screen_action" -> o.data.optString("selected_label").takeIf { it.isNotBlank() }?.let { lastSelected = it }
        }
    }

    @Synchronized
    fun snapshot(now: Long = System.currentTimeMillis()): String {
        val recent = items.filter { now - it.at < TTL }
        if (recent.isEmpty() && lastContact == null && visibleItems.isEmpty()) return ""
        return buildString {
            appendLine("Recent phone activity (use it to resolve words like \"him\", \"that app\" or \"it\"):")
            recent.takeLast(6).forEach { appendLine("- ${it.summary} (${(now - it.at) / 1000}s ago${if (it.ok) "" else ", failed"})") }
            currentApp?.takeIf { now - currentAppAt < TTL }?.let { appendLine("Last app JARVIS opened: $it. Screen contents are not visible to JARVIS yet.") }
            lastContact?.let { appendLine("Last contact mentioned: $it.") }
            lastSelected?.let { appendLine("Last item the user opened on screen: \"$it\" (it is probably the person meant by \"him\" or \"her\" in a chat).") }
            if (visibleItems.isNotEmpty()) appendLine("Visible items: " + visibleItems.joinToString { "${it.index}. ${it.label}" })
        }.trim()
    }

    private companion object { const val TTL = 15 * 60 * 1000L }
}

/** Tracks whether JARVIS is on screen: Android only lets a foreground app open other apps. */
class AppForeground {
    @Volatile var isForeground = false
    @Volatile private var lastLaunch = 0L
    fun noteExternalLaunch() { lastLaunch = System.currentTimeMillis() }
    fun recentlyLaunched(withinMs: Long = 10_000) = System.currentTimeMillis() - lastLaunch < withinMs
}
