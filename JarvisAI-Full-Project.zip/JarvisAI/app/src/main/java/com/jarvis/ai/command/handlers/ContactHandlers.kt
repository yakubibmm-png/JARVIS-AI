package com.jarvis.ai.command.handlers

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.telephony.PhoneNumberUtils
import android.telephony.TelephonyManager
import com.jarvis.ai.apps.AppMatch
import com.jarvis.ai.apps.InstalledApps
import com.jarvis.ai.command.ActionOutcome
import com.jarvis.ai.contacts.Contact
import com.jarvis.ai.contacts.ContactMatch
import com.jarvis.ai.contacts.ContactsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Contact lookup, calling and message drafting. Contacts are resolved on the device (numbers never go to Gemini).
 * Calls open the dialer and messages open a prefilled draft: the user presses call / send. Nothing is sent silently.
 */
class ContactHandlers(
    private val ctx: Context,
    private val contacts: ContactsRepository,
    private val apps: InstalledApps,
) {
    private class Target(val name: String, val number: String, val numberType: String?)

    fun find(args: JSONObject): ActionOutcome {
        val q = args.optString("name").trim()
        if (q.isEmpty()) return ActionOutcome.fail("No name was given.", "missing_argument")
        if (!contacts.hasPermission()) return noPermission()
        val found = contacts.search(q)
        if (found.isEmpty()) return ActionOutcome.fail("No contact matches \"$q\".", "not_found")
        val arr = JSONArray()
        found.forEach { c -> arr.put(JSONObject().put("name", c.name).put("number_types", JSONArray(c.numbers.map { it.type }.distinct()))) }
        return ActionOutcome(
            ok = true, summary = if (found.size == 1) "Found ${found[0].name}." else "Found ${found.size} contacts matching \"$q\".",
            data = JSONObject().put("contacts", arr).put("contact_name", found[0].name),
        )
    }

    fun call(args: JSONObject): ActionOutcome {
        val who = args.optString("contact").trim()
        if (who.isEmpty()) return ActionOutcome.fail("No contact was given.", "missing_argument")
        val target = when (val t = resolve(who)) { is Resolved.Ok -> t.target; is Resolved.Fail -> return t.outcome }
        val ok = ctx.tryStart(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(target.number))))
        return if (ok) ActionOutcome(
            ok = true, launchedExternal = true, summary = "Opened the dialer with ${target.name}'s number.",
            needsUserAction = "Press the call button to place the call.",
            data = JSONObject().put("contact_name", target.name).put("call_placed", false),
        ) else ActionOutcome.fail("No dialer app is available.", "no_handler")
    }

    fun draft(args: JSONObject): ActionOutcome {
        val who = args.optString("contact").trim()
        val text = args.optString("text").trim()
        val appName = args.optString("app_name").trim()
        if (who.isEmpty()) return ActionOutcome.fail("No contact was given.", "missing_argument")
        val target = when (val t = resolve(who)) { is Resolved.Ok -> t.target; is Resolved.Fail -> return t.outcome }

        var pkg: String? = null
        var appLabel = "Messages (SMS)"
        val sms = appName.isEmpty() || TextOnly.isSms(appName)
        if (!sms) when (val m = apps.resolve(appName)) {
            is AppMatch.Found -> { pkg = m.app.pkg; appLabel = m.app.label }
            is AppMatch.Ambiguous -> return ambiguous(appName, m.apps)
            is AppMatch.None -> return ActionOutcome(false, "No installed app matches \"$appName\".", reason = "not_installed")
        }

        val intent: Intent
        var prefilled = text.isNotEmpty()
        when {
            pkg == null -> intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(target.number))).putExtra("sms_body", text)
            pkg.startsWith("com.whatsapp") -> {
                val digits = e164Digits(target.number) ?: return ActionOutcome.fail("I couldn't turn ${target.name}'s number into an international number for WhatsApp.", "bad_number")
                intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits" + if (text.isNotEmpty()) "?text=${enc(text)}" else "")).setPackage(pkg)
            }
            pkg.startsWith("org.telegram") -> {
                val digits = e164Digits(target.number) ?: return ActionOutcome.fail("I couldn't turn ${target.name}'s number into an international number.", "bad_number")
                intent = Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?phone=$digits")).setPackage(pkg)
                prefilled = false
            }
            else -> {
                intent = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage(pkg)
            }
        }
        if (!ctx.tryStart(intent)) return ActionOutcome.fail("Couldn't open $appLabel.", "launch_refused")
        val generic = pkg != null && !pkg.startsWith("com.whatsapp") && !pkg.startsWith("org.telegram")
        return ActionOutcome(
            ok = true, launchedExternal = true,
            summary = if (text.isEmpty()) "Opened $appLabel for ${target.name}." else "Prepared a message to ${target.name} in $appLabel.",
            needsUserAction = when {
                text.isEmpty() -> "Type your message and press Send."
                generic -> "Choose ${target.name} in $appLabel and press Send."
                prefilled -> "Press Send in $appLabel."
                else -> "Type the message and press Send."
            },
            data = JSONObject().put("contact_name", target.name).put("app_label", appLabel).put("text_prefilled", prefilled && text.isNotEmpty()).put("sent", false),
        )
    }

    // ── resolution ──
    private sealed interface Resolved {
        class Ok(val target: Target) : Resolved
        class Fail(val outcome: ActionOutcome) : Resolved
    }

    private fun resolve(who: String): Resolved {
        if (looksLikeNumber(who)) return Resolved.Ok(Target(who, who, null))
        return when (val m = contacts.resolve(who)) {
            ContactMatch.NoPermission -> Resolved.Fail(noPermission())
            ContactMatch.NotFound -> Resolved.Fail(ActionOutcome.fail("No contact matches \"$who\".", "not_found"))
            is ContactMatch.Ambiguous -> Resolved.Fail(ActionOutcome(false, "More than one contact matches \"$who\".", reason = "ambiguous", candidates = m.contacts.map { it.name }))
            is ContactMatch.Found -> {
                val c: Contact = m.contact
                val n = c.numbers.firstOrNull { it.isMobile } ?: c.numbers.firstOrNull()
                if (n == null) Resolved.Fail(ActionOutcome.fail("${c.name} has no phone number saved.", "no_number"))
                else Resolved.Ok(Target(c.name, n.number, n.type))
            }
        }
    }

    private fun noPermission() = ActionOutcome.permission("contacts", "JARVIS needs the Contacts permission to look up people.")

    private fun looksLikeNumber(s: String) = s.count { it.isDigit() } >= 5 && s.all { it.isDigit() || it in "+-() ." }

    private fun e164Digits(number: String): String? {
        val tm = ctx.getSystemService(TelephonyManager::class.java)
        val country = (tm?.simCountryIso?.ifEmpty { null } ?: tm?.networkCountryIso?.ifEmpty { null } ?: Locale.getDefault().country).uppercase()
        val e164 = PhoneNumberUtils.formatNumberToE164(number, country)
        if (e164 != null) return e164.filter { it.isDigit() }
        val digits = number.filter { it.isDigit() }
        return if (number.trim().startsWith("+") && digits.length >= 8) digits else null
    }

    private object TextOnly {
        fun isSms(app: String) = app.lowercase().trim() in setOf("sms", "text", "text message", "messages", "message", "messaging")
    }
}
