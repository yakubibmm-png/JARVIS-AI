package com.jarvis.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.ui.components.AiOrb
import com.jarvis.ai.ui.components.JarvisBackground
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.theme.JarvisColors
import kotlinx.coroutines.launch

private class OnboardPage(val title: String, val body: String, val action: String? = null)

private val pages = listOf(
    OnboardPage("Meet JARVIS AI", "Your smart AI assistant. Talk or type, and let JARVIS answer, remind, search and help you control your phone."),
    OnboardPage(
        "Add your Gemini API key",
        "Gemini powers JARVIS's intelligence and voice conversation. ElevenLabs is an optional secondary provider for extra voice options.",
        "ADD KEY",
    ),
    OnboardPage(
        "You stay in control",
        "JARVIS asks for each permission only when a feature needs it, and always explains why. Nothing is enabled without you.",
        "PERMISSIONS",
    ),
)

@Composable
fun OnboardingScreen(onAddKey: () -> Unit, onPermissions: () -> Unit, onFinish: () -> Unit) {
    val pager = rememberPagerState { pages.size }
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == pages.lastIndex

    JarvisBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("JARVIS AI", color = JarvisColors.Cyan, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                Text("Skip", color = JarvisColors.TextDim, fontSize = 14.sp, modifier = Modifier.clip(CircleShape).clickable(role = Role.Button, onClick = onFinish).padding(horizontal = 12.dp, vertical = 8.dp))
            }
            HorizontalPager(pager, Modifier.weight(1f)) { i ->
                val p = pages[i]
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AiOrb(Modifier.size(minOf(maxWidth, maxHeight)))
                    }
                    Text(p.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text(p.body, color = JarvisColors.TextDim, fontSize = 14.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    if (p.action != null) {
                        NeonButton(p.action, if (i == 1) onAddKey else onPermissions, Modifier.fillMaxWidth(0.7f))
                    } else Spacer(Modifier.height(46.dp))
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    pages.indices.forEach { i ->
                        Box(
                            Modifier.height(8.dp).width(if (i == pager.currentPage) 24.dp else 8.dp).clip(CircleShape)
                                .background(if (i == pager.currentPage) JarvisColors.Cyan else JarvisColors.TextDim.copy(alpha = 0.4f)),
                        )
                    }
                }
                NeonButton(if (last) "Get Started" else "Next", {
                    if (last) onFinish() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                })
            }
        }
    }
}
