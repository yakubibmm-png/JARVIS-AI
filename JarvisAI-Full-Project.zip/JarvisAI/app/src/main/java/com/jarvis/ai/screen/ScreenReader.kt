package com.jarvis.ai.screen

import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo

class UiNode(
    val info: AccessibilityNodeInfo, val label: String, val kind: String, val bounds: Rect,
    val clickable: Boolean, val editable: Boolean, val scrollable: Boolean, val password: Boolean, val viewId: String,
)

/** Turns the accessibility node tree into something JARVIS can reason about. Password fields are never read. */
object ScreenReader {
    private const val MAX_NODES = 500

    fun collect(root: AccessibilityNodeInfo, ownPkg: String): List<UiNode> {
        val out = ArrayList<UiNode>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || out.size >= MAX_NODES || depth > 40) return
            if (n.packageName?.toString() == ownPkg) return
            if (n.isVisibleToUser) {
                val label = labelOf(n)
                if (label.isNotBlank() || n.isClickable || n.isEditable || n.isScrollable) {
                    val r = Rect(); n.getBoundsInScreen(r)
                    out.add(UiNode(n, label, kindOf(n), r, n.isClickable, n.isEditable, n.isScrollable, n.isPassword, n.viewIdResourceName.orEmpty()))
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return out
    }

    fun labelOf(n: AccessibilityNodeInfo): String {
        if (n.isPassword) return ""
        n.text?.toString()?.takeIf { it.isNotBlank() }?.let { return it }
        n.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { return it }
        if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString()?.takeIf { it.isNotBlank() }?.let { return it }
        return ""
    }

    private fun kindOf(n: AccessibilityNodeInfo): String {
        val c = n.className?.toString()?.substringAfterLast('.')?.lowercase().orEmpty()
        return when {
            n.isEditable || "edittext" in c -> "input"
            "button" in c -> "button"
            "switch" in c || "check" in c || "toggle" in c -> "toggle"
            "image" in c -> "image"
            "text" in c -> "text"
            else -> "view"
        }
    }

    /** Rows of the main on-screen list (chats, results, messages...), top to bottom: this is what "the second chat" means. */
    fun listItems(root: AccessibilityNodeInfo): List<UiNode> {
        var best: AccessibilityNodeInfo? = null
        var bestCount = 0
        fun find(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 40) return
            if (n.isScrollable && n.isVisibleToUser && n.childCount > bestCount) { best = n; bestCount = n.childCount }
            for (i in 0 until n.childCount) find(n.getChild(i), depth + 1)
        }
        find(root, 0)
        val list = best ?: return emptyList()
        val items = ArrayList<UiNode>()
        for (i in 0 until list.childCount) {
            val c = list.getChild(i) ?: continue
            if (!c.isVisibleToUser) continue
            val label = descendantText(c)
            if (label.isBlank()) continue
            val r = Rect(); c.getBoundsInScreen(r)
            if (r.height() <= 0) continue
            items.add(UiNode(c, label, "item", r, c.isClickable, false, false, false, c.viewIdResourceName.orEmpty()))
        }
        return items.sortedWith(compareBy({ it.bounds.top }, { it.bounds.left }))
    }

    fun descendantText(n: AccessibilityNodeInfo, max: Int = 100): String {
        val parts = LinkedHashSet<String>()
        fun walk(x: AccessibilityNodeInfo?, depth: Int) {
            if (x == null || depth > 8 || parts.size >= 6) return
            val l = labelOf(x)
            if (l.isNotBlank()) parts.add(l.replace('\n', ' ').trim())
            for (i in 0 until x.childCount) walk(x.getChild(i), depth + 1)
        }
        walk(n, 0)
        return parts.joinToString(" · ").take(max)
    }

    /** The node that actually receives a click: the node itself, a clickable child, or a clickable parent. */
    fun clickTarget(info: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (info.isClickable) return info
        fun down(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
            if (n == null || depth > 6) return null
            if (n.isClickable) return n
            for (i in 0 until n.childCount) down(n.getChild(i), depth + 1)?.let { return it }
            return null
        }
        down(info, 0)?.let { return it }
        var p = info.parent
        var hops = 0
        while (p != null && hops < 8) { if (p.isClickable) return p; p = p.parent; hops++ }
        return null
    }
}
