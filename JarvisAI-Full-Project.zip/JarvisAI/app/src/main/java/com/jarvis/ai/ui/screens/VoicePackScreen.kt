package com.jarvis.ai.ui.screens

import android.Manifest
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.ai.di.LocalContainer
import com.jarvis.ai.ui.components.ChipGrid
import com.jarvis.ai.ui.components.GlassCard
import com.jarvis.ai.ui.components.LabeledField
import com.jarvis.ai.ui.components.NeonButton
import com.jarvis.ai.ui.components.Pill
import com.jarvis.ai.ui.components.ScreenScaffold
import com.jarvis.ai.ui.components.SectionTitle
import com.jarvis.ai.ui.theme.JarvisColors
import com.jarvis.ai.voice.ElevenLabsApi
import com.jarvis.ai.voice.MyVoice
import com.jarvis.ai.voice.MyVoices
import com.jarvis.ai.voice.PcmPlayer
import com.jarvis.ai.voice.UploadFile
import com.jarvis.ai.voice.VoiceCatalog
import com.jarvis.ai.voice.VoiceOption
import com.jarvis.ai.voice.VoiceProviderException
import com.jarvis.ai.voice.VoiceProviderId
import com.jarvis.ai.voice.WavRecorder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Lets other screens open the Voice Pack on a specific tab (0 Gemini, 1 ElevenLabs, 2 Changer, 3 My Voice). */
object VoicePackNav { var initialTab = 0 }

private const val SAMPLE = "Hello, I'm Jarvis. This is how I sound."

@Composable
fun VoicePackScreen(onBack: () -> Unit, onOpenApiKey: () -> Unit) {
    val c = LocalContainer.current
    var tab by remember { mutableStateOf(VoicePackNav.initialTab.coerceIn(0, 3)); }
    VoicePackNav.initialTab = 0
    ScreenScaffold("Voice Pack", "Custom voices, voice changer & more", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Gemini", "ElevenLabs", "Changer", "My Voice").forEachIndexed { i, t -> Pill(t, tab == i) { tab = i } }
        }
        when (tab) {
            0 -> VoiceList(VoiceProviderId.GEMINI, VoiceCatalog.gemini, onOpenApiKey)
            1 -> VoiceList(VoiceProviderId.ELEVENLABS, VoiceCatalog.eleven, onOpenApiKey)
            2 -> ChangerTab(onOpenApiKey)
            else -> MyVoiceTab(onOpenApiKey)
        }
    }
}

// ───────────────────────── Gemini / ElevenLabs voice lists ─────────────────────────
@Composable
private fun VoiceList(provider: VoiceProviderId, voices: List<VoiceOption>, onOpenApiKey: () -> Unit) {
    val c = LocalContainer.current
    val prefs = c.prefs
    val scope = rememberCoroutineScope()
    val elevenKey by c.credentials.elevenLabsKey.collectAsState()
    var category by remember { mutableStateOf(VoiceCatalog.GIRLS) }
    var selected by remember { mutableStateOf(if (provider == VoiceProviderId.GEMINI) prefs.geminiVoiceName else prefs.elevenVoiceId) }
    var using by remember { mutableStateOf(prefs.voiceProvider) }
    var job by remember { mutableStateOf<Job?>(null) }
    var playing by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf<String?>(null) }
    var customId by remember { mutableStateOf(if (provider == VoiceProviderId.ELEVENLABS) prefs.elevenVoiceId else "") }

    if (provider == VoiceProviderId.ELEVENLABS && elevenKey.isBlank()) GlassCard {
        Text("Add your ElevenLabs API key to use this voice.", color = JarvisColors.Gold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp)); NeonButton("ADD KEY", onOpenApiKey, Modifier.fillMaxWidth())
    }
    GlassCard {
        SectionTitle(if (provider == VoiceProviderId.GEMINI) "Gemini Voice" else "ElevenLabs Voice", "High-quality voices. Tap Preview to hear one, Use to make it JARVIS's voice.")
        Spacer(Modifier.height(8.dp))
        ChipGrid(VoiceCatalog.categories.map { it to it.removeSuffix(" Voice") }, category, columns = 4) { category = it }
    }
    voices.filter { category in it.categories }.forEach { v ->
        val isSel = selected == v.id && using == provider.name
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(v.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(v.trait + if (isSel) " · in use" else "", color = if (isSel) JarvisColors.Success else JarvisColors.TextDim, fontSize = 12.sp)
                }
                NeonButton(if (playing == v.id) "Stop" else "Preview", {
                    if (playing == v.id) { job?.cancel(); c.tts.stop(); playing = null }
                    else {
                        job?.cancel(); c.voiceController.interruptAll(); playing = v.id; note = null
                        job = scope.launch {
                            try { note = c.tts.speak(SAMPLE, provider, v.id) { }.note } catch (e: CancellationException) { throw e } catch (e: Exception) { note = "Couldn't play this voice." }
                            playing = null
                        }
                    }
                }, filled = false, icon = if (playing == v.id) Icons.Filled.Stop else Icons.Filled.PlayArrow)
                Spacer(Modifier.width(8.dp))
                NeonButton(if (isSel) "Using" else "Use", {
                    if (provider == VoiceProviderId.GEMINI) prefs.geminiVoiceName = v.id else { prefs.elevenVoiceId = v.id; customId = v.id }
                    prefs.voiceProvider = provider.name; selected = v.id; using = provider.name
                }, enabled = !isSel)
            }
        }
    }
    note?.let { Text(it, color = JarvisColors.Gold, fontSize = 12.sp) }
    if (provider == VoiceProviderId.ELEVENLABS) GlassCard {
        LabeledField(customId, { customId = it.trim(); prefs.elevenVoiceId = customId; selected = prefs.elevenVoiceId }, "Or paste any ElevenLabs voice ID", "Voice ID from your ElevenLabs account")
    }
}

// ───────────────────────── Voice Changer ─────────────────────────
@Composable
private fun ChangerTab(onOpenApiKey: () -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val key by c.credentials.elevenLabsKey.collectAsState()
    val api = remember { ElevenLabsApi(ctx) }
    val recorder = remember { WavRecorder() }
    val mine = remember { MyVoices(c.prefs) }
    var recording by remember { mutableStateOf(false) }
    var level by remember { mutableStateOf(0f) }
    var wav by remember { mutableStateOf<ByteArray?>(null) }
    var target by remember { mutableStateOf(VoiceCatalog.eleven.first().id) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun begin() {
        message = null; wav = null; recording = true
        scope.launch {
            val r = recorder.record(30) { level = it }
            recording = false; wav = r
            if (r == null) message = "I couldn't record. Check the microphone permission and try a little longer."
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) begin() else message = "Microphone permission is required to record." }
    fun toggle() {
        if (recording) recorder.stop()
        else if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) begin()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }

    if (key.isBlank()) GlassCard {
        Text("Add your ElevenLabs API key to use this voice.", color = JarvisColors.Gold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp)); NeonButton("ADD KEY", onOpenApiKey, Modifier.fillMaxWidth())
    }
    GlassCard {
        SectionTitle("Voice Changer", "Record yourself (up to 30 s). JARVIS plays it back in another voice using ElevenLabs.")
        Spacer(Modifier.height(10.dp))
        Text("Change into", color = JarvisColors.TextDim, fontSize = 12.sp)
        ChipGrid((VoiceCatalog.eleven.map { it.id to it.name } + mine.all().map { it.id to "★ ${it.name}" }), target, columns = 3) { target = it }
        Spacer(Modifier.height(12.dp))
        NeonButton(if (recording) "Stop recording" else "Record", ::toggle, Modifier.fillMaxWidth(), icon = if (recording) Icons.Filled.Stop else Icons.Filled.Mic, enabled = !busy)
        if (recording) Text("Listening… level ${(level * 100).toInt()}%", color = JarvisColors.Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        if (wav != null) Text("Recorded ${wav!!.size / 32_000} s", color = JarvisColors.Success, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(8.dp))
        NeonButton(if (busy) "Converting…" else "Convert & play", {
            val data = wav ?: return@NeonButton
            busy = true; message = null
            scope.launch {
                try {
                    c.voiceController.interruptAll()
                    withContext(Dispatchers.IO) {
                        val p = PcmPlayer(24000, c.prefs.voiceVolume) { }
                        try { p.start(); api.speechToSpeech(key, target, data) { b, n -> p.write(b, n) }; p.drain() } finally { p.release() }
                    }
                } catch (e: CancellationException) { throw e } catch (e: VoiceProviderException) { message = e.userMessage } catch (e: Exception) { message = "Couldn't play the converted voice." }
                busy = false
            }
        }, Modifier.fillMaxWidth(), icon = Icons.Filled.PlayArrow, enabled = wav != null && !busy && key.isNotBlank())
        message?.let { Text(it, color = JarvisColors.Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
    }
}

// ───────────────────────── My Voice ─────────────────────────
@Composable
private fun MyVoiceTab(onOpenApiKey: () -> Unit) {
    val c = LocalContainer.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val key by c.credentials.elevenLabsKey.collectAsState()
    val api = remember { ElevenLabsApi(ctx) }
    val recorder = remember { WavRecorder() }
    val store = remember { MyVoices(c.prefs) }
    var voices by remember { mutableStateOf(store.all()) }
    val files = remember { mutableStateListOf<UploadFile>() }
    var name by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val r = ctx.contentResolver
        val n = r.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { q -> if (q.moveToFirst()) q.getString(0) else null } ?: "sample"
        val bytes = r.openInputStream(uri)?.use { it.readBytes() }
        if (bytes == null || bytes.size > 10 * 1024 * 1024) message = "Pick an audio file smaller than 10 MB."
        else { files.add(UploadFile("files", n, r.getType(uri) ?: "audio/mpeg", bytes)); message = null }
    }
    fun begin() {
        recording = true; message = null
        scope.launch {
            val w = recorder.record(60) { }
            recording = false
            if (w != null) files.add(UploadFile("files", "recording-${files.size + 1}.wav", "audio/wav", w)) else message = "I couldn't record a sample. Check the microphone permission."
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) begin() else message = "Microphone permission is required to record." }

    if (key.isBlank()) GlassCard {
        Text("Add your ElevenLabs API key to use this voice.", color = JarvisColors.Gold, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp)); NeonButton("ADD KEY", onOpenApiKey, Modifier.fillMaxWidth())
    }
    GlassCard {
        SectionTitle("My Voice", "Create a voice from your own audio. A clean 1–3 minute sample works best. Creating voices needs a paid ElevenLabs plan.")
        Spacer(Modifier.height(8.dp))
        LabeledField(name, { name = it }, "Voice name", "e.g. My voice")
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton("Upload Voice", { pick.launch(arrayOf("audio/*")) }, Modifier.weight(1f), icon = Icons.Filled.UploadFile, filled = false, enabled = !recording)
            NeonButton(if (recording) "Stop" else "Record Sample", {
                if (recording) recorder.stop()
                else if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) begin()
                else perm.launch(Manifest.permission.RECORD_AUDIO)
            }, Modifier.weight(1f), icon = if (recording) Icons.Filled.Stop else Icons.Filled.Mic, filled = false)
        }
        files.forEachIndexed { i, f ->
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${f.filename} (${f.bytes.size / 1024} KB)", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.Delete, "Remove sample", tint = JarvisColors.Danger, modifier = Modifier.size(20.dp).clickable { files.removeAt(i) })
            }
        }
        Row(Modifier.padding(top = 8.dp).clickable(role = Role.Checkbox) { consent = !consent }, verticalAlignment = Alignment.CenterVertically) {
            Checkbox(consent, { consent = it }, colors = CheckboxDefaults.colors(checkedColor = JarvisColors.Cyan))
            Text("This is my own voice, or I have the speaker's permission to clone it.", color = Color.White, fontSize = 12.sp)
        }
        Spacer(Modifier.height(6.dp))
        NeonButton(if (busy) "Creating…" else "Create voice", {
            busy = true; message = null
            scope.launch {
                try {
                    val id = api.addVoice(key, name.trim(), files.toList())
                    store.add(MyVoice(id, name.trim())); voices = store.all()
                    c.prefs.elevenVoiceId = id; c.prefs.voiceProvider = VoiceProviderId.ELEVENLABS.name
                    files.clear(); name = ""; consent = false; message = "Voice created and selected."
                } catch (e: CancellationException) { throw e } catch (e: VoiceProviderException) { message = e.userMessage } catch (e: Exception) { message = "Couldn't create the voice." }
                busy = false
            }
        }, Modifier.fillMaxWidth(), enabled = consent && files.isNotEmpty() && name.isNotBlank() && key.isNotBlank() && !busy)
        message?.let { Text(it, color = JarvisColors.Gold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
    }
    voices.forEach { v ->
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("★ ${v.name}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(if (c.prefs.elevenVoiceId == v.id) "In use" else "Saved voice", color = JarvisColors.TextDim, fontSize = 12.sp)
                }
                NeonButton("Use", { c.prefs.elevenVoiceId = v.id; c.prefs.voiceProvider = VoiceProviderId.ELEVENLABS.name; voices = store.all() }, filled = false)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Filled.Delete, "Delete voice", tint = JarvisColors.Danger, modifier = Modifier.size(26.dp).clickable {
                    scope.launch {
                        try { if (key.isNotBlank()) api.deleteVoice(key, v.id); store.remove(v.id); voices = store.all() }
                        catch (e: CancellationException) { throw e } catch (e: VoiceProviderException) { message = e.userMessage }
                    }
                })
            }
        }
    }
}
