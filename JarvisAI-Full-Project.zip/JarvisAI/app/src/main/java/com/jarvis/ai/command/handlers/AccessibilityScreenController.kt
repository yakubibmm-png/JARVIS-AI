package com.jarvis.ai.command.handlers

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.ai.ai.GeminiClient
import com.jarvis.ai.apps.InstalledApps
import com.jarvis.ai.automation.AutomationSettings
import com.jarvis.ai.command.ActionMemory
import com.jarvis.ai.command.ActionOutcome
import com.jarvis.ai.command.ConfirmationManager
import com.jarvis.ai.command.ScreenItem
import com.jarvis.ai.data.ModelRepository
import com.jarvis.ai.premium.PremiumRepository
import com.jarvis.ai.screen.JarvisAccessibilityService
import com.jarvis.ai.screen.ScreenReader
import com.jarvis.ai.screen.ScreenShareManager
import com.jarvis.ai.screen.UiNode
import com.jarvis.ai.util.TextMatch
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

/** Words that make an action consequential: the user must confirm first. */
object Risk {
    private val words = Regex("\\b(send|pay|purchase|buy|order|delete|remove|transfer|submit|post|checkout|uninstall|erase|confirm)\\b", RegexOption.IGNORE_CASE)
    fun isConsequential(label: String) = words.containsMatchIn(label)
}

/**
 * Screen understanding + UI interaction through the Accessibility Service. Every call is gated by Pro, the Automation
 * master switch and the service itself. Targets are found by visible text / ids / list position, not by coordinates
 * (a gesture at the element's bounds is only a fallback). Results report what Android really accepted.
 */
class AccessibilityScreenController(
    private val ctx: Context,
    private val memory: ActionMemory,
    private val premium: PremiumRepository,
    private val automation: AutomationSettings,
    private val confirmations: ConfirmationManager,
    private val screenShare: ScreenShareManager,
    private val gemini: GeminiClient,
    private val models: ModelRepository,
    private val apps: InstalledApps,
    private val requestId: () -> Long,
) : ScreenController {
    override val isAvailable: Boolean get() = JarvisAccessibilityService.instance != null

    private class Pick(val info: AccessibilityNodeInfo, val label: String, val fromList: Boolean)

    private fun gate(): ActionOutcome? {
        if (!premium.isPremium.value) return ActionOutcome.fail("Controlling other apps is a Pro feature.", "premium_required")
        if (!automation.enabled.value) return ActionOutcome.fail("Automation is OFF. Turn it on in Tools → Automation to let JARVIS control the screen.", "automation_off")
        if (JarvisAccessibilityService.instance == null) return ActionOutcome.permission("accessibility", "The Accessibility Service isn't enabled. Turn on JARVIS in Accessibility settings (Permissions page).")
        return null
    }

    override suspend fun perform(action: String, target: String, text: String, ordinal: Int): ActionOutcome {
        gate()?.let { return it }
        val svc = JarvisAccessibilityService.instance ?: return ActionOutcome.fail("Accessibility just disconnected.", "accessibility_unavailable")
        return when (action) {
            "read_screen" -> read(svc)
            "back" -> global(svc, AccessibilityService.GLOBAL_ACTION_BACK, "Went back.")
            "home" -> global(svc, AccessibilityService.GLOBAL_ACTION_HOME, "Went to the home screen.")
            "recents" -> global(svc, AccessibilityService.GLOBAL_ACTION_RECENTS, "Opened recent apps.")
            "scroll_down" -> scroll(svc, down = true)
            "scroll_up" -> scroll(svc, down = false)
            "tap" -> tap(svc, target, ordinal, long = false)
            "long_press" -> tap(svc, target, ordinal, long = true)
            "type" -> type(svc, target, text)
            "send" -> send(svc)
            else -> ActionOutcome.fail("Unknown screen action \"$action\".", "invalid_argument")
        }
    }

    // ───────────── reading ─────────────
    private suspend fun read(svc: AccessibilityService): ActionOutcome {
        val root = svc.rootInActiveWindow ?: return unreadable()
        val nodes = ScreenReader.collect(root, ctx.packageName)
        val visible = nodes.filter { !it.password && it.label.isNotBlank() }.distinctBy { it.label to it.bounds.top }
        val lines = visible.take(70).mapIndexed { i, n -> "${i + 1}. ${n.label.take(90)}${if (n.editable) " [input]" else if (n.clickable) " [tappable]" else ""}" }
        val items = ScreenReader.listItems(root)
        remember(root, items)
        val itemArr = JSONArray(); items.take(15).forEachIndexed { i, it -> itemArr.put("${i + 1}. ${it.label}") }
        return ActionOutcome(
            ok = true, summary = "Read the screen of ${appLabel(root)}.",
            data = JSONObject().put("app", appLabel(root)).put("screen_text", lines.joinToString("\n").take(3500)).put("list_items", itemArr)
                .put("note", "Use ordinal with screen_action for list positions."),
        )
    }

    private fun unreadable() = ActionOutcome.fail("I can't read this screen. The app may block screen reading (for example password or banking screens).", "screen_unreadable")

    private fun remember(root: AccessibilityNodeInfo, items: List<UiNode>) {
        memory.visibleItems = items.take(10).mapIndexed { i, n -> ScreenItem(i + 1, n.label.take(60), "item") }
        appLabel(root).takeIf { it.isNotBlank() }?.let { memory.setCurrentApp(it) }
    }

    private fun appLabel(root: AccessibilityNodeInfo?): String = root?.packageName?.toString()?.let { apps.labelOf(it) ?: it } ?: ""

    private suspend fun refresh(svc: AccessibilityService) {
        delay(600)
        svc.rootInActiveWindow?.let { remember(it, ScreenReader.listItems(it)) }
    }

    // ───────────── tap / long press ─────────────
    private suspend fun tap(svc: AccessibilityService, target: String, ordinal: Int, long: Boolean): ActionOutcome {
        val root = svc.rootInActiveWindow ?: return unreadable()
        val nodes = ScreenReader.collect(root, ctx.packageName)
        val pick: Pick = if (ordinal > 0) {
            val items = ScreenReader.listItems(root)
            remember(root, items)
            if (items.size < ordinal) return ActionOutcome.fail(
                if (items.isEmpty()) "I don't see a list on this screen." else "I only see ${items.size} list item(s) on screen.", "ordinal_out_of_range",
                JSONObject().put("list_items", JSONArray(items.take(10).mapIndexed { i, n -> "${i + 1}. ${n.label}" })),
            )
            Pick(items[ordinal - 1].info, items[ordinal - 1].label, true)
        } else if (target.isNotBlank()) {
            val best = nodes.filter { !it.password }
                .map { n -> n to (maxOf(TextMatch.score(target, n.label), if (n.viewId.isNotEmpty()) TextMatch.score(target, n.viewId.substringAfterLast('/')) - 6 else 0) + if (n.clickable) 4 else 0) }
                .maxByOrNull { it.second }
            if (best == null || best.second < 70) return ActionOutcome(
                ok = false, summary = "I couldn't find \"$target\" on this screen.", reason = "not_found",
                candidates = nodes.filter { it.label.isNotBlank() && !it.password && (it.clickable || it.editable) }.map { it.label.take(40) }.distinct().take(8),
            )
            Pick(best.first.info, best.first.label, false)
        } else return ActionOutcome.fail("Tell me what to tap.", "missing_argument")

        if (!long && Risk.isConsequential(pick.label)) {
            val label = pick.label
            confirmations.request("Tap \"${label.take(40)}\"?", "JARVIS wants to tap \"${label.take(80)}\" in ${appLabel(root)}.", requestId()) { tapByLabel(label, long = false) }
            return awaiting("tap \"${label.take(40)}\"")
        }
        return doTap(svc, pick, long)
    }

    private suspend fun doTap(svc: AccessibilityService, pick: Pick, long: Boolean): ActionOutcome {
        val t = ScreenReader.clickTarget(pick.info)
        val ok = if (t != null) t.performAction(if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK)
        else { val r = Rect(); pick.info.getBoundsInScreen(r); gestureTap(svc, r.centerX().toFloat(), r.centerY().toFloat(), long) }
        if (!ok) return ActionOutcome.fail("Android didn't accept the tap on \"${pick.label.take(40)}\".", "tap_failed")
        refresh(svc)
        val first = pick.label.substringBefore(" · ").take(60)
        return ActionOutcome(
            ok = true, summary = "${if (long) "Long-pressed" else "Tapped"} \"${pick.label.take(40)}\".",
            data = JSONObject().put("label", pick.label.take(80)).apply { if (pick.fromList) put("selected_label", first) },
        )
    }

    private suspend fun tapByLabel(label: String, long: Boolean): ActionOutcome {
        val svc = JarvisAccessibilityService.instance ?: return ActionOutcome.fail("Accessibility disconnected.", "accessibility_unavailable")
        val root = svc.rootInActiveWindow ?: return unreadable()
        val n = ScreenReader.collect(root, ctx.packageName).firstOrNull { it.label == label && !it.password }
            ?: return ActionOutcome.fail("The \"$label\" button is no longer on screen.", "not_found")
        return doTap(svc, Pick(n.info, label, false), long)
    }

    // ───────────── typing / sending ─────────────
    private suspend fun type(svc: AccessibilityService, target: String, text: String): ActionOutcome {
        if (text.isEmpty()) return ActionOutcome.fail("Nothing to type.", "missing_argument")
        val root = svc.rootInActiveWindow ?: return unreadable()
        val editables = ScreenReader.collect(root, ctx.packageName).filter { it.editable }
        val field: AccessibilityNodeInfo = when {
            target.isNotBlank() -> editables.maxByOrNull { TextMatch.score(target, it.label) }?.takeIf { TextMatch.score(target, it.label) >= 60 }?.info
            else -> root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: editables.lastOrNull()?.info
        } ?: return ActionOutcome.fail("I can't find a text box to type in.", "no_input_field")
        if (field.isPassword) return ActionOutcome.fail("JARVIS never types into password fields.", "password_field")

        val existing = if (field.isShowingHintText) "" else field.text?.toString().orEmpty()
        val newText = if (existing.isEmpty()) text else "$existing $text"
        val ok = field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText) })
        field.refresh()
        val verified = field.text?.toString()?.contains(text) == true
        if (!ok || !verified) return ActionOutcome.fail("The text box didn't accept the text.", "set_text_failed")
        refresh(svc)
        return ActionOutcome(
            ok = true, summary = "Typed the text. It has NOT been sent.",
            data = JSONObject().put("typed_characters", text.length).put("sent", false),
            needsUserAction = "Nothing is sent yet. If the user wants it sent, call screen_action with action=send (they will be asked to confirm).",
        )
    }

    private suspend fun send(svc: AccessibilityService): ActionOutcome {
        val root = svc.rootInActiveWindow ?: return unreadable()
        val nodes = ScreenReader.collect(root, ctx.packageName)
        val draft = nodes.filter { it.editable && !it.password && !it.info.isShowingHintText }.lastOrNull()?.info?.text?.toString().orEmpty()
        if (draft.isBlank()) return ActionOutcome.fail("There's no typed message to send. Type it first.", "nothing_to_send")
        if (findSend(nodes) == null) return ActionOutcome(
            ok = false, summary = "I can't find a Send button on this screen.", reason = "no_send_button",
            candidates = nodes.filter { it.clickable && it.label.isNotBlank() }.map { it.label.take(30) }.distinct().take(8),
        )
        val app = appLabel(root)
        confirmations.request("Send this message?", "\"${draft.take(160)}\" in $app", requestId()) { doSend(draft) }
        return awaiting("send \"${draft.take(60)}\" in $app")
    }

    private fun findSend(nodes: List<UiNode>): UiNode? =
        nodes.firstOrNull { it.clickable && !it.password && (TextMatch.norm(it.label) == "send" || it.viewId.lowercase().endsWith("send")) }
            ?: nodes.firstOrNull { it.clickable && !it.password && it.label.lowercase().contains("send") }

    private suspend fun doSend(draft: String): ActionOutcome {
        val svc = JarvisAccessibilityService.instance ?: return ActionOutcome.fail("Accessibility disconnected.", "accessibility_unavailable")
        val root = svc.rootInActiveWindow ?: return unreadable()
        val send = findSend(ScreenReader.collect(root, ctx.packageName)) ?: return ActionOutcome.fail("The Send button is no longer on screen.", "no_send_button")
        val t = ScreenReader.clickTarget(send.info)
        val ok = if (t != null) t.performAction(AccessibilityNodeInfo.ACTION_CLICK) else { val r = send.bounds; gestureTap(svc, r.centerX().toFloat(), r.centerY().toFloat(), false) }
        if (!ok) return ActionOutcome.fail("Android didn't accept the tap on Send.", "tap_failed")
        delay(900)
        val after = svc.rootInActiveWindow?.let { ScreenReader.collect(it, ctx.packageName) }.orEmpty()
        val stillThere = after.any { it.editable && it.info.text?.toString()?.contains(draft) == true }
        refresh(svc)
        return if (!stillThere) ActionOutcome(true, "Message sent.", JSONObject().put("sent", true).put("verified", true))
        else ActionOutcome(true, "I tapped Send, but the message is still in the box, so I can't confirm it was sent.", JSONObject().put("sent", false).put("verified", false))
    }

    private fun awaiting(what: String) = ActionOutcome(
        ok = true, summary = "Waiting for the user's confirmation to $what. Nothing has been done yet.",
        data = JSONObject().put("awaiting_confirmation", true).put("performed", false),
        needsUserAction = "Ask the user to confirm. They can say yes, or tap Confirm on the JARVIS card.",
    )

    // ───────────── scrolling / global ─────────────
    private suspend fun scroll(svc: AccessibilityService, down: Boolean): ActionOutcome {
        val root = svc.rootInActiveWindow ?: return unreadable()
        val node = ScreenReader.collect(root, ctx.packageName).filter { it.scrollable }.maxByOrNull { it.bounds.width() * it.bounds.height() }
        val ok = if (node != null) {
            val id = if (down) AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id else AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id
            node.info.performAction(id) || node.info.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        } else {
            val m = ctx.resources.displayMetrics
            gestureSwipe(svc, m.widthPixels / 2f, m.heightPixels * (if (down) 0.7f else 0.3f), m.widthPixels / 2f, m.heightPixels * (if (down) 0.3f else 0.7f))
        }
        if (!ok) return ActionOutcome.fail("This screen didn't scroll${if (down) " down" else " up"}. It may already be at the end.", "scroll_failed")
        refresh(svc)
        return ActionOutcome(true, if (down) "Scrolled down." else "Scrolled up.")
    }

    private suspend fun global(svc: AccessibilityService, action: Int, done: String): ActionOutcome {
        val ok = svc.performGlobalAction(action)
        if (ok) refresh(svc)
        return if (ok) ActionOutcome(true, done) else ActionOutcome.fail("Android didn't accept that action.", "action_failed")
    }

    private suspend fun gestureTap(svc: AccessibilityService, x: Float, y: Float, long: Boolean): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return dispatch(svc, GestureDescription.StrokeDescription(path, 0, if (long) 700 else 60))
    }

    private suspend fun gestureSwipe(svc: AccessibilityService, x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        return dispatch(svc, GestureDescription.StrokeDescription(path, 0, 350))
    }

    private suspend fun dispatch(svc: AccessibilityService, stroke: GestureDescription.StrokeDescription): Boolean = suspendCancellableCoroutine { cont ->
        val ok = svc.dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(g: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!ok && cont.isActive) cont.resume(false)
    }

    // ───────────── screen questions ─────────────
    override suspend fun ask(question: String): ActionOutcome {
        gate()?.let { return it }
        val svc = JarvisAccessibilityService.instance ?: return ActionOutcome.fail("Accessibility disconnected.", "accessibility_unavailable")
        val root = svc.rootInActiveWindow
        val text = root?.let { r -> ScreenReader.collect(r, ctx.packageName).filter { !it.password && it.label.isNotBlank() }.take(80).joinToString("\n") { it.label.take(100) } }.orEmpty()
        val image = if (screenShare.active.value) screenShare.captureJpeg() else null
        if (image == null && text.isBlank()) return ActionOutcome.fail(
            "There's nothing readable on this screen. Turn on Screen Share in Automation so I can look at it.", "nothing_visible",
        )
        return try {
            val answer = gemini.oneShot(
                models.effective(premium.isPremium.value),
                "You describe the user's current phone screen and answer their question about it briefly and accurately. Use the screenshot (if any) and the visible text. Never guess at things you cannot see.",
                "Question: $question\n\nVisible text on screen:\n$text", image,
            )
            ActionOutcome(true, "Looked at the screen.", JSONObject().put("answer", answer).put("used_screenshot", image != null).put("app", appLabel(root)))
        } catch (e: com.jarvis.ai.ai.AiException) {
            ActionOutcome.fail(e.userMessage, "ai_error")
        }
    }

    override suspend fun confirm(approve: Boolean): ActionOutcome =
        if (approve) confirmations.approveFromTool(requestId())
        else if (confirmations.cancel()) ActionOutcome(true, "Cancelled. Nothing was done.") else ActionOutcome.fail("Nothing was waiting for confirmation.", "nothing_pending")
}
