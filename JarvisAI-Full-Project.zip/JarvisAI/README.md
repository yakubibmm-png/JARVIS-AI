# JARVIS AI — Android (complete project: Phases 1–4)

Kotlin + Jetpack Compose · minSdk 26 · targetSdk 34. Open in Android Studio (Koala or newer) and run `app`.
First run: onboarding → add your Gemini key (sparkle icon, top-right of Home) → tap the mic or open Chat.
Pro: Pro tab → get a key from @JARVISai_PRO on Telegram → Unlock. `./gradlew test` runs the matching unit tests.

| Phase | What it added |
|---|---|
| 1 | 5-tab navigation, Home (orb, waveform), API Key page (Gemini + ElevenLabs, encrypted), Pro/Premium state, Permissions page, onboarding |
| 2 | Gemini streaming chat + history, speech recognition, voice conversation loop, device/Gemini/ElevenLabs voices with fallback, live waveform, MUTE/SLEEP/STOP |
| 3 | Command engine: Gemini tool calls → planner → real Android actions (open any installed app, Google Play install flow, reminders, alarms, time, weather, music, contacts, call/message drafts), Quick Actions/Reminders/Music/Weather screens |
| 4 | Accessibility screen control, Screen Share, contextual follow-ups, confirmed sending, WhatsApp Auto Reply, contact shortcuts, background assistant, spoken reminders, Voice Pack, Super AI, Preferences, Personalization, Automation, real Settings pages |

See `PHASE4_REPORT.md` (implementation, limits, remaining work) and `ANDROID_TESTING_CHECKLIST.md`.

## Architecture in one picture
    voice/text → ConversationEngine → Gemini (tools) → ActionEngine.plan → handlers → ActionOutcome (what REALLY happened) → Gemini → reply
    handlers: DeviceHandlers · ContactHandlers · InfoHandlers · AccessibilityScreenController (+ ConfirmationManager)
    background: AssistantService (foreground) · JarvisNotificationListener (Auto Reply) · AutomationRunner/TaskScheduler/TriggerManager
Nothing is matched against fixed phrases or app names. Safety: Pro + Automation master switch gate every automation;
sending/paying/deleting always needs the user's yes; passwords are never read or typed.

## Build status
Written and statically checked in an environment without the Android SDK, Gradle or a Kotlin compiler, so it has NOT been compiled or run.
Expect a few small fixes on the first Gradle sync (see PHASE4_REPORT.md → Build status).
